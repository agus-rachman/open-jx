# Deadline rule tables

Generated from packs/*/deadlines.yaml. Use these ids with scripts/compute_deadline.py.
The script computes only from rules, provisions and holiday tables in the `verified` evidence state.

## art — Administrative Review Tribunal (pack au, holidays `nsw`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `art-general-review-application` | Application for review of a reviewable decision (general period, where no other Act fixes one) | Administrative Review Tribunal Rules 2024 (Cth) r 5, made for s 18(1) of the Administrative Review Tribunal Act 2024 (Cth) | 28 calendar days | next_business_day | verified |
| `migration-judicial-review` | Judicial review of a migration decision | Migration Act 1958 (Cth) ss 477(1) and 477A(1) | 35 calendar days | none | verified |

## cth-federal-courts — Federal Court of Australia, Federal Circuit and Family Court of Australia (Division 2, general federal law) (pack au, holidays `nsw`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `fcr-defence-after-service` | Defence after service of statement of claim | Federal Court Rules 2011 (Cth) r 16.32 | 28 calendar days | next_business_day | verified |
| `fcr-notice-of-appeal` | Notice of appeal from a Federal Court judgment (no leave path) | Federal Court Rules 2011 (Cth) r 36.03 | 28 calendar days | next_business_day | verified |

## act-courts — Supreme Court of the Australian Capital Territory, Magistrates Court of the Australian Capital Territory (pack au-act, holidays `act`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `act-cpr-noir-or-defence-after-service` | Notice of intention to respond, defence, or both, after service of originating claim | Court Procedures Rules 2006 (ACT) r 102(1)(a) | 28 calendar days | next_business_day | verified |
| `act-cpr-appeal-notice-ca` | Notice of appeal and case summary to the Court of Appeal (no leave required) | Court Procedures Rules 2006 (ACT) r 5405(1)(b) | 28 calendar days | next_business_day | verified |

## ncat — NSW Civil and Administrative Tribunal (pack au-nsw, holidays `nsw`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `ncat-internal-appeal` | Internal appeal to the NCAT Appeal Panel (general period) | Civil and Administrative Tribunal Rules 2014 (NSW) r 25(4)(c) | 28 calendar days | next_business_day | verified |

## nsw-courts — Supreme Court of NSW, District Court of NSW, Local Court of NSW (pack au-nsw, holidays `nsw`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `ucpr-defence-after-service` | Defence after service of statement of claim | Uniform Civil Procedure Rules 2005 (NSW) r 14.3(1) | 28 calendar days | next_business_day | verified |
| `ucpr-appeal-notice-ca` | Notice of appeal to the Court of Appeal (no leave required, no notice of intention filed) | Uniform Civil Procedure Rules 2005 (NSW) r 51.16(1)(c) | 28 calendar days | next_business_day | verified |

## nt-courts — Supreme Court of the Northern Territory, Local Court of the Northern Territory (pack au-nt, holidays `nt`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `nt-scr-appearance-after-service` | Notice of appearance after service of writ (Darwin Registry, service within 200 km of Darwin) | Supreme Court Rules 1987 (NT) r 8.04(a)(i) | 7 calendar days | next_business_day | verified |
| `nt-scr-defence-after-soc-service` | Defence after service of a separate statement of claim | Supreme Court Rules 1987 (NT) r 14.04(b) | 14 calendar days | next_business_day | verified |
| `nt-scr-appeal-notice` | Notice of appeal (Court of Appeal or Full Court) where no Act fixes the period | Supreme Court Rules 1987 (NT) r 82.04(2)(b) | 28 calendar days | next_business_day | verified |

## qcat — Queensland Civil and Administrative Tribunal (pack au-qld, holidays `qld`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `qcat-review-application` | Application to review a reviewable decision (general period, subject to the enabling Act) | Queensland Civil and Administrative Tribunal Act 2009 (Qld) s 33(3) | 28 calendar days | next_business_day | verified |

## qld-courts — Supreme Court of Queensland, District Court of Queensland, Magistrates Courts of Queensland (pack au-qld, holidays `qld`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `qld-ucpr-noid-after-service` | Notice of intention to defend (with defence attached) after service of claim | Uniform Civil Procedure Rules 1999 (Qld) r 137(1) | 28 calendar days | next_business_day | verified |
| `qld-ucpr-appeal-notice` | Notice of appeal to the Court of Appeal | Uniform Civil Procedure Rules 1999 (Qld) r 748(a) | 28 calendar days | next_business_day | verified |

## sa-courts — Supreme Court of South Australia, District Court of South Australia, Magistrates Court of South Australia (pack au-sa, holidays `sa`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `sa-ucr-defence-after-service-supreme-district` | Defence to a statement of claim after service of the Claim documents (Supreme Court and District Court) | Uniform Civil Rules 2020 (SA) r 65.1(1) | 28 calendar days | next_business_day | verified |
| `sa-ucr-defence-after-service-magistrates` | Defence to a statement of claim after service of the Claim documents (Magistrates Court) | Uniform Civil Rules 2020 (SA) r 65.1(1) | 28 calendar days | next_business_day | verified |
| `sa-ucr-appeal-after-judgment` | Notice of appeal (including to the Court of Appeal) after the judgment or order appealed from, where leave is not sought | Uniform Civil Rules 2020 (SA) r 214.1(1) | 21 calendar days | next_business_day | verified |

## tas-courts — Supreme Court of Tasmania, Magistrates Court of Tasmania (pack au-tas, holidays `tas`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `tas-scr-appearance-after-service` | Notice of appearance after service of writ within Tasmania | Supreme Court Rules 2000 (Tas) r 98 | 7 calendar days | next_business_day | verified |
| `tas-scr-defence-after-appearance` | Defence to statement of claim | Supreme Court Rules 2000 (Tas) r 266(1) | 21 calendar days | next_business_day | verified |
| `tas-scr-appeal-full-court` | Notice of appeal to the Full Court from a final judgment | Supreme Court Rules 2000 (Tas) r 659 | 21 calendar days | next_business_day | verified |

## vcat — Victorian Civil and Administrative Tribunal (pack au-vic, holidays `vic`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |

## vic-courts — Supreme Court of Victoria, County Court of Victoria, Magistrates' Court of Victoria (pack au-vic, holidays `vic`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `vic-scr-appearance-after-service` | Appearance after service of writ (service in Victoria; minimum period) | Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 8.04(a)(i) | 10 calendar days | next_business_day | pending-verification |
| `vic-scr-defence-after-appearance` | Defence where the writ's indorsement of claim stands as the statement of claim | Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 14.04(a) | 30 calendar days | next_business_day | verified |

## wa-courts — Supreme Court of Western Australia, District Court of Western Australia, Magistrates Court of Western Australia (pack au-wa, holidays `wa`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `wa-rsc-appearance-after-service` | Memorandum of appearance after service of writ (service in WA less than 300 km from Perth; minimum period) | Rules of the Supreme Court 1971 (WA) O 5 r 11(1) | 10 calendar days | next_business_day | pending-verification |
| `wa-rsc-defence-after-appearance-or-soc` | Defence after the later of the time limited for appearing and service of the statement of claim | Rules of the Supreme Court 1971 (WA) O 20 r 4(1) | 14 calendar days | next_business_day | verified |
| `wa-car-appeal-after-decision` | Appeal to the Court of Appeal from a decision other than an interlocutory civil decision | Supreme Court (Court of Appeal) Rules 2005 (WA) r 26(2) | 21 calendar days | next_business_day | verified |

## hk-courts — Court of First Instance of the High Court, Court of Appeal of the High Court (pack hk, holidays `hk`)

| period_rule_id | Step | Citation | Period | Rollover | Evidence |
| --- | --- | --- | --- | --- | --- |
| `hk-rhc-aos-after-service` | Acknowledgment of service of a writ served in Hong Kong | Rules of the High Court (Cap. 4A) O 12 (period to be confirmed) | 14 calendar days | next_business_day | pending-verification |
| `hk-rhc-defence` | Defence after the time limited for acknowledging service | Rules of the High Court (Cap. 4A) O 18 r 2 (period to be confirmed) | 28 calendar days | next_business_day | pending-verification |

## Holiday tables

| table | coverage | checked | evidence |
| --- | --- | --- | --- |
| `act` | 2026-01-01 to 2027-12-31 | 2026-08-26 | verified |
| `nsw` | 2026-01-01 to 2027-12-31 | 2026-08-14 | verified |
| `nt` | 2026-01-01 to 2027-12-31 | 2026-08-26 | verified |
| `qld` | 2026-01-01 to 2027-12-31 | 2026-08-14 | verified |
| `sa` | 2026-01-01 to 2027-12-31 | 2026-08-26 | verified |
| `tas` | 2026-01-01 to 2027-12-31 | 2026-08-26 | verified |
| `vic` | 2026-01-01 to 2027-12-31 | 2026-08-14 | verified |
| `wa` | 2026-01-01 to 2027-12-31 | 2026-08-26 | verified |
| `hk` | 2026-01-01 to 2026-12-31 | 2026-11-15 | pending-verification |
