# Pack gb@0.1.0 — United Kingdom (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: none · Level: national · Locale: en-GB · Legal system: three legal systems (England and Wales, Scotland, Northern Ireland) with UK-wide statutes
- Maintainers: @agus-rachman · Last reviewed: not yet

## detection

- Names: United Kingdom, UK, Great Britain, Britain, British
- Governing-law wording: laws of the United Kingdom, UK law, United Kingdom law
- Courts and tribunals: Supreme Court of the United Kingdom, Judicial Committee of the Privy Council, Upper Tribunal, First-tier Tribunal, Employment Appeal Tribunal, Employment Tribunal, Competition Appeal Tribunal
- Identifiers: Companies House company number, VAT registration number (GB prefix)
- Other signals: Ltd / plc / LLP, £, GBP, +44, Companies House, Companies Act 2006, UK GDPR, LCIA arbitration clause (hint only: the LCIA also hears foreign-law disputes)
- Note: There is no single 'UK law' of contract, deeds, property or limitation. This pack holds only UK-wide material (company law, data protection, identifiers, sources). Always add gb-eaw, gb-sct or gb-nir when England and Wales, Scotland or Northern Ireland is identified; if only 'UK' is known and the task turns on execution, deeds, time limits or courts, ask which of the three applies.

## Sources (rank 1 = official text)

- **gb.src.legislation** — legislation.gov.uk (The National Archives).
  Source: https://www.legislation.gov.uk/ · Type: legislation, rank 1 · Note: Official revised legislation for the whole UK, including Acts of the Scottish Parliament, Senedd Cymru and Northern Ireland Assembly. Check the 'changes to legislation' banner: some revised text is not up to date.
- **gb.src.find-case-law** — Find Case Law (The National Archives).
  Source: https://caselaw.nationalarchives.gov.uk/ · Type: case-law, rank 1 · Note: Official publisher of judgments of the UK Supreme Court, Privy Council, courts of England and Wales and UK tribunals since April 2022, with earlier material.
- **gb.src.uksc** — The Supreme Court of the United Kingdom.
  Source: https://www.supremecourt.uk/ · Type: court, rank 1
- **gb.src.bailii** — British and Irish Legal Information Institute (BAILII).
  Source: https://www.bailii.org/ · Type: case-law, rank 2 · Note: Free secondary source for all UK jurisdictions, including older judgments.
- **gb.src.companies-house** — Companies House.
  Source: https://www.gov.uk/government/organisations/companies-house · Type: register, rank 1 · Note: Register of companies and LLPs for the whole UK.
- **gb.src.ico** — Information Commissioner's Office.
  Source: https://ico.org.uk/ · Type: regulator, rank 1 · Note: The Data (Use and Access) Act 2025 provides for an Information Commission to replace the ICO; confirm the current name.
- **gb.src.fca** — Financial Conduct Authority.
  Source: https://www.fca.org.uk/ · Type: regulator, rank 1
- **gb.src.cma** — Competition and Markets Authority.
  Source: https://www.gov.uk/government/organisations/competition-and-markets-authority · Type: regulator, rank 1
- **gb.src.hmrc** — HM Revenue and Customs.
  Source: https://www.gov.uk/government/organisations/hm-revenue-customs · Type: regulator, rank 1
- **gb.src.gazette** — The Gazette (London, Edinburgh and Belfast).
  Source: https://www.thegazette.co.uk/ · Type: register, rank 1 · Note: Official public record for statutory notices.
- **gb.src.law-commission** — Law Commission of England and Wales / Scottish Law Commission.
  Source: https://lawcom.gov.uk/ · Type: secondary, rank 2

## Citation

- Guide: OSCOLA: The Oxford University Standard for Citation of Legal Authorities, 5th edn, 2026 (Faculty of Law, University of Oxford (Hart Publishing)) — https://www.law.ox.ac.uk/oscola
- Note: Court documents follow the relevant court's practice directions on citing authorities; reviewer to confirm.
- **gb.cite.legislation** — Cite Acts by short title and year without a jurisdiction label, then the pinpoint (s, sch, para). Example: Companies Act 2006, s 44.
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb.cite.neutral** — Cite judgments from 2001 by neutral citation first, then the best report; no full stops in abbreviations. Example: [2025] EWHC 1383 (Admin), [2025] 1 WLR 5147.
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb.cite.reports** — Prefer the Law Reports (AC, QB or KB, Ch, Fam), then the WLR, then the All ER; square brackets where the year identifies the volume. Example: [2008] 1 AC 884.
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb.cite.si** — Cite statutory instruments by title, year and SI number. Example: Civil Procedure Rules 1998, SI 1998/3132.
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **gb.id.nino** — National Insurance number. Looks like: two letters + six digits + a suffix letter A-D, often written QQ 12 34 56 C; near 'NI number', 'NINO' or 'National Insurance'.
  Authority: Social Security Administration Act 1992; HMRC · Source: https://www.gov.uk/national-insurance/your-national-insurance-number · Status: in-force · Verified: not yet
- **gb.id.nhs** — NHS number (England, Wales and Isle of Man). Looks like: 10 digits, often written 3-3-4 (the last is a check digit); near 'NHS number'.
  Authority: NHS England · Source: https://www.nhs.uk/nhs-services/online-services/find-nhs-number/ · Status: in-force · Verified: not yet
- **gb.id.utr** — Unique Taxpayer Reference (UTR). Looks like: 10 digits, sometimes followed by K; near 'UTR' or 'tax reference'.
  Authority: HMRC · Source: https://www.gov.uk/find-utr-number · Status: in-force · Verified: not yet
- **gb.id.driving-licence** — Driving licence number (Great Britain). Looks like: 16 characters starting with five letters of the surname; near 'driving licence' or 'driver number'.
  Authority: Road Traffic Act 1988; DVLA · Source: https://www.gov.uk/view-driving-licence · Status: in-force · Verified: not yet
- **gb.id.passport** — UK passport number. Looks like: 9 digits, near 'passport'.
  Authority: HM Passport Office · Source: https://www.gov.uk/government/organisations/hm-passport-office · Status: in-force · Verified: not yet · Note: Pattern to be confirmed
- **gb.id.ch-personal-code** — Companies House personal code. Looks like: an 11-character code issued after identity verification; near 'personal code' or 'identity verification'.
  Authority: Economic Crime and Corporate Transparency Act 2023; Companies House · Source: https://www.gov.uk/government/organisations/companies-house · Status: in-force · Verified: not yet · Note: Format to be confirmed. Companies House guidance treats the code as personal to the individual
- **gb.id.share-code** — Immigration status share code or biometric residence permit number. Looks like: share code: 9 characters starting with a letter; near 'share code', 'eVisa' or 'BRP'.
  Authority: Home Office · Source: https://www.gov.uk/view-prove-immigration-status · Status: in-force · Verified: not yet · Note: Pattern to be confirmed

## identifiers.organisational — may be quoted and compared

- **gb.org.company-number** — Companies House company number. Format: 8 characters: 8 digits (England and Wales), or a prefix + 6 digits (SC Scotland, NI Northern Ireland, OC / SO / NC for LLPs).
  Authority: Companies Act 2006 s 1066 · Source: https://www.gov.uk/government/organisations/companies-house
- **gb.org.vat** — VAT registration number. Format: GB + 9 digits (XI prefix for Northern Ireland goods trade).
  Authority: Value Added Tax Act 1994 · Source: https://www.gov.uk/vat-registration
- **gb.org.frn** — FCA firm reference number (FRN). Format: 6 or 7 digits.
  Authority: Financial Services and Markets Act 2000 · Source: https://register.fca.org.uk/

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **gb.privacy.uk-gdpr** — General data protection law: the UK GDPR and the Data Protection Act 2018, applying across the UK to controllers and processors.
  Authority: UK GDPR; Data Protection Act 2018 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet
- **gb.privacy.breach** — Personal data breach: the controller notifies the regulator without undue delay and, where feasible, within 72 hours of becoming aware, unless the breach is unlikely to result in a risk to individuals; individuals are told without undue delay where the risk is high.
  Authority: UK GDPR arts 33-34 · Source: https://ico.org.uk/ · Status: in-force · Verified: not yet
- **gb.privacy.processor** — A processor notifies the controller without undue delay after becoming aware of a personal data breach.
  Authority: UK GDPR art 33(2) · Source: https://ico.org.uk/ · Status: in-force · Verified: not yet
- **gb.privacy.duaa** — The Data (Use and Access) Act 2025 amends the UK GDPR, the DPA 2018 and PECR in stages (for example a data-protection complaints procedure and recognised legitimate interests) and provides for an Information Commission.
  Authority: Data (Use and Access) Act 2025 · Source: https://www.legislation.gov.uk/ukpga/2025/18/contents · Status: in-force · Verified: not yet · Note: Commencement is staged by regulations; check which provisions are in force at the date that matters
- **gb.privacy.pecr** — The document involves electronic marketing, cookies or a communications-service security breach, which engage PECR (breach notification for service providers within 72 hours where feasible).
  Authority: Privacy and Electronic Communications (EC Directive) Regulations 2003, SI 2003/2426 · Source: https://ico.org.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb.privacy.transfers** — Personal data is transferred outside the UK; record the transfer mechanism named (adequacy regulations, the International Data Transfer Agreement or the UK Addendum).
  Authority: UK GDPR ch V · Source: https://ico.org.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk

## execution

- **gb.exec.s43-contracts** [company] — A company contract is made by the company in writing under its common seal, or on its behalf by a person acting under its authority.
  Authority: Companies Act 2006 s 43 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.exec.s44-signing** [company] — Under the law of England and Wales or Northern Ireland, a company document is executed by affixing the common seal, or by signature of two authorised signatories (directors or the secretary), or by a director in the presence of a witness who attests the signature.
  Authority: Companies Act 2006 s 44(1)-(4) · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet · Note: Scottish execution is governed by s 48 and the Requirements of Writing (Scotland) Act 1995 (see gb-sct)
- **gb.exec.s44-multiple** [company] — A person signing for more than one company signs separately in each capacity.
  Authority: Companies Act 2006 s 44(6) · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.exec.s45-seal** [company] — The company has no common seal or does not use one; a seal is optional.
  Authority: Companies Act 2006 s 45(1) · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.exec.s46-deed** [company, deed] — A company deed (England and Wales or Northern Ireland) is duly executed by the company and delivered as a deed; delivery is presumed on execution unless a contrary intention is proved.
  Authority: Companies Act 2006 s 46 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.exec.s47-attorney** [company, attorney] — A company appoints an attorney to execute deeds or other documents on its behalf by an instrument executed as a deed.
  Authority: Companies Act 2006 s 47 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb.exec.llp** [partnership] — A limited liability partnership executes a document by two members, or by one member in the presence of a witness, or under seal.
  Authority: Limited Liability Partnerships (Application of Companies Act 2006) Regulations 2009, SI 2009/1804, reg 4 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb.exec.overseas-company** [company] — An overseas company executes by its seal, by any manner permitted by the law of its place of incorporation, or by a person with express or implied authority under that law.
  Authority: Overseas Companies (Execution of Documents and Registration of Charges) Regulations 2009, SI 2009/1917 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb.exec.e-signature** [electronic] — An electronic signature is relied on; it is admissible in evidence, and the Law Commission's 2019 statement of the law treats it as capable of executing a document, including a deed, where the other formalities are met.
  Authority: Electronic Communications Act 2000 s 7; Law Commission, Electronic execution of documents (Law Com No 386, 2019) · Source: https://lawcom.gov.uk/project/electronic-execution-of-documents/ · Status: guidance · Verified: not yet · Note: The Law Commission statement concerns England and Wales; registries (HM Land Registry, Registers of Scotland) set their own acceptance rules
- **gb.exec.company-number** [company] — The company number and name in the parties clause match the signature block and the Companies House register; an SC or NI prefix shows registration in Scotland or Northern Ireland.
  Authority: Companies Act 2006 ss 1066 and 82 (trading disclosures) · Source: https://www.gov.uk/government/organisations/companies-house · Status: guidance · Verified: not yet
- **gb.exec.stamp-duty** [company, individual] — A transfer of shares on a stock transfer form may be chargeable with stamp duty within a fixed period after execution.
  Authority: Stamp Act 1891; Finance Act 1999 sch 13 · Source: https://www.gov.uk/guidance/stamp-duty-on-shares · Status: in-force · Verified: not yet · Note: Rate and period to be confirmed. Whether duty is payable is a counsel decision

## governance

- **gb.gov.s248-board-minutes** [company-board] — Minutes of all directors' meetings are recorded and kept for at least ten years.
  Authority: Companies Act 2006 s 248 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.gov.s249-evidence** [company-board] — Minutes authenticated by the chair of the meeting or of the next meeting are evidence of the proceedings.
  Authority: Companies Act 2006 s 249 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.gov.s355-records** [company-members] — Copies of members' resolutions passed otherwise than at meetings, minutes of general meetings and sole-member decisions are kept for at least ten years.
  Authority: Companies Act 2006 ss 355-357 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.gov.written-resolution** [company-members] — A private company's written resolution records circulation to every eligible member, the required majority and the lapse date (28 days from circulation unless the articles say otherwise).
  Authority: Companies Act 2006 ss 288-300 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet · Note: Sections 296-297 to be confirmed
- **gb.gov.directors-written** [company-board] — A directors' decision without a meeting follows the articles (the model articles for private companies require a unanimous decision).
  Authority: Companies (Model Articles) Regulations 2008, SI 2008/3229, sch 1 art 8 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb.gov.s177-interests** [company-board] — A director's interest in a proposed transaction is declared to the other directors before the company enters into it; an interest in an existing transaction is declared as soon as reasonably practicable.
  Authority: Companies Act 2006 ss 177 and 182 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.gov.s30-filing** [company-members] — Special resolutions and certain other resolutions are filed at Companies House within 15 days.
  Authority: Companies Act 2006 ss 29-30 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.gov.agm** [company-members] — A public company holds an AGM within six months of its accounting reference date; a private company has no statutory AGM requirement unless its articles impose one.
  Authority: Companies Act 2006 s 336 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb.gov.identity-verification** [company-board] — Directors and persons with significant control are subject to Companies House identity verification, phased in from 18 November 2025.
  Authority: Economic Crime and Corporate Transparency Act 2023; Companies Act 2006 pt 35A · Source: https://www.gov.uk/government/organisations/companies-house · Status: in-force · Verified: not yet · Note: Transition dates to be confirmed

## calendar.business_day

- **gb.cal.bd-contract** — No statutory default for 'business day' in contracts; agreements usually refer to days (other than Saturdays, Sundays and public holidays) on which banks in London (or Edinburgh or Belfast) are open.
  Authority: Contract construction (no statutory default) · Source: https://www.legislation.gov.uk/ · Status: guidance · Verified: not yet

## calendar.time_computation

- **gb.cal.no-general-rule** — There is no single UK statutory rule for counting time in contracts; court rules and the law of each of the three jurisdictions apply. Load gb-eaw, gb-sct or gb-nir.
  Authority: Interpretation Act 1978 (no general time-computation provision) · Source: https://www.legislation.gov.uk/ · Status: guidance · Verified: not yet

## calendar.holidays

- **gb.cal.bank-holidays** — Bank holidays differ between England and Wales, Scotland and Northern Ireland; some are set by the Schedule and others by royal proclamation each year.
  Authority: Banking and Financial Dealings Act 1971 s 1 and sch 1 · Source: https://www.gov.uk/bank-holidays · Status: in-force · Verified: not yet

## calendar.limitation

- **gb.cal.limitation-split** — Limitation (England and Wales, Northern Ireland) and prescription (Scotland) are separate regimes with different periods; identify which of the three applies before naming a period.
  Authority: Limitation Act 1980; Prescription and Limitation (Scotland) Act 1973; Limitation (Northern Ireland) Order 1989 · Source: https://www.legislation.gov.uk/ · Status: guidance · Verified: not yet

## courts_ai

- **gb.ai.split** — Court: UK Supreme Court, Privy Council and UK-wide tribunals. Instrument: No UK-wide instrument on court users' use of generative AI was identified (15 November 2026). No practice direction on generative AI for court users of the UK Supreme Court or UK-wide tribunals was identified. Guidance and case law in England and Wales (see gb-eaw) are the nearest reference; the person filing remains responsible for every authority cited.
  Authority: No instrument identified · Source: https://www.supremecourt.uk/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **gb.case.uksc** — UKSC → The Supreme Court (direct). Court: Supreme Court of the United Kingdom.
  Source: https://www.supremecourt.uk/ · Status: guidance · Verified: not yet · Note: Also on Find Case Law.
- **gb.case.ukpc** — UKPC → JCPC (direct). Court: Judicial Committee of the Privy Council.
  Source: https://www.jcpc.uk/ · Status: guidance · Verified: not yet
- **gb.case.ukhl** — UKHL → BAILII (direct). Court: House of Lords (to 2009).
  Source: https://www.bailii.org/ · Status: guidance · Verified: not yet · Note: Historic court; official text is on the UK Parliament site.
- **gb.case.tribunals** — UKUT, UKFTT, EAT, UKEAT, UKET, CAT → Find Case Law (direct). Court: Upper Tribunal, First-tier Tribunal, Employment Appeal Tribunal and other UK tribunals.
  Source: https://caselaw.nationalarchives.gov.uk/ · Status: guidance · Verified: not yet · Note: The chamber follows the number in brackets, for example [2024] UKUT 123 (IAC). Coverage varies by tribunal.

## terminology

- Spelling: en-GB
- Use **England and Wales / Scotland / Northern Ireland** instead of UK law (for contract, property, deeds or limitation) — Three separate legal systems.
- Use **Ltd / plc / LLP** instead of Pty Ltd / Inc / LLC — Companies Act 2006; Limited Liability Partnerships Act 2000.
- Use **solicitor / barrister (advocate in Scotland)** instead of attorney — Except 'power of attorney'.
- Use **Companies House** instead of corporate registry / ASIC — One registrar for each of England and Wales, Scotland and Northern Ireland.
- Use **VAT** instead of GST / sales tax — Value Added Tax Act 1994.
- Use **UK GDPR** instead of GDPR (alone) — The retained UK regime, distinct from the EU GDPR.
- Use **bank holiday** instead of public holiday — Dates differ between the three jurisdictions.
