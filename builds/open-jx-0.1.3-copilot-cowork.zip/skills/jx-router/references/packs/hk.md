# Pack hk@0.1.0 — Hong Kong SAR (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: none · Level: region · Locale: en-HK · Legal system: common law (Basic Law art. 8); English and Chinese texts of ordinances equally authentic
- Maintainers: @agus-rachman · Last reviewed: not yet

## detection

- Names: Hong Kong, Hong Kong SAR, HKSAR, Hong Kong Special Administrative Region
- Governing-law wording: laws of Hong Kong, laws of the Hong Kong Special Administrative Region, laws of the HKSAR, courts of Hong Kong, Hong Kong courts
- Courts and tribunals: Court of Final Appeal, Court of Appeal of the High Court, Court of First Instance of the High Court, District Court, Family Court, Lands Tribunal, Labour Tribunal, Small Claims Tribunal, Competition Tribunal, Magistrates' Courts
- Identifiers: Company Registration (CR) number, Business Registration (BR) number
- Other signals: citations to ordinances by 'Cap.' number, HK$, HKD, +852, HCA / HCMP / DCCJ action numbers, HKIAC arbitration clause (hint only: HKIAC also hears foreign-law disputes)
- Note: 'Limited' and 'HK$' alone are not enough; load this pack only with another Hong Kong signal, otherwise ask. Mainland China (PRC) law is a different jurisdiction: a PRC-law clause or a Mainland court is not a Hong Kong signal.

## Sources (rank 1 = official text)

- **hk.src.elegislation** — Hong Kong e-Legislation (Department of Justice).
  Source: https://www.elegislation.gov.hk/ · Type: legislation, rank 1 · Note: Verified copies and past versions. Ordinances are cited by chapter ('Cap.') number. English and Chinese texts are equally authentic. Reviewer to confirm the point-in-time label.
- **hk.src.lrs** — Judiciary Legal Reference System.
  Source: https://legalref.judiciary.hk/ · Type: case-law, rank 1 · Note: Official judgments of the Hong Kong courts, searchable by neutral citation.
- **hk.src.hklii** — Hong Kong Legal Information Institute (HKLII).
  Source: https://www.hklii.hk/ · Type: case-law, rank 2 · Note: Free legislation and judgments (secondary).
- **hk.src.judiciary** — Hong Kong Judiciary — practice directions.
  Source: https://www.judiciary.hk/ · Type: court, rank 1
- **hk.src.cr** — Companies Registry.
  Source: https://www.cr.gov.hk/ · Type: register, rank 1 · Note: Companies, CR numbers, e-Registry.
- **hk.src.ird** — Inland Revenue Department (Business Registration Office, Stamp Office).
  Source: https://www.ird.gov.hk/ · Type: register, rank 1 · Note: BR numbers and stamp duty.
- **hk.src.landreg** — Land Registry.
  Source: https://www.landreg.gov.hk/ · Type: register, rank 1
- **hk.src.pcpd** — Office of the Privacy Commissioner for Personal Data (PCPD).
  Source: https://www.pcpd.org.hk/ · Type: regulator, rank 1
- **hk.src.sfc** — Securities and Futures Commission.
  Source: https://www.sfc.hk/ · Type: regulator, rank 1
- **hk.src.hkma** — Hong Kong Monetary Authority.
  Source: https://www.hkma.gov.hk/ · Type: regulator, rank 1
- **hk.src.lawsoc** — The Law Society of Hong Kong.
  Source: https://www.hklawsoc.org.hk/ · Type: secondary, rank 2 · Note: Professional guidance for solicitors.

## Citation

- Guide: No official guide: university legal citation guides (OSCOLA-based), current (CUHK and HKU law libraries) — https://libguides.lib.cuhk.edu.hk/legal_citation/cases
- Note: Reviewer to confirm whether a Judiciary practice direction or a preferred guide applies to court documents.
- **hk.cite.legislation** — Cite ordinances by short title and chapter number, then pinpoint; subsidiary legislation by its own chapter (for example Cap. 4A). Example: Companies Ordinance (Cap. 622) s 127(3).
  Authority: University citation guides; e-Legislation chapter numbering · Source: https://libguides.lib.cuhk.edu.hk/legal_citation/cases · Status: guidance · Verified: not yet
- **hk.cite.neutral** — Cite judgments by neutral citation [year] court number (HKCFA, HKCA, HKCFI, HKDC, HKFC, HKLdT and others). Example: [2026] HKCFI 123 (format only).
  Authority: University citation guides; Judiciary neutral citation practice · Source: https://libguides.lib.cuhk.edu.hk/legal_citation/cases · Status: guidance · Verified: not yet · Note: Full list of court codes and start dates to be confirmed
- **hk.cite.reports** — Reported cases: Hong Kong Court of Final Appeal Reports (HKCFAR, round brackets), Hong Kong Law Reports and Digest (HKLRD) and Hong Kong Cases (HKC) (square brackets). Example: (2020) 23 HKCFAR 1; [2020] 1 HKLRD 1 (format only).
  Authority: University citation guides · Source: https://libguides.lib.cuhk.edu.hk/legal_citation/cases · Status: guidance · Verified: not yet
- **hk.cite.bilingual** — A provision may be cited in English or Chinese; where the two texts appear to differ, record the difference rather than choose between them.
  Authority: Interpretation and General Clauses Ordinance (Cap. 1) s 10B · Source: https://www.elegislation.gov.hk/hk/cap1 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation

## identifiers.personal — never reproduce values

- **hk.id.hkid** — Hong Kong Identity Card (HKID) number. Looks like: one or two letters + 6 digits + a check digit (0-9 or A) in brackets, e.g. A123456(7); near 'HKID', 'HK Identity Card' or 'ID card no.'.
  Authority: Registration of Persons Ordinance (Cap. 177); PCPD Code of Practice on the Identity Card Number and other Personal Identifiers · Source: https://www.pcpd.org.hk/ · Status: in-force · Verified: not yet · Note: The PCPD code limits when HKID numbers and copies of identity cards may be collected. Record the field, never the number.
- **hk.id.passport** — HKSAR passport number. Looks like: a letter (often H or K) + 8 digits, near 'passport'.
  Authority: Immigration Department · Source: https://www.immd.gov.hk/ · Status: in-force · Verified: not yet · Note: Pattern to be confirmed
- **hk.id.travel-permit** — Mainland travel permit or exit-entry permit number. Looks like: near 'Home Return Permit', 'Mainland Travel Permit' or 'One-way Permit'.
  Authority: Immigration Department · Source: https://www.immd.gov.hk/ · Status: in-force · Verified: not yet
- **hk.id.mpf** — MPF scheme member account number. Looks like: near 'MPF', 'member account' or 'scheme member no.'.
  Authority: Mandatory Provident Fund Schemes Ordinance (Cap. 485) · Source: https://www.mpfa.org.hk/ · Status: in-force · Verified: not yet

## identifiers.organisational — may be quoted and compared

- **hk.org.cr** — Company Registration (CR) number. Format: usually 7 digits, e.g. CR No. 1234567.
  Authority: Companies Registry · Source: https://www.cr.gov.hk/
- **hk.org.br** — Business Registration (BR) number. Format: 8 digits, often followed by a branch suffix, e.g. 12345678-000.
  Authority: Business Registration Ordinance (Cap. 310) · Source: https://www.ird.gov.hk/

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **hk.privacy.pdpo** — General privacy law: Personal Data (Privacy) Ordinance (Cap. 486) and its six Data Protection Principles; applies to public and private data users.
  Authority: Personal Data (Privacy) Ordinance (Cap. 486) Sch 1 · Source: https://www.elegislation.gov.hk/hk/cap486 · Status: in-force · Verified: not yet
- **hk.privacy.breach-voluntary** — Data breach: there is no statutory duty to notify; notification to the PCPD and to affected individuals is voluntary and follows PCPD guidance. Mandatory notification was proposed in 2020 but has not been enacted (position as at August 2026).
  Authority: PCPD Guidance on Data Breach Handling; Cap. 486 · Source: https://www.pcpd.org.hk/ · Status: guidance · Verified: not yet · Note: Check for amending legislation before relying on this entry
- **hk.privacy.s33** — Cross-border transfer: s 33 restricts transfers outside Hong Kong but has never been brought into operation; transfers are governed by the Data Protection Principles, and the PCPD's model contractual clauses (2022) are recommended, not mandatory.
  Authority: Personal Data (Privacy) Ordinance (Cap. 486) s 33 (not in operation) · Source: https://www.elegislation.gov.hk/hk/cap486 · Status: pending · Verified: not yet
- **hk.privacy.doxxing** — Disclosure of personal data without consent with intent or recklessness as to specified harm is an offence (two tiers).
  Authority: Personal Data (Privacy) Ordinance (Cap. 486) s 64 (as amended by Ord. No. 32 of 2021, from 8 October 2021) · Source: https://www.elegislation.gov.hk/hk/cap486 · Status: in-force · Verified: not yet
- **hk.privacy.hkid-code** — The document collects or copies HKID numbers or identity cards; the PCPD code sets when this is permitted, and a departure from an approved code can be used as evidence of a contravention.
  Authority: PCPD Code of Practice on the Identity Card Number and other Personal Identifiers; Cap. 486 s 13 · Source: https://www.pcpd.org.hk/ · Status: guidance · Verified: not yet
- **hk.privacy.direct-marketing** — The document involves using personal data in direct marketing, which engages the notice and consent requirements of Part 6A.
  Authority: Personal Data (Privacy) Ordinance (Cap. 486) pt 6A · Source: https://www.elegislation.gov.hk/hk/cap486 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.privacy.critical-infrastructure** — A designated critical infrastructure operator has incident-reporting duties to the Commissioner of Critical Infrastructure (Computer-system Security), separate from the PDPO (from 1 January 2026).
  Authority: Protection of Critical Infrastructures (Computer Systems) Ordinance (Cap. 653) · Source: https://www.elegislation.gov.hk/hk/cap653 · Status: in-force · Verified: not yet · Note: Reporting periods to be confirmed

## execution

- **hk.exec.seal-optional** [company] — The company has no common seal or does not use one; keeping and using a seal is optional.
  Authority: Companies Ordinance (Cap. 622) s 124(1) · Source: https://www.cr.gov.hk/en/companies_ordinance/faq_common_seal.htm · Status: in-force · Verified: not yet
- **hk.exec.s127-signing** [company] — A company document is signed by its sole director (one-director company), or by two directors or a director and the company secretary (two or more directors), and is expressed to be executed by the company; alternatively it is executed under the common seal as the articles provide.
  Authority: Companies Ordinance (Cap. 622) s 127(1)-(3), (5) · Source: https://www.cr.gov.hk/en/companies_ordinance/faq_common_seal.htm · Status: in-force · Verified: not yet
- **hk.exec.s128-deed** [company, deed] — A company deed executed without a seal is executed under s 127(3), expressed to be executed by the company as a deed, and delivered as a deed.
  Authority: Companies Ordinance (Cap. 622) s 128(1) · Source: https://www.cr.gov.hk/en/companies_ordinance/faq_common_seal.htm · Status: in-force · Verified: not yet · Note: A presumption of delivery on execution is described in commentary; section to be confirmed
- **hk.exec.s121-writing-under-seal** [company] — A contract that would need to be in writing under seal if made by an individual may be made by the company in writing executed under s 127(3) and expressed to be executed by the company.
  Authority: Companies Ordinance (Cap. 622) s 121(2)(b) · Source: https://www.cr.gov.hk/en/companies_ordinance/faq_common_seal.htm · Status: in-force · Verified: not yet
- **hk.exec.deed-individual** [individual, deed] — A deed by an individual shows signing, sealing and delivery; the CPO presumes sealing only where the instrument describes itself as a deed, states that it has been sealed and bears a mark representing a seal.
  Authority: Conveyancing and Property Ordinance (Cap. 219) ss 19-20 · Source: https://www.elegislation.gov.hk/hk/cap219 · Status: in-force · Verified: not yet · Note: Taken from commentary; reviewer to read ss 19-20 before relying on this entry
- **hk.exec.eto-schedule-1** [electronic, deed] — The document is signed electronically and may fall within ETO Schedule 1 (wills and testamentary documents, trusts, powers of attorney, instruments stampable under Cap. 117, Government leases, instruments registrable in the Land Registry, Cap. 219 assignments, mortgages and charges, oaths and affidavits, statutory declarations, judgments and orders, negotiable instruments).
  Authority: Electronic Transactions Ordinance (Cap. 553) s 3 and Sch 1 · Source: https://www.elegislation.gov.hk/hk/cap553 · Status: in-force · Verified: not yet · Note: List taken from secondary sources; confirm the current Schedule 1 text. Whether a deed outside Schedule 1 can be signed electronically is untested in the courts: record the question, give no view
- **hk.exec.e-signature** [electronic] — An electronic signature is relied on for a requirement for a signature; the ETO distinguishes electronic and digital signatures and transactions involving a government entity.
  Authority: Electronic Transactions Ordinance (Cap. 553) ss 6 and 6A · Source: https://www.elegislation.gov.hk/hk/cap553 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.exec.witness-presence** [individual, deed, electronic] — Witness boxes are completed for a remote or electronic signing; physical presence of the witness is usually assumed in practice.
  Authority: Practice commentary (no statutory rule identified) · Source: https://www.elegislation.gov.hk/hk/cap553 · Status: guidance · Verified: not yet · Note: Reviewer to confirm
- **hk.exec.registrable-charge** [company] — A company charge that is registrable with the Companies Registry is usually executed in wet ink because registrable documents are within ETO Schedule 1.
  Authority: Companies Ordinance (Cap. 622) pt 8; Cap. 553 Sch 1 · Source: https://www.cr.gov.hk/ · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.exec.poa** [attorney] — The document is signed under a power of attorney; record the instrument relied on and whether it is an enduring power.
  Authority: Powers of Attorney Ordinance (Cap. 31); Enduring Powers of Attorney Ordinance (Cap. 501) · Source: https://www.elegislation.gov.hk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.exec.stamp-duty** [company, individual] — The document may be chargeable with stamp duty (for example property or shares), within fixed periods after execution.
  Authority: Stamp Duty Ordinance (Cap. 117) · Source: https://www.ird.gov.hk/ · Status: in-force · Verified: not yet · Note: Periods to be confirmed. Whether duty is payable is a counsel decision

## governance

- **hk.gov.board-minutes** [company-board] — Minutes of directors' meetings are recorded and kept, and directors' written resolutions are recorded.
  Authority: Companies Ordinance (Cap. 622) s 481 · Source: https://www.elegislation.gov.hk/hk/cap622 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.gov.written-resolution-members** [company-members] — A members' written resolution of a private company records the circulation date, the required majority and the period within which it lapses.
  Authority: Companies Ordinance (Cap. 622) pt 12 div 1 (from s 547) · Source: https://www.elegislation.gov.hk/hk/cap622 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.gov.records** [company-members] — Records of members' resolutions and meetings are kept for the period required by the Ordinance.
  Authority: Companies Ordinance (Cap. 622) s 618 · Source: https://www.elegislation.gov.hk/hk/cap622 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.gov.agm** [company-members] — The company holds an AGM, or the minutes or resolutions show how it was dispensed with.
  Authority: Companies Ordinance (Cap. 622) ss 610-612 · Source: https://www.elegislation.gov.hk/hk/cap622 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.gov.directors-interests** [company-board] — A director's material interest in a transaction is declared to the board and recorded.
  Authority: Companies Ordinance (Cap. 622) s 536 · Source: https://www.elegislation.gov.hk/hk/cap622 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation

## calendar.business_day

- **hk.cal.bd-contract** — No statutory default for 'business day' in contracts; agreements usually refer to days (other than Saturdays, Sundays and general holidays) on which banks in Hong Kong are open.
  Authority: Contract construction (no statutory default) · Source: https://www.elegislation.gov.hk/ · Status: guidance · Verified: not yet
- **hk.cal.bd-weather** — The business-day definition addresses tropical cyclone warning signal No. 8 or above, black rainstorm warnings and 'extreme conditions' announcements; if it is silent, record the gap.
  Authority: Hong Kong contract practice · Source: https://www.hko.gov.hk/ · Status: guidance · Verified: not yet

## calendar.time_computation

- **hk.cal.igco-s71** — For periods in ordinances, the first day is excluded; where the last day falls on a general holiday (and, after the 2016 amendment, possibly a gale warning or black rainstorm warning day), the period runs to the next day that is not.
  Authority: Interpretation and General Clauses Ordinance (Cap. 1) s 71; Interpretation and General Clauses (Amendment) Ordinance 2016 (Ord. No. 18 of 2016) · Source: https://www.elegislation.gov.hk/hk/cap1 · Status: in-force · Verified: not yet · Note: Effect of the 2016 amendment on weather days to be confirmed
- **hk.cal.rhc-o3** — Time in High Court proceedings is counted under RHC O 3, which deals with periods ending on days the Registry is closed.
  Authority: Rules of the High Court (Cap. 4A) O 3 · Source: https://www.elegislation.gov.hk/hk/cap4A · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.cal.gale-warnings** — Hearings and filings may be affected when a gale or rainstorm warning is in force.
  Authority: Judicial Proceedings (Adjournment During Gale Warnings) Ordinance (Cap. 62) · Source: https://www.elegislation.gov.hk/hk/cap62 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation

## calendar.holidays

- **hk.cal.general-holidays** — General holidays are every Sunday and the days in the Schedule to the General Holidays Ordinance, with the dates published in the Gazette each year (substitutes where a holiday falls on a Sunday or another holiday).
  Authority: General Holidays Ordinance (Cap. 149) · Source: https://www.gov.hk/en/about/abouthk/holiday/ · Status: in-force · Verified: not yet
- **hk.cal.statutory-holidays** — Statutory holidays for employees are a separate, shorter list from general holidays; banks and courts follow general holidays.
  Authority: Employment Ordinance (Cap. 57) s 39 · Source: https://www.labour.gov.hk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation

## calendar.limitation

- **hk.cal.limitation** — Candidate general limitation period for contract and tort claims: 6 years from accrual, subject to the special rules below.
  Authority: Limitation Ordinance (Cap. 347) s 4(1) · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision
- **hk.cal.limitation-specialty** — Actions on a specialty (including a deed): 12 years.
  Authority: Limitation Ordinance (Cap. 347) s 4(3) · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.cal.limitation-pi** — Personal injury: 3 years from accrual or from the date of knowledge.
  Authority: Limitation Ordinance (Cap. 347) s 4A · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.cal.limitation-land** — Recovery of land: 12 years.
  Authority: Limitation Ordinance (Cap. 347) s 7 · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation
- **hk.cal.limitation-latent** — Latent damage in negligence (other than personal injury): special time limits with a longstop.
  Authority: Limitation Ordinance (Cap. 347) pt IVA · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: in-force · Verified: not yet · Note: Sections and periods to be confirmed
- **hk.cal.limitation-defamation** — Defamation: whether a shorter special period applies is to be confirmed.
  Authority: Limitation Ordinance (Cap. 347) · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: in-force · Verified: not yet · Note: To be confirmed
- **hk.cal.limitation-postponement** — Disability, fraud, concealment, mistake and acknowledgment may postpone or extend a period; record as flags, never resolve.
  Authority: Limitation Ordinance (Cap. 347) pt III · Source: https://www.elegislation.gov.hk/hk/cap347 · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed against e-Legislation

## courts_ai

- **hk.ai.judiciary-guidelines** — Court: All Hong Kong courts and tribunals. Instrument: Guidelines on the Use of Generative Artificial Intelligence for Judges and Judicial Officers and Support Staff of the Hong Kong Judiciary (July 2024). The guidelines are addressed to judges and court staff, not to court users. They warn that AI can invent cases, citations and quotations; judges may remind lawyers of their professional obligation to verify AI-assisted research and citations, and may ask litigants in person what checks they made. No Hong Kong rule restricting what court users may draft with AI was found; the user remains responsible for every authority cited.
  Authority: Judiciary Guidelines on the Use of Generative AI (July 2024) paras 7-8, 14-16 · Source: https://www.judiciary.hk/doc/en/court_services_facilities/guidelines_on_the_use_of_generative_ai.pdf · Status: guidance · Verified: not yet
- **hk.ai.court-user-guidelines** — Court: All Hong Kong courts and tribunals. Instrument: Guidelines on the use of generative AI by legal practitioners and court users (in preparation). In April 2026 the Judiciary said it was drafting guidelines for legal practitioners and court users and would consult the profession later in 2026. Check whether they have been issued before relying on the absence of a court-user rule.
  Authority: Judiciary paper to the LegCo Panel on Administration of Justice and Legal Services (reported 14 April 2026) · Source: https://www.judiciary.hk/ · Status: pending · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **hk.case.cfa** — HKCFA → Judiciary Legal Reference System (direct). Court: Court of Final Appeal.
  Source: https://legalref.judiciary.hk/ · Status: guidance · Verified: not yet · Note: Search by neutral citation.
- **hk.case.ca** — HKCA → Judiciary Legal Reference System (direct). Court: Court of Appeal of the High Court.
  Source: https://legalref.judiciary.hk/ · Status: guidance · Verified: not yet
- **hk.case.cfi** — HKCFI → Judiciary Legal Reference System (direct). Court: Court of First Instance of the High Court.
  Source: https://legalref.judiciary.hk/ · Status: guidance · Verified: not yet
- **hk.case.lower** — HKDC, HKFC, HKLdT, HKLaT → Judiciary Legal Reference System (direct). Court: District Court, Family Court, Lands Tribunal and Labour Tribunal.
  Source: https://legalref.judiciary.hk/ · Status: guidance · Verified: not yet · Note: Court codes other than HKDC and HKFC to be confirmed; publication of lower-court decisions is selective.

## terminology

- Spelling: en-HK
- Use **Ordinance (Cap. number)** instead of Act — Hong Kong primary legislation; Acts are UK or Mainland statutes.
- Use **Limited** instead of Pty Ltd / Pte. Ltd. / Inc — Companies under the Companies Ordinance (Cap. 622).
- Use **solicitor / barrister** instead of lawyer (where the role matters) / attorney — Split profession under the Legal Practitioners Ordinance (Cap. 159).
- Use **Court of First Instance (of the High Court)** instead of High Court (alone, when the level matters) — The High Court comprises the Court of Appeal and the Court of First Instance.
- Use **general holiday** instead of public holiday / bank holiday — General Holidays Ordinance (Cap. 149); statutory holidays under the Employment Ordinance are a different list.
- Use **HKSAR** instead of Hong Kong, China (in legal instruments) — Usual short form in governing-law clauses.
- Use **Lands Tribunal / Labour Tribunal** — Different tribunals with similar names; check the neutral-citation code.

## deadlines — holiday table and court computation rules

- **Holiday table `hk`** — General holidays (other than Sundays) under the General Holidays Ordinance (Cap. 149), as gazetted for 2026. Coverage 2026-01-01 to 2026-12-31; checked 2026-11-15 (pending-verification); source https://www.info.gov.hk/gia/general/202505/16/P2025051300353.htm.
  Holidays: 2026-01-01, 2026-02-17, 2026-02-18, 2026-02-19, 2026-04-03, 2026-04-04, 2026-04-06, 2026-04-07, 2026-05-01, 2026-05-25, 2026-06-19, 2026-07-01, 2026-09-26, 2026-10-01, 2026-10-19, 2026-12-25, 2026-12-26
  Caveat: Every Sunday is a general holiday; the script also treats every Saturday as a non-business day. Whether a Saturday counts depends on the rule applied; confirm.
  Caveat: The 2027 general holidays were gazetted in May 2026 and are not yet in this table.
  Contingent closure `hk.closure.typhoon-8`: tropical cyclone warning signal No. 8 or above is in force — court registries close and the governing rule may extend time to the next day the registry is open (Cap. 1 s 71; Cap. 62; RHC (Cap. 4A) O 3; in-force). Hours and provisions to be confirmed
  Contingent closure `hk.closure.black-rainstorm`: a black rainstorm warning is in force — court registries close and the governing rule may extend time to the next day the registry is open (Cap. 1 s 71; Cap. 62; RHC (Cap. 4A) O 3; in-force). Hours and provisions to be confirmed
  Contingent closure `hk.closure.extreme-conditions`: the Government announces 'extreme conditions' — court and registry operations may be suspended (Judiciary announcements; guidance). Legal effect on time limits to be confirmed
- **Rule table `hk-courts`** — Court of First Instance of the High Court, Court of Appeal of the High Court; holidays: `hk`. Seed rules for review. Every rule and provision is pending verification, so the script returns identify_only for each.
  Provision `hk-igco-s71`: Interpretation and General Clauses Ordinance (Cap. 1) s 71 (pending-verification)
  Provision `hk-rhc-o3`: Rules of the High Court (Cap. 4A) O 3 (pending-verification)
  Rule `hk-rhc-aos-after-service`: Acknowledgment of service of a writ served in Hong Kong — Rules of the High Court (Cap. 4A) O 12 (period to be confirmed); 14 calendar days, rollover next_business_day (pending-verification)
  Rule `hk-rhc-defence`: Defence after the time limited for acknowledging service — Rules of the High Court (Cap. 4A) O 18 r 2 (period to be confirmed); 28 calendar days, rollover next_business_day (pending-verification)
- Provenance: Compiled for open-jx from the Government's general holidays announcement for 2026 and e-Legislation; not yet verified by a Hong Kong-qualified reviewer, so the deadline script refuses every Hong Kong computation. @  (). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
