# Pack gb-sct@0.1.0 — Scotland (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: gb · Level: region · Locale: en-GB · Legal system: mixed (civilian and common law)
- Maintainers: @agus-rachman · Last reviewed: not yet

## detection

- Names: Scotland, Scottish, Scots law
- Governing-law wording: laws of Scotland, Scots law, law of Scotland, Scottish courts, courts of Scotland
- Courts and tribunals: Court of Session, Outer House, Inner House, High Court of Justiciary, Sheriff Appeal Court, Sheriff Court, Scottish Land Court, Lands Tribunal for Scotland
- Identifiers: SC-prefixed company number, SO-prefixed LLP number, Scottish charity number (SC0...)
- Other signals: Edinburgh, Glasgow, 'registered in Scotland', testing clause, 'IN WITNESS WHEREOF these presents', missives, pursuer / defender, LBTT
- Note: Scots law of contract, property and execution differs from English law: there are no English-style deeds and no doctrine of consideration.

## Sources (rank 1 = official text)

- **gb-sct.src.scotcourts** — Scottish Courts and Tribunals Service — judgments and rules.
  Source: https://www.scotcourts.gov.uk/ · Type: case-law, rank 1 · Note: Court of Session, High Court of Justiciary, Sheriff Appeal Court and sheriff court opinions; court rules.
- **gb-sct.src.judiciary** — Judiciary of Scotland.
  Source: https://judiciary.scot/ · Type: court, rank 1 · Note: Practice notes and judicial statements.
- **gb-sct.src.ros** — Registers of Scotland.
  Source: https://www.ros.gov.uk/ · Type: register, rank 1 · Note: Land Register of Scotland and Books of Council and Session.
- **gb-sct.src.revenue-scotland** — Revenue Scotland.
  Source: https://revenue.scot/ · Type: regulator, rank 1 · Note: Land and Buildings Transaction Tax.
- **gb-sct.src.lawscot** — Law Society of Scotland.
  Source: https://www.lawscot.org.uk/ · Type: regulator, rank 1
- **gb-sct.src.oscr** — Scottish Charity Regulator (OSCR).
  Source: https://www.oscr.org.uk/ · Type: register, rank 1

## Citation

- Inherits the citation guide of pack `gb`.
- Note: Use OSCOLA as set in the gb pack, with Scottish conventions for reports and Acts of the Scottish Parliament.
- **gb-sct.cite.asp** — Cite Acts of the Scottish Parliament with the asp number. Example: Land Registration etc. (Scotland) Act 2012 (asp 5).
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb-sct.cite.reports** — Scottish report series are cited by year without brackets (Session Cases SC, Scots Law Times SLT, Justiciary Cases JC). Example: 2024 SLT 123 (format only).
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb-sct.cite.neutral** — Neutral citations: CSOH and CSIH (Court of Session), HCJ and HCJAC (High Court of Justiciary), SAC (Sheriff Appeal Court) and SC with a court code (sheriff courts). Example: [2024] CSIH 12 (format only).
  Authority: OSCOLA 5th edn; Scottish Courts practice · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **gb-sct.id.chi** — Community Health Index (CHI) number. Looks like: 10 digits starting with the date of birth (DDMMYY); near 'CHI'.
  Authority: NHS Scotland · Source: https://www.nhsinform.scot/ · Status: in-force · Verified: not yet

## identifiers.organisational — may be quoted and compared

- **gb-sct.org.charity** — Scottish charity number. Format: SC + 6 digits, e.g. SC012345.
  Authority: Charities and Trustee Investment (Scotland) Act 2005 · Source: https://www.oscr.org.uk/
- **gb-sct.org.title-number** — Land Register of Scotland title number. Format: county letters + digits, e.g. MID12345.
  Authority: Land Registration etc. (Scotland) Act 2012 · Source: https://www.ros.gov.uk/

## execution

- **gb-sct.exec.rowsa-writing** [individual, company, trust] — Writing is required for contracts and unilateral obligations relating to interests in land, gratuitous unilateral obligations not undertaken in the course of business, trusts over the granter's own property, and wills.
  Authority: Requirements of Writing (Scotland) Act 1995 s 1(2) · Source: https://www.legislation.gov.uk/ukpga/1995/7/contents · Status: in-force · Verified: not yet
- **gb-sct.exec.rowsa-subscription** [individual, company] — A traditional document is subscribed by the granter (signed at the end of the last page); subscription alone gives formal validity.
  Authority: Requirements of Writing (Scotland) Act 1995 ss 2 and 7 · Source: https://www.legislation.gov.uk/ukpga/1995/7/contents · Status: in-force · Verified: not yet
- **gb-sct.exec.rowsa-self-proving** [individual] — A document is self-proving (probative) where the granter's subscription is attested by one witness who signs, with the witness's name and address stated in the document or testing clause.
  Authority: Requirements of Writing (Scotland) Act 1995 s 3 · Source: https://www.legislation.gov.uk/ukpga/1995/7/contents · Status: in-force · Verified: not yet
- **gb-sct.exec.rowsa-company** [company] — A company subscribes by a director, the secretary or an authorised person; the document is self-proving where that signature is witnessed, or where it is signed by two directors, a director and the secretary, or two authorised persons.
  Authority: Requirements of Writing (Scotland) Act 1995 sch 2 para 3; Companies Act 2006 s 48 · Source: https://www.legislation.gov.uk/ukpga/1995/7/contents · Status: in-force · Verified: not yet
- **gb-sct.exec.no-deed-concept** [deed] — The document uses English deed wording ('executed as a deed', 'signed, sealed and delivered'); Scots law has no equivalent category and does not require consideration, so record the wording and the signing method actually used.
  Authority: Scots common law; Requirements of Writing (Scotland) Act 1995 · Source: https://www.legislation.gov.uk/ukpga/1995/7/contents · Status: guidance · Verified: not yet
- **gb-sct.exec.counterparts** [individual, company, electronic] — The document is executed in counterpart or delivered electronically (for example a signed copy sent by email).
  Authority: Legal Writings (Counterparts and Delivery) (Scotland) Act 2015 ss 1 and 4 · Source: https://www.legislation.gov.uk/asp/2015/4/contents · Status: in-force · Verified: not yet
- **gb-sct.exec.electronic** [electronic] — An electronic document that the Act requires to be written is authenticated by an advanced electronic signature; it is self-proving only with a qualified electronic signature.
  Authority: Requirements of Writing (Scotland) Act 1995 pt 3; Electronic Documents (Scotland) Regulations 2014, SSI 2014/83 · Source: https://www.legislation.gov.uk/ukpga/1995/7/contents · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb-sct.exec.registration** [individual, company] — A document is to be registered in the Land Register or the Books of Council and Session, which generally require it to be self-proving.
  Authority: Requirements of Writing (Scotland) Act 1995 s 6; Land Registration etc. (Scotland) Act 2012 · Source: https://www.ros.gov.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb-sct.exec.poa** [attorney] — A continuing or welfare power of attorney is in writing, carries the prescribed certificate and is registered with the Public Guardian.
  Authority: Adults with Incapacity (Scotland) Act 2000 ss 15-19 · Source: https://www.legislation.gov.uk/asp/2000/4/contents · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk

## calendar.business_day

- **gb-sct.cal.bd-contract** — A business-day definition refers to London banks only; Scottish bank holidays differ (2 January, the first Monday in August, St Andrew's Day; Easter Monday is not one), so record which place the definition names.
  Authority: Banking and Financial Dealings Act 1971 sch 1 para 2 · Source: https://www.gov.uk/bank-holidays · Status: guidance · Verified: not yet

## calendar.time_computation

- **gb-sct.cal.court-rules** — Time in Court of Session and sheriff court proceedings is counted under the Rules of the Court of Session 1994 and the sheriff court rules.
  Authority: Act of Sederunt (Rules of the Court of Session 1994) 1994, SI 1994/1443 · Source: https://www.scotcourts.gov.uk/ · Status: in-force · Verified: not yet · Note: Rule numbers to be confirmed; no Scottish court-rule table is installed

## calendar.holidays

- **gb-sct.cal.holidays** — Bank holidays in Scotland: 1 and 2 January, Good Friday, the early May and spring bank holidays, the first Monday in August, St Andrew's Day (30 November), Christmas Day and Boxing Day; local holidays are set by councils and are not bank holidays.
  Authority: Banking and Financial Dealings Act 1971 sch 1 para 2; St Andrew's Day Bank Holiday (Scotland) Act 2007 · Source: https://www.gov.uk/bank-holidays · Status: in-force · Verified: not yet

## calendar.limitation

- **gb-sct.cal.prescription-short** — Candidate period: obligations under contract and to make reparation (delict) are extinguished after 5 years (short negative prescription).
  Authority: Prescription and Limitation (Scotland) Act 1973 s 6 and sch 1 · Source: https://www.legislation.gov.uk/ukpga/1973/52/contents · Status: in-force · Verified: not yet · Note: Candidate only. The Prescription (Scotland) Act 2018 changed the start date and added standstill agreements; commencement to be confirmed
- **gb-sct.cal.prescription-long** — Long negative prescription: 20 years.
  Authority: Prescription and Limitation (Scotland) Act 1973 s 7 · Source: https://www.legislation.gov.uk/ukpga/1973/52/contents · Status: in-force · Verified: not yet
- **gb-sct.cal.limitation-pi** — Personal injury actions: 3 years, with a discretion to allow a late action.
  Authority: Prescription and Limitation (Scotland) Act 1973 ss 17 and 19A · Source: https://www.legislation.gov.uk/ukpga/1973/52/contents · Status: in-force · Verified: not yet
- **gb-sct.cal.limitation-defamation** — Defamation: 1 year from first publication to the public.
  Authority: Prescription and Limitation (Scotland) Act 1973 s 18A; Defamation and Malicious Publication (Scotland) Act 2021 s 32 · Source: https://www.legislation.gov.uk/ukpga/1973/52/contents · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb-sct.cal.prescription-vs-limitation** — Prescription extinguishes the obligation; limitation bars the action. Record which the document or question concerns, never resolve it.
  Authority: Prescription and Limitation (Scotland) Act 1973 pts I and II · Source: https://www.legislation.gov.uk/ukpga/1973/52/contents · Status: guidance · Verified: not yet

## courts_ai

- **gb-sct.ai.none-identified** — Court: Court of Session, High Court of Justiciary and sheriff courts. Instrument: No practice note on court users' use of generative AI was identified (15 November 2026). No Scottish practice note for court users was identified; the Lord President has spoken publicly about AI in the courts and the Scottish Courts and Tribunals Service has an internal AI policy. Solicitors and advocates remain responsible under their professional rules for the accuracy of every authority cited. Check for a new practice note before filing.
  Authority: No instrument identified · Source: https://judiciary.scot/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **gb-sct.case.court-of-session** — CSOH, CSIH → Scottish Courts and Tribunals Service (direct). Court: Court of Session (Outer and Inner House).
  Source: https://www.scotcourts.gov.uk/ · Status: guidance · Verified: not yet
- **gb-sct.case.justiciary** — HCJ, HCJAC → Scottish Courts and Tribunals Service (direct). Court: High Court of Justiciary.
  Source: https://www.scotcourts.gov.uk/ · Status: guidance · Verified: not yet
- **gb-sct.case.sheriff** — SAC, SC EDIN, SC GLA, SC ABE, SC DUN → Scottish Courts and Tribunals Service (direct). Court: Sheriff Appeal Court and sheriff courts.
  Source: https://www.scotcourts.gov.uk/ · Status: guidance · Verified: not yet · Note: Sheriff court codes shown are examples; the full list is to be confirmed. SAC citations with (Civ) or (Crim) before the number are not parsed.

## terminology

- Spelling: en-GB
- Use **pursuer / defender** instead of claimant / defendant — Scottish civil procedure.
- Use **delict** instead of tort
- Use **prescription** instead of limitation (for extinction of obligations) — Prescription and Limitation (Scotland) Act 1973.
- Use **subscribed / self-proving (probative)** instead of executed as a deed — Requirements of Writing (Scotland) Act 1995.
- Use **missives / disposition / standard security** instead of contract for sale / transfer / mortgage — Scottish conveyancing.
- Use **interdict** instead of injunction
- Use **advocate / solicitor advocate** instead of barrister — Faculty of Advocates.
- Use **Land and Buildings Transaction Tax (LBTT)** instead of stamp duty land tax — Revenue Scotland.

## deadlines — holiday table and court computation rules

- **Holiday table `scotland`** — Bank holidays in Scotland under the Banking and Financial Dealings Act 1971 and by proclamation, with Good Friday and Christmas Day. Coverage 2026-01-01 to 2027-12-31; checked 2026-11-15 (pending-verification); source https://www.gov.uk/bank-holidays.
  Holidays: 2026-01-01, 2026-01-02, 2026-04-03, 2026-05-04, 2026-05-25, 2026-08-03, 2026-11-30, 2026-12-25, 2026-12-28, 2027-01-01, 2027-01-04, 2027-03-26, 2027-05-03, 2027-05-31, 2027-08-02, 2027-11-30, 2027-12-27, 2027-12-28
  Caveat: Local and trades holidays set by councils are not included.
  Caveat: Court holidays are set separately by the courts; confirm the court was open.
  Contingent closure `gb-sct.closure.proclamation`: a special or substitute bank holiday is appointed by royal proclamation — the day is a bank holiday and is not in this table until it is added (Banking and Financial Dealings Act 1971 s 1(2)-(3); in-force).
- Provenance: Compiled for open-jx from the Banking and Financial Dealings Act 1971; not yet verified by a reviewer. No Scottish court-rule table is installed, so the deadline script computes no Scottish date. @  (). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
