# Pack gb-nir@0.1.0 — Northern Ireland (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: gb · Level: region · Locale: en-GB · Legal system: common law
- Maintainers: @agus-rachman · Last reviewed: not yet

## detection

- Names: Northern Ireland, Northern Irish
- Governing-law wording: laws of Northern Ireland, law of Northern Ireland, Northern Ireland law, courts of Northern Ireland
- Courts and tribunals: Court of Appeal in Northern Ireland, High Court of Justice in Northern Ireland, Court of Judicature of Northern Ireland, Crown Court in Northern Ireland, county court (Northern Ireland), Industrial Tribunals (Northern Ireland)
- Identifiers: NI-prefixed company number, NC-prefixed LLP number, Northern Ireland charity number (NIC1...)
- Other signals: Belfast, BT postcode, 'registered in Northern Ireland', Order in Council citations ending '(Northern Ireland) Order'
- Note: 'Ireland' or 'Irish law' alone means the Republic of Ireland, which is a different jurisdiction with no open-jx pack; do not load this pack for it.

## Sources (rank 1 = official text)

- **gb-nir.src.judiciaryni** — Judiciary NI — judgments and practice directions.
  Source: https://www.judiciaryni.uk/ · Type: case-law, rank 1
- **gb-nir.src.courts** — Northern Ireland Courts and Tribunals Service.
  Source: https://www.justice-ni.gov.uk/topics/courts-and-tribunals · Type: court, rank 1
- **gb-nir.src.lps** — Land & Property Services (Land Registry and Registry of Deeds).
  Source: https://www.finance-ni.gov.uk/land-property-services-lps · Type: register, rank 1
- **gb-nir.src.lawsoc** — Law Society of Northern Ireland.
  Source: https://www.lawsoc-ni.org/ · Type: regulator, rank 1
- **gb-nir.src.ccni** — Charity Commission for Northern Ireland.
  Source: https://www.charitycommissionni.org.uk/ · Type: register, rank 1

## Citation

- Inherits the citation guide of pack `gb`.
- Note: Use OSCOLA as set in the gb pack, with Northern Ireland conventions for Orders in Council and Assembly Acts.
- **gb-nir.cite.order** — Cite Northern Ireland Orders in Council by title and year, with the SI number and NI number. Example: Limitation (Northern Ireland) Order 1989, SI 1989/1339 (NI 11).
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb-nir.cite.neutral** — Neutral citations: NICA (Court of Appeal), NIKB (King's Bench, NIQB before September 2022), NICh, NIFam, NIMaster, NICC and NICty. Example: [2024] NIKB 12 (format only).
  Authority: OSCOLA 5th edn; Judiciary NI practice · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **gb-nir.id.hcn** — Health and Care Number (H&C number). Looks like: 10 digits; near 'H&C number' or 'health and care number'.
  Authority: Health and Social Care Northern Ireland · Source: https://www.nidirect.gov.uk/ · Status: in-force · Verified: not yet
- **gb-nir.id.driving-licence** — Northern Ireland driving licence number. Looks like: 8 digits; near 'driving licence' or 'driver number'.
  Authority: Road Traffic (Northern Ireland) Order 1981; DVA · Source: https://www.nidirect.gov.uk/ · Status: in-force · Verified: not yet · Note: Pattern to be confirmed

## identifiers.organisational — may be quoted and compared

- **gb-nir.org.charity** — Northern Ireland charity number. Format: NIC + 6 digits, e.g. NIC100123.
  Authority: Charities Act (Northern Ireland) 2008 · Source: https://www.charitycommissionni.org.uk/

## execution

- **gb-nir.exec.deed-individual** [individual, deed] — A deed by an individual makes clear on its face that it is intended to be a deed, is signed in the presence of a witness who attests the signature, and is delivered; sealing by individuals is no longer required.
  Authority: Law Reform (Miscellaneous Provisions) (Northern Ireland) Order 2005, SI 2005/1452 (NI 7), art 3 · Source: https://www.legislation.gov.uk/nisi/2005/1452/contents · Status: in-force · Verified: not yet · Note: Article numbers to be confirmed
- **gb-nir.exec.company** [company, deed] — A company document or deed governed by Northern Ireland law follows the Companies Act 2006 ss 44 and 46 (see the gb pack).
  Authority: Companies Act 2006 ss 44 and 46 · Source: https://www.legislation.gov.uk/ukpga/2006/46/contents · Status: in-force · Verified: not yet
- **gb-nir.exec.statute-of-frauds** [individual, company] — A guarantee or a contract for the sale of land is in writing, or evidenced by a written note or memorandum, signed by the party to be charged.
  Authority: Statute of Frauds (Ireland) 1695 s 2 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet
- **gb-nir.exec.poa** [attorney, deed] — A power of attorney is executed as a deed; an enduring power of attorney follows the 1987 Order and is registered with the High Court when the donor is losing capacity.
  Authority: Powers of Attorney Act (Northern Ireland) 1971; Enduring Powers of Attorney (Northern Ireland) Order 1987 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet · Note: Commencement of the lasting power of attorney provisions of the Mental Capacity Act (Northern Ireland) 2016 to be confirmed
- **gb-nir.exec.land** [deed, electronic] — A document is to be registered in the Land Registry or the Registry of Deeds, which set their own execution and electronic-signature requirements.
  Authority: Land Registration Act (Northern Ireland) 1970 · Source: https://www.finance-ni.gov.uk/land-property-services-lps · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk

## calendar.business_day

- **gb-nir.cal.bd-contract** — A business-day definition refers to London banks only; Northern Ireland has two extra bank holidays (St Patrick's Day and the Battle of the Boyne), so record which place the definition names.
  Authority: Banking and Financial Dealings Act 1971 sch 1 para 3 · Source: https://www.gov.uk/bank-holidays · Status: guidance · Verified: not yet

## calendar.time_computation

- **gb-nir.cal.ia-1954** — For periods in Northern Ireland legislation, the day of the event from which a period runs is excluded, and a period ending on a Sunday or public holiday runs to the next day that is neither.
  Authority: Interpretation Act (Northern Ireland) 1954 s 39 · Source: https://www.legislation.gov.uk/apni/1954/33/contents · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb-nir.cal.rcj** — Time in High Court proceedings is counted under the Rules of the Court of Judicature (Northern Ireland) 1980, Order 3.
  Authority: Rules of the Court of Judicature (Northern Ireland) 1980, SR 1980/346, O 3 · Source: https://www.judiciaryni.uk/ · Status: in-force · Verified: not yet · Note: No Northern Ireland court-rule table is installed

## calendar.holidays

- **gb-nir.cal.holidays** — Bank holidays in Northern Ireland: the England and Wales days plus St Patrick's Day (17 March) and the Battle of the Boyne (12 July), with substitute days when one falls on a weekend.
  Authority: Banking and Financial Dealings Act 1971 sch 1 para 3 and proclamation · Source: https://www.gov.uk/bank-holidays · Status: in-force · Verified: not yet

## calendar.limitation

- **gb-nir.cal.limitation** — Candidate period for contract and tort claims: 6 years from accrual.
  Authority: Limitation (Northern Ireland) Order 1989, SI 1989/1339 (NI 11), arts 4 and 6 · Source: https://www.legislation.gov.uk/nisi/1989/1339/contents · Status: in-force · Verified: not yet · Note: Candidate only; article numbers to be confirmed. The applicable period is a counsel decision
- **gb-nir.cal.limitation-pi** — Personal injury: 3 years from accrual or the date of knowledge, with a discretion to disapply.
  Authority: Limitation (Northern Ireland) Order 1989 arts 7 and 50 · Source: https://www.legislation.gov.uk/nisi/1989/1339/contents · Status: in-force · Verified: not yet · Note: Article numbers to be confirmed
- **gb-nir.cal.limitation-defamation** — Defamation: 1 year, with a discretion to disapply.
  Authority: Limitation (Northern Ireland) Order 1989 art 6(2) · Source: https://www.legislation.gov.uk/nisi/1989/1339/contents · Status: in-force · Verified: not yet · Note: Article numbers to be confirmed
- **gb-nir.cal.limitation-specialty** — Actions on an instrument under seal and recovery of land: 12 years.
  Authority: Limitation (Northern Ireland) Order 1989 · Source: https://www.legislation.gov.uk/nisi/1989/1339/contents · Status: in-force · Verified: not yet · Note: Article numbers to be confirmed
- **gb-nir.cal.limitation-postponement** — Disability, fraud, concealment, mistake and acknowledgment may postpone or extend a period; record as flags, never resolve.
  Authority: Limitation (Northern Ireland) Order 1989 pt III · Source: https://www.legislation.gov.uk/nisi/1989/1339/contents · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk

## courts_ai

- **gb-nir.ai.none-identified** — Court: Court of Judicature of Northern Ireland and county courts. Instrument: No practice direction on court users' use of generative AI was identified (15 November 2026). No Northern Ireland practice direction for court users was identified. The England and Wales case law on fictitious AI-generated authorities (see gb-eaw) is likely to be cited; solicitors and barristers remain responsible for the accuracy of every authority. Check for a new practice direction before filing.
  Authority: No instrument identified · Source: https://www.judiciaryni.uk/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **gb-nir.case.court-of-appeal** — NICA → Judiciary NI (direct). Court: Court of Appeal in Northern Ireland.
  Source: https://www.judiciaryni.uk/ · Status: guidance · Verified: not yet
- **gb-nir.case.high-court** — NIKB, NIQB, NICh, NIFam, NIMaster, NIComm → Judiciary NI (direct). Court: High Court of Justice in Northern Ireland.
  Source: https://www.judiciaryni.uk/ · Status: guidance · Verified: not yet · Note: NIQB became NIKB in September 2022. Codes other than NICA, NIKB, NIQB and NICh to be confirmed.
- **gb-nir.case.other** — NICC, NICty, NIMag → Judiciary NI (direct). Court: Crown Court, county courts and magistrates' courts.
  Source: https://www.judiciaryni.uk/ · Status: guidance · Verified: not yet · Note: Publication of lower-court decisions is selective.

## terminology

- Spelling: en-GB
- Use **plaintiff / writ of summons** instead of claimant / claim form — Northern Ireland High Court procedure keeps the older terms; the CPR do not apply.
- Use **Order (Northern Ireland)** instead of Act (for Orders in Council) — Much Northern Ireland primary legislation is made by Order in Council.
- Use **Court of Judicature of Northern Ireland** instead of Supreme Court of Judicature — Renamed in 2009.
- Use **Northern Ireland** instead of Ireland / Ulster — The Republic of Ireland is a separate state and legal system.
- Use **industrial tribunal** instead of employment tribunal — Northern Ireland keeps the older name.

## deadlines — holiday table and court computation rules

- **Holiday table `northern-ireland`** — Bank holidays in Northern Ireland under the Banking and Financial Dealings Act 1971 and by proclamation, with Good Friday and Christmas Day. Coverage 2026-01-01 to 2027-12-31; checked 2026-11-15 (pending-verification); source https://www.gov.uk/bank-holidays.
  Holidays: 2026-01-01, 2026-03-17, 2026-04-03, 2026-04-06, 2026-05-04, 2026-05-25, 2026-07-13, 2026-08-31, 2026-12-25, 2026-12-28, 2027-01-01, 2027-03-17, 2027-03-26, 2027-03-29, 2027-05-03, 2027-05-31, 2027-07-12, 2027-08-30, 2027-12-27, 2027-12-28
  Caveat: The Battle of the Boyne holiday is appointed by proclamation each year; 12 July 2026 is a Sunday, so 13 July is listed.
  Caveat: Court offices also close on other days; confirm the court office was open.
  Contingent closure `gb-nir.closure.proclamation`: a special or substitute bank holiday is appointed by royal proclamation — the day is a bank holiday and is not in this table until it is added (Banking and Financial Dealings Act 1971 s 1(2)-(3); in-force).
- Provenance: Compiled for open-jx from the Banking and Financial Dealings Act 1971; not yet verified by a reviewer. No Northern Ireland court-rule table is installed, so the deadline script computes no Northern Ireland date. @  (). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
