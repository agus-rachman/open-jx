# Pack gb-eaw@0.1.0 — England and Wales (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: gb · Level: region · Locale: en-GB · Legal system: common law
- Maintainers: @agus-rachman · Last reviewed: not yet

## detection

- Names: England and Wales, England, Wales, English law, English, Welsh
- Governing-law wording: laws of England and Wales, English law, laws of England, law of England and Wales, courts of England and Wales, English courts
- Courts and tribunals: Court of Appeal (Civil Division), Court of Appeal (Criminal Division), High Court of Justice, King's Bench Division, Chancery Division, Business and Property Courts, Commercial Court, Technology and Construction Court, Administrative Court, County Court, Crown Court, Family Court, Court of Protection
- Identifiers: company number of 8 digits ('registered in England and Wales'), OC-prefixed LLP number
- Other signals: London, 'registered in England and Wales', CPR or Practice Direction references, HM Land Registry title number, 'executed as a deed'
- Note: Welsh legislation made by Senedd Cymru applies in Wales only and is published in English and Welsh, which have equal standing.

## Sources (rank 1 = official text)

- **gb-eaw.src.cpr** — Civil Procedure Rules and Practice Directions (Ministry of Justice).
  Source: https://www.justice.gov.uk/courts/procedure-rules/civil · Type: court, rank 1
- **gb-eaw.src.judiciary** — Courts and Tribunals Judiciary.
  Source: https://www.judiciary.uk/ · Type: court, rank 1 · Note: Practice directions, court guides and judicial guidance.
- **gb-eaw.src.hmlr** — HM Land Registry.
  Source: https://www.gov.uk/government/organisations/land-registry · Type: register, rank 1 · Note: Practice guides on execution of deeds and electronic signatures.
- **gb-eaw.src.law-wales** — Law Wales / Cyfraith Cymru.
  Source: https://law.gov.wales/ · Type: legislation, rank 2 · Note: Guide to Welsh law; the authoritative text is on legislation.gov.uk.
- **gb-eaw.src.sra** — Solicitors Regulation Authority.
  Source: https://www.sra.org.uk/ · Type: regulator, rank 1
- **gb-eaw.src.bsb** — Bar Standards Board.
  Source: https://www.barstandardsboard.org.uk/ · Type: regulator, rank 1
- **gb-eaw.src.cjc** — Civil Justice Council.
  Source: https://www.judiciary.uk/related-offices-and-bodies/advisory-bodies/cjc/ · Type: secondary, rank 2

## Citation

- Inherits the citation guide of pack `gb`.
- Note: Use OSCOLA as set in the gb pack. Neutral citations: UKSC, EWCA Civ, EWCA Crim, EWHC with the division in brackets after the number, EWCOP, EWFC.
- **gb-eaw.cite.ewhc-division** — High Court neutral citations carry the division or court in brackets after the number. Example: [2025] EWHC 1383 (Admin).
  Authority: OSCOLA 5th edn; Practice Direction (Judgments: Neutral Citations) [2002] 1 WLR 346 · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet
- **gb-eaw.cite.welsh** — Cite Acts of Senedd Cymru and Measures with their series abbreviation (asc, anaw, nawm). Example: Renting Homes (Wales) Act 2016 (anaw 1).
  Authority: OSCOLA 5th edn · Source: https://www.law.ox.ac.uk/oscola · Status: guidance · Verified: not yet

## identifiers.organisational — may be quoted and compared

- **gb-eaw.org.charity** — Registered charity number (England and Wales). Format: 6 or 7 digits.
  Authority: Charities Act 2011 · Source: https://www.gov.uk/government/organisations/charity-commission
- **gb-eaw.org.title-number** — HM Land Registry title number. Format: letters + digits, e.g. AB123456.
  Authority: Land Registration Act 2002 · Source: https://www.gov.uk/government/organisations/land-registry

## execution

- **gb-eaw.exec.deed-individual** [individual, deed] — A deed by an individual makes clear on its face that it is intended to be a deed, is signed in the presence of a witness who attests the signature (or at the individual's direction in the presence of two witnesses), and is delivered; no seal is needed.
  Authority: Law of Property (Miscellaneous Provisions) Act 1989 s 1 · Source: https://www.legislation.gov.uk/ukpga/1989/34/section/1 · Status: in-force · Verified: not yet
- **gb-eaw.exec.witness-presence** [individual, company, deed, electronic] — A witness box is completed for a remote or electronic signing; the Law Commission's view is that the witness is physically present when the signatory signs.
  Authority: Law Commission, Electronic execution of documents (Law Com No 386, 2019) · Source: https://lawcom.gov.uk/project/electronic-execution-of-documents/ · Status: guidance · Verified: not yet
- **gb-eaw.exec.mercury** [deed, electronic, company, individual] — Signature pages were signed separately from, or before, the final form of the document; record how the pages were attached, especially for deeds and land contracts.
  Authority: R (Mercury Tax Group Ltd) v HMRC [2008] EWHC 2721 (Admin); Law Society and CLLS guidance on virtual signings · Source: https://caselaw.nationalarchives.gov.uk/ · Status: guidance · Verified: not yet · Note: Reviewer to confirm the current Law Society practice note
- **gb-eaw.exec.land-contract** [individual, company] — A contract for the sale or other disposition of an interest in land is in writing, incorporates all expressly agreed terms in one document (or in each exchanged part) and is signed by or on behalf of each party.
  Authority: Law of Property (Miscellaneous Provisions) Act 1989 s 2 · Source: https://www.legislation.gov.uk/ukpga/1989/34/section/2 · Status: in-force · Verified: not yet
- **gb-eaw.exec.land-deed** [deed, electronic] — A conveyance of a legal estate in land is made by deed; HM Land Registry sets its own requirements for witnessed electronic signatures.
  Authority: Law of Property Act 1925 s 52; HM Land Registry Practice Guide 8 · Source: https://www.gov.uk/government/organisations/land-registry · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb-eaw.exec.guarantee** [individual, company] — A guarantee is in writing, or evidenced by a written note or memorandum, signed by the guarantor or an authorised agent.
  Authority: Statute of Frauds 1677 s 4 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet
- **gb-eaw.exec.poa** [attorney, deed] — A power of attorney is executed as a deed by the donor; a lasting power of attorney is in the prescribed form and registered before use.
  Authority: Powers of Attorney Act 1971 s 1; Mental Capacity Act 2005 ss 9-10 and sch 1 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk
- **gb-eaw.exec.corporation-aggregate** [association, deed] — A corporation that is not a Companies Act company (for example a statutory or chartered body) executes a deed under its seal attested as the Act describes, or as its constitution provides.
  Authority: Law of Property Act 1925 s 74 · Source: https://www.legislation.gov.uk/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed against legislation.gov.uk

## calendar.business_day

- **gb-eaw.cal.bd-cpr** — For service under the CPR, 'business day' means any day except Saturday, Sunday, a bank holiday, Good Friday or Christmas Day.
  Authority: CPR r 6.2(b) · Source: https://www.justice.gov.uk/courts/procedure-rules/civil · Status: in-force · Verified: not yet

## calendar.time_computation

- **gb-eaw.cal.cpr-2-8** — Periods in the CPR, practice directions and court orders are counted in clear days; in a period of 5 days or less, Saturdays, Sundays, bank holidays, Christmas Day and Good Friday do not count; where the court office is closed on the last day for doing an act there, it may be done on the next day the office is open.
  Authority: CPR r 2.8 · Source: https://www.justice.gov.uk/courts/procedure-rules/civil · Status: in-force · Verified: not yet
- **gb-eaw.cal.month** — 'Month' in a judgment, order, the CPR, a deed or a contract means a calendar month unless the context shows otherwise.
  Authority: CPR r 2.10; Law of Property Act 1925 s 61 · Source: https://www.justice.gov.uk/courts/procedure-rules/civil · Status: in-force · Verified: not yet

## calendar.holidays

- **gb-eaw.cal.holidays** — Bank holidays in England and Wales: New Year's Day, Good Friday, Easter Monday, the early May, spring and summer bank holidays, Christmas Day and Boxing Day, with substitute days when one falls on a weekend.
  Authority: Banking and Financial Dealings Act 1971 sch 1 and royal proclamation · Source: https://www.gov.uk/bank-holidays · Status: in-force · Verified: not yet

## calendar.limitation

- **gb-eaw.cal.limitation-contract** — Candidate period for simple contract claims: 6 years from accrual of the cause of action.
  Authority: Limitation Act 1980 s 5 · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision
- **gb-eaw.cal.limitation-tort** — Candidate period for tort claims: 6 years from accrual.
  Authority: Limitation Act 1980 s 2 · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet
- **gb-eaw.cal.limitation-specialty** — Actions on a specialty (including a deed): 12 years.
  Authority: Limitation Act 1980 s 8 · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet
- **gb-eaw.cal.limitation-pi** — Personal injury: 3 years from accrual or the date of knowledge, with a discretion to disapply.
  Authority: Limitation Act 1980 ss 11, 14 and 33 · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet
- **gb-eaw.cal.limitation-defamation** — Defamation and malicious falsehood: 1 year, with a discretion to disapply.
  Authority: Limitation Act 1980 ss 4A and 32A · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet
- **gb-eaw.cal.limitation-latent** — Latent damage in negligence (not personal injury): 6 years from accrual or 3 years from knowledge, with a 15-year longstop.
  Authority: Limitation Act 1980 ss 14A-14B · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet
- **gb-eaw.cal.limitation-land** — Recovery of land: 12 years.
  Authority: Limitation Act 1980 s 15 · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: in-force · Verified: not yet · Note: Registered land follows the Land Registration Act 2002 sch 6
- **gb-eaw.cal.limitation-postponement** — Disability, fraud, concealment, mistake and acknowledgment or part payment may postpone or extend a period; record as flags, never resolve.
  Authority: Limitation Act 1980 ss 28-32 · Source: https://www.legislation.gov.uk/ukpga/1980/58/contents · Status: guidance · Verified: not yet

## courts_ai

- **gb-eaw.ai.judicial-guidance** — Court: Courts and tribunals of England and Wales. Instrument: Artificial Intelligence (AI) - Guidance for Judicial Office Holders (31 October 2025). The guidance is addressed to judges and their staff, not to court users. It expects AI to appear in submissions: lawyers remain bound by their professional obligations to verify what they file, and judges may ask a litigant in person whether AI was used and what accuracy checks were made.
  Authority: AI Judicial Guidance (October 2025) · Source: https://www.judiciary.uk/guidance-and-resources/artificial-intelligence-ai-judicial-guidance-october-2025/ · Status: guidance · Verified: not yet · Note: Summary taken from the judiciary page and commentary; reviewer to read the guidance text
- **gb-eaw.ai.ayinde** — Court: High Court and all courts of England and Wales. Instrument: R (Ayinde) v London Borough of Haringey; Al-Haroun v Qatar National Bank [2025] EWHC 1383 (Admin). The Divisional Court held that lawyers who use AI for research have a professional duty to check its output against authoritative sources before it is put before the court. Citing non-existent authorities may lead to public admonition, costs or wasted costs orders, referral to the regulator, contempt proceedings or referral to the police.
  Authority: [2025] EWHC 1383 (Admin), [2025] 1 WLR 5147 · Source: https://caselaw.nationalarchives.gov.uk/ · Status: in-force · Verified: not yet · Note: Paragraph pinpoints to be confirmed
- **gb-eaw.ai.pd-57ac** — Court: Business and Property Courts of England and Wales. Instrument: CPR Practice Direction 57AC - Trial Witness Statements in the Business and Property Courts. A trial witness statement sets out only matters of fact of which the witness has personal knowledge, in the witness's own words, and is prepared in line with the Statement of Best Practice. This is not an AI rule, but AI-generated content that is not the witness's own account does not fit it: draft only from the facts the witness has supplied and add nothing. Restricted content: evidence-fabrication.
  Authority: CPR PD 57AC paras 3.1-3.2 and Appendix · Source: https://www.justice.gov.uk/courts/procedure-rules/civil · Status: in-force · Verified: not yet · Note: Paragraph pinpoints to be confirmed
- **gb-eaw.ai.cjc-final-report** — Court: Civil courts of England and Wales. Instrument: Civil Justice Council, Use of AI for the Preparation of Court Documents: Final Report (29 October 2026). Recommendations to the Civil Procedure Rule Committee, not yet rules: a declaration in a witness statement that AI used in its preparation has not generated or influenced its substantive content; a declaration in an expert report where AI use generates or influences its substantive content; no declaration for statements of case or skeleton arguments, with the responsible legal representative named; certified human translation alongside any AI translation; and a new practice direction. Check whether the CPR has been amended before relying on the absence of a declaration requirement.
  Authority: CJC Final Report (29 October 2026) recs 3, 4, 6, 8 and 9 · Source: https://www.judiciary.uk/related-offices-and-bodies/advisory-bodies/cjc/current-work/use-of-ai-in-preparing-court-documents/ · Status: pending · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **gb-eaw.case.court-of-appeal** — EWCA Civ, EWCA Crim → Find Case Law (direct). Court: Court of Appeal of England and Wales.
  Source: https://caselaw.nationalarchives.gov.uk/ · Status: guidance · Verified: not yet
- **gb-eaw.case.high-court** — EWHC → Find Case Law (direct). Court: High Court of Justice.
  Source: https://caselaw.nationalarchives.gov.uk/ · Status: guidance · Verified: not yet · Note: The division follows the number in brackets: (KB), (QB), (Ch), (Comm), (Admin), (Fam), (TCC), (Pat), (IPEC), (Admlty), (SCCO).
- **gb-eaw.case.other** — EWCOP, EWFC, EWCC, EWCR → Find Case Law (direct). Court: Court of Protection, Family Court, County Court and Crown Court.
  Source: https://caselaw.nationalarchives.gov.uk/ · Status: guidance · Verified: not yet · Note: Publication of County Court and Crown Court decisions is selective.

## terminology

- Spelling: en-GB
- Use **claimant / claim form / particulars of claim** instead of plaintiff / writ / statement of claim — Civil Procedure Rules since 1999.
- Use **King's Bench Division (KB)** instead of Queen's Bench Division (for decisions after 8 September 2022) — Neutral citations use (KB) from that date.
- Use **executed as a deed** instead of signed, sealed and delivered (for individuals) — Sealing by individuals was abolished in 1990.
- Use **Stamp Duty Land Tax (England) / Land Transaction Tax (Wales)** instead of stamp duty (on land) — Wales has had its own tax since April 2018.
- Use **Senedd Cymru** instead of Welsh Assembly — Renamed in 2020; its Acts apply in Wales only.

## deadlines — holiday table and court computation rules

- **Holiday table `england-and-wales`** — Bank holidays in England and Wales under the Banking and Financial Dealings Act 1971 and by proclamation, with Good Friday and Christmas Day. Coverage 2026-01-01 to 2027-12-31; checked 2026-11-15 (pending-verification); source https://www.gov.uk/bank-holidays.
  Holidays: 2026-01-01, 2026-04-03, 2026-04-06, 2026-05-04, 2026-05-25, 2026-08-31, 2026-12-25, 2026-12-28, 2027-01-01, 2027-03-26, 2027-03-29, 2027-05-03, 2027-05-31, 2027-08-30, 2027-12-27, 2027-12-28
  Caveat: Court offices also close on other days (for example over Christmas); confirm the court office was open.
  Contingent closure `gb-eaw.closure.proclamation`: a special or substitute bank holiday is appointed by royal proclamation — the day is a bank holiday and is not in this table until it is added (Banking and Financial Dealings Act 1971 s 1(2)-(3); in-force).
- **Rule table `eaw-courts`** — High Court of Justice, County Court, Court of Appeal (Civil Division); holidays: `england-and-wales`. Seed rules for review. Every rule and provision is pending verification, so the script returns identify_only for each. Deemed dates of service (CPR Part 6) are not modelled.
  Provision `eaw-cpr-2-8`: CPR r 2.8 (pending-verification)
  Rule `cpr-aos-after-particulars`: Acknowledgment of service — CPR r 10.3(1); 14 calendar days, rollover next_business_day (pending-verification)
  Rule `cpr-defence-after-particulars`: Defence where no acknowledgment of service is filed — CPR r 15.4(1)(a); 14 calendar days, rollover next_business_day (pending-verification)
  Rule `cpr-defence-after-aos`: Defence where an acknowledgment of service is filed — CPR r 15.4(1)(b); 28 calendar days, rollover next_business_day (pending-verification)
  Rule `cpr-appellants-notice`: Appellant's notice — CPR r 52.12(2)(b); 21 calendar days, rollover next_business_day (pending-verification)
- Provenance: Compiled for open-jx from the Banking and Financial Dealings Act 1971 and the Civil Procedure Rules; not yet verified by a reviewer, so the deadline script refuses every England and Wales computation. @  (). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
