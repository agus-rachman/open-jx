# open-jx jurisdiction index

Read this first, then read the pack file(s) for the jurisdictions you detect, parent before child.

| Pack | Jurisdiction | Parent | Level | Version | Status | Detect by | File |
| --- | --- | --- | --- | --- | --- | --- | --- |
| au | Australia (Commonwealth) | — | national | 0.1.0 | draft | Australia, Commonwealth of Australia, Australian | `references/packs/au.md` |
| au-act | Australian Capital Territory | au | territory | 0.1.0 | draft | Australian Capital Territory, ACT | `references/packs/au-act.md` |
| au-nsw | New South Wales | au | state | 0.1.0 | draft | New South Wales, NSW | `references/packs/au-nsw.md` |
| au-nt | Northern Territory | au | territory | 0.1.0 | draft | Northern Territory, NT | `references/packs/au-nt.md` |
| au-qld | Queensland | au | state | 0.1.0 | draft | Queensland, QLD, Qld | `references/packs/au-qld.md` |
| au-sa | South Australia | au | state | 0.1.0 | draft | South Australia, SA | `references/packs/au-sa.md` |
| au-tas | Tasmania | au | state | 0.1.0 | draft | Tasmania, Tasmanian, TAS | `references/packs/au-tas.md` |
| au-vic | Victoria | au | state | 0.1.0 | draft | Victoria, Victorian, VIC | `references/packs/au-vic.md` |
| au-wa | Western Australia | au | state | 0.1.0 | draft | Western Australia, WA | `references/packs/au-wa.md` |
| nz | New Zealand | — | national | 0.1.0 | draft | New Zealand, Aotearoa, NZ | `references/packs/nz.md` |
| sg | Singapore | — | national | 0.1.0 | draft | Singapore, Republic of Singapore | `references/packs/sg.md` |

Status meanings: draft = entries not yet verified by a qualified reviewer; beta = verified by one
reviewer; stable = verified by two; stale = verification out of date; unmaintained = no active maintainer.
