# Pack au-wa@0.1.0 — Western Australia (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: state · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Western Australia, WA
- Governing-law wording: laws of Western Australia, laws in force in Western Australia, courts of Western Australia
- Courts and tribunals: Supreme Court of Western Australia, District Court of Western Australia, Magistrates Court of Western Australia, State Administrative Tribunal (WA)
- Other signals: Perth, WA in an address with a four-digit postcode
- Note: 'WA' can also mean Washington (USA); require another Australian signal.

## Sources (rank 1 = official text)

- **au-wa.src.legislation** — Western Australia legislation (official).
  Source: https://www.legislation.wa.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-wa.src.1** — Supreme Court of Western Australia.
  Source: https://www.supremecourt.wa.gov.au/ · Type: court, rank 1
- **au-wa.src.2** — Government of Western Australia (RevenueWA).
  Source: https://www.wa.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-wa.cite.state-act** — Cite Western Australia Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-wa.id.driver-licence** — Western Australia driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Road Traffic (Authorisation to Drive) Act 2008 (WA) · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-wa.privacy.general-privacy** — General privacy law: Privacy and Responsible Information Sharing Act 2024 — Ministers, public entities and specified contracted service providers and subcontractors (current legislation).
  Authority: Privacy and Responsible Information Sharing Act 2024 (WA) · Source: https://www.wa.gov.au/government/privacy-and-responsible-information-sharing · Status: in-force · Verified: not yet · Note: commencement: 2026-07-01 · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-wa.privacy.health** — Health information: Privacy and Responsible Information Sharing Act 2024 — WA public health entities and specified State-service contractors (current legislation).
  Authority: Privacy and Responsible Information Sharing Act 2024 (WA) · Source: https://www.wa.gov.au/government/privacy-and-responsible-information-sharing · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-wa.privacy.breach** — Data breach notification: PRIS Act Part 2 Division 6 (enacted future legislation).
  Authority: PRIS Act Part 2 Division 6 (WA) · Source: https://www.wa.gov.au/organisation/office-of-the-information-commissioner/personal-information-collected-and-after-1-july-2026 · Status: pending from 2027-01-01 · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-wa.privacy.automated-decisions** — Automated decision-making: PRIS IPP 10 — specified significant automated decisions involving relevant post-commencement personal information (current legislation).
  Authority: PRIS IPP 10 · Source: https://www.wa.gov.au/organisation/office-of-the-information-commissioner/privacy-and-accountability-automated-decision-making · Status: in-force · Verified: not yet · Note: commencement: 2026-07-01 · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-wa.privacy.workplace** — Workplace surveillance: no dedicated regime identified in this jurisdiction (upstream as at 2026-08-14).
  Authority: Dedicated workplace-surveillance regime · Source: https://www.legislation.wa.gov.au/legislation/statutes.nsf/main_mrtitle_946_homepage.html · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-wa.exec.deed-individual** [individual, deed] — A deed by an individual shows signature and attestation by a witness; confirm whether sealing wording is needed.
  Authority: Property Law Act 1969 (WA) s 9 · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-wa.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions Act 2011 (WA) · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-wa.exec.poa** [attorney] — A party signs by an attorney; the power of attorney and its form are governed by state or territory law.
  Authority: Guardianship and Administration Act 1990 (WA) pt 9 · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet
- **au-wa.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Duties Act 2008 (WA) · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.

## governance

- **au-wa.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Act 2015 (WA) · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-wa.cal.interp** — Periods in Western Australia legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Interpretation Act 1984 (WA) s 61 · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Note: Section 61(2) also treats public service holidays and bank holidays as excluded days. · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-wa.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Rules of the Supreme Court 1971 (WA) O 3 rr 2–4 · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-wa.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Rules of the Supreme Court 1971 (WA) O 3 rr 2–4 · Source: https://www.legislation.wa.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## calendar.holidays

- **au-wa.cal.holidays** — Western Australia Day (June) and the King's Birthday (usually late September or early October) differ from other states.
  Authority: Public and Bank Holidays Act 1972 (WA) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-wa.cal.limitation** — Candidate general limitation period for contract and tort claims governed by Western Australia law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation Act 2005 (WA) s 13 · Source: https://www.legislation.wa.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-wa.ai.check-current** — Court: All Western Australia courts and SAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.supremecourt.wa.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-wa.case.court-site** — WASC, WASCA, WADC, WASAT → The court's own website (not-mapped). Court: Western Australian courts and SAT.
  Source: https://www.supremecourt.wa.gov.au/ · Status: guidance · Verified: not yet · Note: Official publisher route not yet mapped; a citation that cannot be checked at the court's publisher is reported as unverifiable, never as verified or fabricated. Contributors: map the publisher and access posture. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **SAT** instead of small claims court / administrative tribunal — Western Australia civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Duties Act 2008 (WA).

## deadlines — holiday table and court computation rules

- **Holiday table `wa`** — Western Australian public holidays under the Public and Bank Holidays Act 1972 (WA), as published by the Western Australian Government (statewide list; Perth basis for the King's Birthday holiday). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-26 (verified); source https://www.wa.gov.au/service/employment/workplace-arrangements/public-holidays-western-australia.
  Holidays: 2026-01-01, 2026-01-26, 2026-03-02, 2026-04-03, 2026-04-05, 2026-04-06, 2026-04-25, 2026-04-27, 2026-06-01, 2026-09-28, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-01, 2027-03-26, 2027-03-28, 2027-03-29, 2027-04-25, 2027-04-26, 2027-06-07, 2027-09-27, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Caveat: The King's Birthday holiday is observed in late September in Western Australia (Monday 28 September 2026; Monday 27 September 2027); the City of Karratha and Town of Port Hedland observe it instead on Monday 3 August 2026, on which date the statewide holiday does not apply in those districts, and 2027 regional dates had not been published at the checked date — confirm registry-location holidays before relying on a business-day computation.
  Caveat: Western Australia Day is Monday 1 June 2026 and Monday 7 June 2027; Labour Day is Monday 2 March 2026 and Monday 1 March 2027.
  Caveat: Anzac Day falls on Saturday 25 April 2026 with Monday 27 April 2026 an additional holiday, and on Sunday 25 April 2027 with Monday 26 April 2027 an additional holiday; Boxing Day 2026 (Saturday) is followed by Monday 28 December 2026, and Christmas Day 2027 (Saturday) and Boxing Day 2027 (Sunday) are followed by Monday 27 and Tuesday 28 December 2027, all as published.
  Caveat: Interpretation Act 1984 (WA) s 61(2) also treats public service holidays and bank holidays as excluded days; no public service holiday is listed in this table — confirm none applies to the candidate date.
  Caveat: The Government has a public holiday review under way (Department of the Premier and Cabinet); dates for 2026 and 2027 are as published on the checked date but may change if the review is implemented, and 2028 dates had not been published. Reported after the snapshot (24 September 2026 review, not yet confirmed against the Western Australian Government or legislation.wa.gov.au): the review is being implemented through the Public and Bank Holidays Amendment Bill 2025, which passed the Legislative Assembly in October 2025; its passage through the Legislative Council was not confirmed. The Bill's reported holiday changes (including moving Labour Day, Western Australia Day and the King's Birthday, and adding Easter Saturday and a Show Day) would commence on 1 January 2028, leaving the 2026 and 2027 dates in this table unaffected — verify the Bill's status and commencement before extending this table beyond 2027.
- **Rule table `wa-courts`** — Supreme Court of Western Australia, District Court of Western Australia, Magistrates Court of Western Australia; holidays: `wa`. Verified against legislation.wa.gov.au on 2026-08-26. The Rules of the Supreme Court 1971 (RSC) carry their own time rules in Order 3: r 2(1) reckons days exclusively of the first and inclusively of the last day; r 2(2) drops Central-Office-closed days from periods of less than 7 days; r 3 excludes the period between 24 December and 15 January when computing time for filing, serving or amending a pleading or for filing and serving a notice of appeal; and r 4 extends a period that expires on a day the Central Office is closed to the next day it is open (not for documents that must be filed electronically, r 4(2)). The Interpretation Act 1984 s 61 applies to the rules as a written law (s 3(1)) unless a contrary provision applies, and its rollover on 'excluded days' (Saturday, Sunday, public service holiday, bank or public holiday) is what the script models with the WA holiday table; the script approximates Central-Office-closed days with weekends and public holidays, and every computed date carries a warning to confirm the office was open. The Supreme Court (Court of Appeal) Rules 2005 must be read with the RSC (r 3(1)) and pick up RSC Order 3 other than rr 2(2) and 5(3) (r 3(4)). The period rules in this table are Supreme Court rules; the District Court Rules 2005 (consolidation 02-s0-00, current from 20 Aug 2025) and the Magistrates Court (Civil Proceedings) Rules 2005 (consolidation 04-a0-00, current from 2 Jul 2026) carry their own procedural periods and were not verified for this table. The appearance rule stays pending-verification because the operative time is the time stated in the writ itself (RSC O 5 r 11).
  Provision `wa-ia-s61`: Interpretation Act 1984 (WA) s 61 (verified)
  Provision `wa-rsc-o3-r2-r4`: Rules of the Supreme Court 1971 (WA) O 3 rr 2 and 4 (verified)
  Provision `wa-rsc-o3-r3`: Rules of the Supreme Court 1971 (WA) O 3 r 3 (verified)
  Provision `wa-car-r3`: Supreme Court (Court of Appeal) Rules 2005 (WA) r 3(1), (3) and (4) (verified)
  Rule `wa-rsc-appearance-after-service`: Memorandum of appearance after service of writ (service in WA less than 300 km from Perth; minimum period) — Rules of the Supreme Court 1971 (WA) O 5 r 11(1); 10 calendar days, rollover next_business_day (pending-verification)
  Rule `wa-rsc-defence-after-appearance-or-soc`: Defence after the later of the time limited for appearing and service of the statement of claim — Rules of the Supreme Court 1971 (WA) O 20 r 4(1); 14 calendar days, rollover next_business_day (verified)
  Rule `wa-car-appeal-after-decision`: Appeal to the Court of Appeal from a decision other than an interlocutory civil decision — Supreme Court (Court of Appeal) Rules 2005 (WA) r 26(2); 21 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
