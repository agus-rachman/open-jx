# Pack au@0.1.0 — Australia (Commonwealth) (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: none · Level: national · Locale: en-AU · Legal system: common law (federation)
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Australia, Commonwealth of Australia, Australian
- Governing-law wording: laws of Australia, laws of the Commonwealth
- Courts and tribunals: High Court of Australia, Federal Court of Australia, Federal Circuit and Family Court of Australia, Fair Work Commission, Administrative Review Tribunal
- Identifiers: ACN, ABN, ARBN, ARSN
- Other signals: Pty Ltd, AUD, A$, +61, four-digit postcode with a state abbreviation (NSW, VIC, QLD, WA, SA, TAS, ACT, NT)
- Note: Australian law is split between the Commonwealth and the states and territories. Load a state or territory pack with this one whenever one is identified.

## Sources (rank 1 = official text)

- **au.src.frl** — Federal Register of Legislation.
  Source: https://www.legislation.gov.au/ · Type: legislation, rank 1 · Note: Official register of Commonwealth Acts and legislative instruments, with point-in-time compilations. · Upstream: legal-skills@5bfb3d8 (method)
- **au.src.hca** — High Court of Australia.
  Source: https://www.hcourt.gov.au/ · Type: court, rank 1
- **au.src.fca** — Federal Court of Australia.
  Source: https://www.fedcourt.gov.au/ · Type: court, rank 1 · Note: Practice notes, rules and judgments.
- **au.src.fcfcoa** — Federal Circuit and Family Court of Australia.
  Source: https://www.fcfcoa.gov.au/ · Type: court, rank 1
- **au.src.austlii** — AustLII.
  Source: https://www.austlii.edu.au/ · Type: case-law, rank 2 · Note: Free reprints of legislation and judgments; confirm currency against the official register.
- **au.src.jade** — Jade (BarNet).
  Source: https://jade.io/ · Type: case-law, rank 2
- **au.src.asic** — Australian Securities and Investments Commission (ASIC).
  Source: https://asic.gov.au/ · Type: regulator, rank 1 · Note: Company registers, regulatory guides.
- **au.src.oaic** — Office of the Australian Information Commissioner (OAIC).
  Source: https://www.oaic.gov.au/ · Type: regulator, rank 1
- **au.src.accc** — Australian Competition and Consumer Commission (ACCC).
  Source: https://www.accc.gov.au/ · Type: regulator, rank 1
- **au.src.ato** — Australian Taxation Office (ATO).
  Source: https://www.ato.gov.au/ · Type: regulator, rank 1
- **au.src.fwo** — Fair Work Ombudsman.
  Source: https://www.fairwork.gov.au/ · Type: regulator, rank 1
- **au.src.fwc** — Fair Work Commission.
  Source: https://www.fwc.gov.au/ · Type: court, rank 1
- **au.src.apra** — Australian Prudential Regulation Authority (APRA).
  Source: https://www.apra.gov.au/ · Type: regulator, rank 1
- **au.src.austrac** — AUSTRAC.
  Source: https://www.austrac.gov.au/ · Type: regulator, rank 1
- **au.src.abr** — Australian Business Register (ABN Lookup).
  Source: https://abr.business.gov.au/ · Type: register, rank 1

## Citation

- Guide: Australian Guide to Legal Citation, 4th edition (2018) (Melbourne University Law Review Association) — https://law.unimelb.edu.au/mulr/aglc
- Note: A 5th edition is in preparation; switch when it is published and the organisation adopts it.
- **au.cite.legislation** — Cite Acts as short title, year, jurisdiction in brackets, then pinpoint with a space after the abbreviation. Example: Corporations Act 2001 (Cth) s 127(1).
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet
- **au.cite.cases-mnc** — Cite unreported or recent judgments by medium neutral citation, with a reported citation where one exists. Example: Mabo v Queensland [No 2] (1992) 175 CLR 1.
  Authority: AGLC4 ch 2 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet
- **au.cite.footnotes** — AGLC uses footnotes, not in-text author-date citation; full stop at the end of each footnote.
  Authority: AGLC4 r 1.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au.id.tfn** — Tax file number (TFN). Looks like: 8 or 9 digits, often written 123 456 789, near "TFN" or "tax file number".
  Authority: Taxation Administration Act 1953 (Cth); Privacy (Tax File Number) Rule 2015 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: Use and disclosure of TFNs is restricted by statute; record the field, never the number.
- **au.id.medicare** — Medicare card number. Looks like: 10 digits plus an individual reference number, near "Medicare".
  Authority: Health Insurance Act 1973 (Cth) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.id.ihi** — Individual healthcare identifier (IHI). Looks like: 16 digits starting 800360, near "IHI" or "healthcare identifier".
  Authority: Healthcare Identifiers Act 2010 (Cth) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.id.crn** — Centrelink customer reference number (CRN). Looks like: 9 digits and a letter, near "CRN" or "Centrelink".
  Authority: Social Security (Administration) Act 1999 (Cth) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.id.passport** — Australian passport number. Looks like: one or two letters followed by 7 digits, near "passport".
  Authority: Australian Passports Act 2005 (Cth) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.id.driver-licence** — Driver licence number (state or territory issued). Looks like: format varies by state; near "licence no", "driver licence" or "DL".
  Authority: State and territory road transport legislation · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: See the state pack for the issuing law.
- **au.id.usi** — Unique Student Identifier (USI). Looks like: 10 characters, letters and digits, near "USI".
  Authority: Student Identifiers Act 2014 (Cth) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet

## identifiers.organisational — may be quoted and compared

- **au.org.acn** — Australian Company Number (ACN). Format: 9 digits, written "ACN 123 456 789".
  Authority: Corporations Act 2001 (Cth) · Source: https://asic.gov.au/
- **au.org.abn** — Australian Business Number (ABN). Format: 11 digits, written "ABN 12 345 678 901"; for a company the last 9 digits usually equal its ACN.
  Authority: A New Tax System (Australian Business Number) Act 1999 (Cth) · Source: https://abr.business.gov.au/
- **au.org.arbn** — Australian Registered Body Number (ARBN). Format: 9 digits; used by foreign companies and registered bodies.
  Authority: Corporations Act 2001 (Cth) · Source: https://asic.gov.au/
- **au.org.arsn** — Australian Registered Scheme Number (ARSN). Format: 9 digits; managed investment schemes.
  Authority: Corporations Act 2001 (Cth) · Source: https://asic.gov.au/

## privacy_context

- **au.priv.app** — Personal information handling by most organisations with annual turnover over $3 million, and by Commonwealth agencies, is governed by the Australian Privacy Principles.
  Authority: Privacy Act 1988 (Cth) sch 1 · Source: https://www.oaic.gov.au/ · Status: in-force · Verified: not yet
- **au.priv.adm** — Privacy policies must describe certain automated decision-making that uses personal information; obligations apply from 10 December 2026.
  Authority: Privacy Act 1988 (Cth) as amended by the Privacy and Other Legislation Amendment Act 2024 (Cth) · Source: https://www.oaic.gov.au/ · Status: pending from 2026-12-10 · Verified: not yet
- **au.priv.tort** — A statutory cause of action for serious invasions of privacy exists.
  Authority: Privacy Act 1988 (Cth) sch 2 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet

## execution

- **au.exec.s127-methods** [company] — A company signature block shows signing without a common seal by two directors, by a director and a company secretary, or (for a proprietary company with a sole director who is also its sole secretary, or has no secretary) by that director.
  Authority: Corporations Act 2001 (Cth) s 127(1) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: If the block does not match a s 127 method, the document may rely on an agent or attorney instead; that is a counsel question.
- **au.exec.s127-seal** [company] — A common seal is used and its fixing is witnessed by the officers the section names.
  Authority: Corporations Act 2001 (Cth) s 127(2) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.exec.s127-deed** [company, deed] — A company executing a deed under s 127(1) or (2) has the document expressed to be executed as a deed.
  Authority: Corporations Act 2001 (Cth) s 127(3) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.exec.s129-assumptions** [company] — A counterparty may be entitled to statutory assumptions where a document appears to be executed under s 127; note which method the block shows.
  Authority: Corporations Act 2001 (Cth) s 129(5)–(6) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.exec.electronic** [company, electronic] — The document refers to electronic signing, signing on separate copies or counterparts, or electronic deeds by a company.
  Authority: Corporations Act 2001 (Cth) pt 1.2AA · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed (sections within Part 1.2AA)
- **au.exec.eta** [individual, electronic] — An electronic signature is used for a signature required by a Commonwealth law.
  Authority: Electronic Transactions Act 1999 (Cth) s 10 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: Transactions under state law fall under the state Electronic Transactions Act; see the state pack.
- **au.exec.agent** [company, attorney] — A person signs for a company as agent or under a power of attorney rather than under s 127.
  Authority: Corporations Act 2001 (Cth) s 126 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: Powers of attorney are governed by state and territory law; see the state pack.
- **au.exec.state-deeds** [individual, deed] — Deed formalities for individuals (witnessing, sealing, delivery, electronic deeds) are set by state and territory law.
  Authority: State and territory property law and electronic transactions Acts · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: Load the state or territory pack for the governing law.

## governance

- **au.gov.s251a-record** [company-board, company-members] — Minutes of meetings, and resolutions passed without a meeting, are to be recorded in the minute book within one month.
  Authority: Corporations Act 2001 (Cth) s 251A(1) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.s251a-sign** [company-board, company-members] — The draft minutes provide for signature by the chair of the meeting (or the next meeting) within a reasonable time.
  Authority: Corporations Act 2001 (Cth) s 251A(2) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.s248a-circulating** [company-board] — A directors' resolution passed without a meeting records that all directors entitled to vote signed a document containing a statement that they are in favour.
  Authority: Corporations Act 2001 (Cth) s 248A (replaceable rule) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: The company's constitution may displace or vary replaceable rules.
- **au.gov.s248b-sole** [company-board] — A sole director passes a resolution by recording it and signing the record.
  Authority: Corporations Act 2001 (Cth) s 248B · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.s248f-quorum** [company-board] — The minutes record who was present for quorum; the replaceable-rule quorum for directors' meetings is two unless the directors determine otherwise.
  Authority: Corporations Act 2001 (Cth) s 248F (replaceable rule) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.s191-interests** [company-board] — Disclosures of directors' material personal interests are recorded in the minutes.
  Authority: Corporations Act 2001 (Cth) s 191 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.s195-public** [company-board] — For a public company, the minutes show whether an interested director was present and voted on the matter.
  Authority: Corporations Act 2001 (Cth) s 195 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.s249a-members** [company-members] — A members' resolution passed without a meeting records signature by all members entitled to vote; check whether this route is available to the company type.
  Authority: Corporations Act 2001 (Cth) s 249A · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.gov.technology-meetings** [company-board, company-members] — The minutes record how the meeting was held (in person, hybrid or virtual) and the technology used.
  Authority: Corporations Act 2001 (Cth) pt 1.2AA and pt 2G.2 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed

## calendar.business_day

- **au.cal.bd-corps** — Where the Corporations Act applies, "business day" excludes Saturdays, Sundays and public or bank holidays in the place concerned.
  Authority: Corporations Act 2001 (Cth) s 9 (definition of "business day") · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet
- **au.cal.bd-contract** — If a contract does not define "Business Day" or names no city, the place whose holidays apply is unclear; the governing-law state and the place of performance may differ.
  Authority: Contract construction (no statutory default) · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet

## calendar.time_computation

- **au.cal.aia-36** — For periods in Commonwealth legislation, the trigger day is excluded and a last day on a weekend or holiday moves to the next day, subject to the section's terms.
  Authority: Acts Interpretation Act 1901 (Cth) s 36 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au.cal.fcr** — Time limits in Federal Court proceedings are counted under the Federal Court Rules.
  Authority: Federal Court Rules 2011 (Cth) r 1.61 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au.cal.art** — Applications to the Administrative Review Tribunal have their own time limits; the rule table in deadlines.yaml uses NSW holidays as its holiday basis — confirm the registry location.
  Authority: Administrative Review Tribunal Act 2024 (Cth) s 18(1); Administrative Review Tribunal Rules 2024 (Cth) r 5 · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## calendar.holidays

- **au.cal.holidays** — Public holidays are declared by each state and territory; there is no single national list in Commonwealth law.
  Authority: State and territory public holiday Acts · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: guidance · Verified: not yet

## calendar.limitation

- **au.cal.limitation** — Most limitation periods are set by state and territory Acts; see the state pack for the candidate general period.
  Authority: State and territory limitation Acts · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Note: The applicable period is a counsel decision.
- **au.cal.limitation-acl** — Candidate period for Australian Consumer Law damages claims: 6 years.
  Authority: Competition and Consumer Act 2010 (Cth) sch 2 s 236(2) · Source: https://www.legislation.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8 (pending-verification)
- **au.cal.limitation-child-abuse** — Child abuse claims: limitation periods have been removed in every jurisdiction; never state a candidate period, flag for the responsible lawyer.
  Authority: State and territory limitation Acts · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8 (pending-verification)
- **au.cal.limitation-defamation** — Defamation: a one-year period from publication applies in every jurisdiction, subject to extension; Western Australia has not enacted the Stage 1 uniform reforms (single-publication rule), the Northern Territory has.
  Authority: State and territory limitation and defamation Acts · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet · Note: Confirm the NT commencement date. · Upstream: legal-skills@5bfb3d8, checked 2026-09-24 (pending-verification)
- **au.cal.limitation-personal-injury** — Personal injury: discoverability-based and scheme-specific periods (motor accident, workers compensation) displace the general period.
  Authority: State and territory limitation and scheme Acts · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8 (pending-verification)
- **au.cal.limitation-contribution** — Contribution claims: separate periods run from judgment or settlement, not from the underlying wrong.
  Authority: State and territory limitation Acts · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8 (pending-verification)
- **au.cal.limitation-estates** — Deceased estates: survival-of-actions and family-provision periods are separate and short; flag whenever a party has died.
  Authority: State and territory succession and limitation Acts · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8 (pending-verification)
- **au.cal.limitation-postponement** — Disability, fraud and concealment: postponement and suspension provisions may extend any candidate period; record as flags, never resolve.
  Authority: State and territory limitation Acts · Source: https://www.legislation.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au.ai.fca-gpn-ai** — Court: Federal Court of Australia. Instrument: Use of Generative Artificial Intelligence Practice Note (GPN-AI), 16 April 2026. Applies to everyone who appears before or files documents with the Court. Disclosure of whether and how generative AI was used may be required by the Court, and is expected where AI was used in preparing material a witness relies on. Affidavits and witness statements must reflect the person's own knowledge; expert reports must contain the expert's own opinion. Citations, evidence, chronologies and lists of documents must be checked before filing. Suppressed, confidential, privileged and implied undertaking material must not be put into generally accessible AI tools without checking restrictions. Restricted content: affidavit-content, witness-statement-content, expert-opinion.
  Authority: GPN-AI paras 2.1, 2.3, 3.1, 4.3–4.15, 5.1 · Source: https://www.fedcourt.gov.au/law-and-practice/practice-documents/practice-notes/gpn-ai · Status: in-force · Verified: not yet
- **au.ai.fcfcoa** — Court: Federal Circuit and Family Court of Australia. Instrument: Check the Court's current practice directions and notices on generative AI. No specific rule recorded in this pack yet.
  Authority: Federal Circuit and Family Court of Australia practice directions · Source: https://www.fcfcoa.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au.case.hca** — HCA → High Court of Australia judgments (direct). Court: High Court of Australia.
  Source: https://www.hcourt.gov.au/ · Status: guidance · Verified: not yet · Note: Includes Commonwealth Law Reports volumes 1–100, so older reported HCA citations can be checked directly. · Upstream: legal-skills@5bfb3d8 (method)
- **au.case.fca** — FCA, FCAFC → Federal Court (Federal Law Search) (human-browser-only). Court: Federal Court of Australia.
  Source: https://www.fedcourt.gov.au/ · Status: guidance · Verified: not yet · Note: The site uses a bot challenge: never automate around it; give the user the manual search route or report the citation as unverifiable. · Upstream: legal-skills@5bfb3d8 (method)
- **au.case.fcfcoa** — FEDCFAMC1A, FEDCFAMC1F, FEDCFAMC2F, FEDCFAMC2G, FCCA, FAMCA, FAMCAFC → Federal Circuit and Family Court of Australia (direct). Court: Federal Circuit and Family Court of Australia (and predecessors).
  Source: https://www.fcfcoa.gov.au/ · Status: guidance · Verified: not yet · Note: Family law decisions are published under statutory anonymisation; treat the published pseudonym as the case name. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **Annexure** instead of Exhibit — Agreements commonly use Schedules and Annexures; affidavits use annexures or exhibits depending on court rules.
- Use **solicitor / barrister / legal practitioner** instead of attorney (except "power of attorney")
- Use **Pty Ltd / Ltd** instead of Inc / LLC — Proprietary and public companies under the Corporations Act 2001 (Cth).
- Use **GST** instead of sales tax / VAT — A New Tax System (Goods and Services Tax) Act 1999 (Cth).
- Use **stamp duty / transfer duty** instead of transfer tax — Imposed by each state and territory.
- Use **Australian Consumer Law (ACL)** instead of UCC / consumer protection statutes — Competition and Consumer Act 2010 (Cth) sch 2, applied as a law of each state and territory.
- Use **PPSA / PPSR** instead of UCC Article 9 financing statement — Personal Property Securities Act 2009 (Cth).
- Use **judgment** instead of judgement — Legal usage for a court decision.
- Use **organisation, licence (noun), license (verb), program** instead of organization, license (noun)

## deadlines — holiday table and court computation rules

- **Rule table `art`** — Administrative Review Tribunal; holidays: `nsw`. Verified against legislation.gov.au on 2026-08-14. Review periods for particular decisions sit in the Act conferring the reviewable decision; entries here cover only the general ART layer, which the conferring Act can displace. Migration-review periods carry mandatory non-extendable and jurisdictional warnings. The holiday_table is a placeholder the profile must confirm for the place where the act is to be done.
  Provision `aia-s36`: Acts Interpretation Act 1901 (Cth) s 36 (verified)
  Rule `art-general-review-application`: Application for review of a reviewable decision (general period, where no other Act fixes one) — Administrative Review Tribunal Rules 2024 (Cth) r 5, made for s 18(1) of the Administrative Review Tribunal Act 2024 (Cth); 28 calendar days, rollover next_business_day (verified)
  Rule `migration-judicial-review`: Judicial review of a migration decision — Migration Act 1958 (Cth) ss 477(1) and 477A(1); 35 calendar days, rollover none (verified)
- **Rule table `cth-federal-courts`** — Federal Court of Australia, Federal Circuit and Family Court of Australia (Division 2, general federal law); holidays: `nsw`. Verified against legislation.gov.au on 2026-08-14. FCR r 1.61(5) is expressed as a declared excluded range (24 December to 14 January, not counted) and r 1.61(3) as a short-period threshold: calendar-day rules of 5 days or less fail closed because they count business days only. Where rolling a last day under r 1.61(4) would enter the excluded range, the interaction with r 1.61(5) is not settled by the tables and the script refuses — the responsible lawyer resolves it. The holiday_table must match the registry in which the act is to be done; the shipped default is a placeholder the profile must confirm.
  Provision `aia-s36`: Acts Interpretation Act 1901 (Cth) s 36 (verified)
  Provision `fcr-1-61`: Federal Court Rules 2011 (Cth) r 1.61 (verified)
  Rule `fcr-defence-after-service`: Defence after service of statement of claim — Federal Court Rules 2011 (Cth) r 16.32; 28 calendar days, rollover next_business_day (verified)
  Rule `fcr-notice-of-appeal`: Notice of appeal from a Federal Court judgment (no leave path) — Federal Court Rules 2011 (Cth) r 36.03; 28 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
