# Pack au-tas@0.1.0 — Tasmania (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: state · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Tasmania, Tasmanian, TAS
- Governing-law wording: laws of Tasmania, laws in force in Tasmania, courts of Tasmania
- Courts and tribunals: Supreme Court of Tasmania, Magistrates Court of Tasmania, Tasmanian Civil and Administrative Tribunal (TASCAT)
- Other signals: Hobart, TAS in an address with a four-digit postcode

## Sources (rank 1 = official text)

- **au-tas.src.legislation** — Tasmania legislation (official).
  Source: https://www.legislation.tas.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-tas.src.1** — Supreme Court of Tasmania.
  Source: https://www.supremecourt.tas.gov.au/ · Type: court, rank 1
- **au-tas.src.2** — State Revenue Office Tasmania.
  Source: https://www.sro.tas.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-tas.cite.state-act** — Cite Tasmania Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-tas.id.driver-licence** — Tasmania driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Vehicle and Traffic Act 1999 (Tas) · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-tas.privacy.general-privacy** — General privacy law: Personal Information Protection Act 2004 — Tasmanian public sector (current legislation).
  Authority: Personal Information Protection Act 2004 (Tas) · Source: https://www.legislation.tas.gov.au/view/html/inforce/current/act-2004-046 · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-tas.privacy.breach** — Data breach notification: Public-sector security incident reporting (internal policy control).
  Authority: Public-sector security incident reporting · Source: https://www.dpac.tas.gov.au/_security/protective-security/information-security · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-tas.privacy.workplace** — Workplace surveillance: no dedicated regime identified in this jurisdiction (upstream as at 2026-08-14).
  Authority: Dedicated workplace-surveillance regime · Source: https://www.legislation.tas.gov.au/view/html/inforce/current/act-1991-021 · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-tas.exec.deed-individual** [individual, deed] — A deed by an individual shows signature and attestation; confirm whether sealing wording is needed.
  Authority: Conveyancing and Law of Property Act 1884 (Tas) s 63 · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-tas.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions Act 2000 (Tas) · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-tas.exec.poa** [attorney] — A party signs by an attorney; the power of attorney and its form are governed by state or territory law.
  Authority: Powers of Attorney Act 2000 (Tas) · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet
- **au-tas.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Duties Act 2001 (Tas) · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.

## governance

- **au-tas.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Act 1964 (Tas) · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-tas.cal.interp** — Periods in Tasmania legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Acts Interpretation Act 1931 (Tas) s 29 · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (pending-verification)
- **au-tas.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Supreme Court Rules 2000 (Tas) rr 47, 48, 50 and 51 · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Note: Rule 48 deals with the Court vacation; r 19 defines Court holidays. · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-tas.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Supreme Court Rules 2000 (Tas) rr 47, 48, 50 and 51 · Source: https://www.legislation.tas.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## calendar.holidays

- **au-tas.cal.holidays** — Royal Hobart Regatta applies in southern Tasmania and Recreation Day in the north; Eight Hours Day replaces Labour Day.
  Authority: Statutory Holidays Act 2000 (Tas) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-tas.cal.limitation** — Candidate general limitation period for contract and tort claims governed by Tasmania law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation Act 1974 (Tas) s 4 · Source: https://www.legislation.tas.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-tas.ai.check-current** — Court: All Tasmania courts and TASCAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.supremecourt.tas.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-tas.case.court-site** — TASSC, TASFC, TASCAT → The court's own website (not-mapped). Court: Tasmanian courts and TASCAT.
  Source: https://www.supremecourt.tas.gov.au/ · Status: guidance · Verified: not yet · Note: Official publisher route not yet mapped; a citation that cannot be checked at the court's publisher is reported as unverifiable, never as verified or fabricated. Contributors: map the publisher and access posture. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **TASCAT** instead of small claims court / administrative tribunal — Tasmania civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Duties Act 2001 (Tas).

## deadlines — holiday table and court computation rules

- **Holiday table `tas`** — Tasmanian public holidays under the Statutory Holidays Act 2000 (Tas), as published by WorkSafe Tasmania (statewide list plus the Hobart-area regional holidays; Hobart Principal Registry basis). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-26 (verified); source https://worksafe.tas.gov.au/topics/laws-and-compliance/public-holidays.
  Holidays: 2026-01-01, 2026-01-26, 2026-02-09, 2026-03-09, 2026-04-03, 2026-04-06, 2026-04-07, 2026-04-25, 2026-06-08, 2026-10-22, 2026-12-25, 2026-12-28, 2027-01-01, 2027-01-26, 2027-02-08, 2027-03-08, 2027-03-26, 2027-03-29, 2027-03-30, 2027-04-25, 2027-06-14, 2027-10-21, 2027-12-25, 2027-12-27, 2027-12-28
  Caveat: Supreme Court Rules 2000 (Tas) r 19 defines 'Court holidays' (New Year's Day; Good Friday, Easter Monday and Easter Tuesday; Christmas Day and the 3 days following; any other day appointed by the Chief Justice) and rr 20, 50 and 51 turn on Court holidays, not public holidays. The table lists public holidays, so it may include days the registry treats as open (unless appointed by the Chief Justice) and omits Chief Justice appointments — confirm with the registry before relying on a rollover.
  Caveat: Easter Tuesday (7 April 2026; 30 March 2027) is published as 'generally Tasmanian Public Service only' and is included because it is a Court holiday under r 19(b).
  Caveat: The Royal Hobart Regatta (9 February 2026; 8 February 2027) and the Royal Hobart Show (22 October 2026; 21 October 2027) are regional holidays for southern Tasmania and are included on a Hobart-registry basis; the Launceston and Burnie district registries observe different regional days (Launceston Cup, Royal Launceston Show, Recreation Day, Burnie Show) that are not included — confirm registry-location holidays.
  Caveat: The Devonport Cup half-day holiday and the other municipal show holidays are not included.
  Caveat: Christmas Day 2027 falls on a Saturday: both Saturday 25 December and Monday 27 December are holidays, and Boxing Day is observed on Tuesday 28 December, as published.
  Caveat: Anzac Day is not substituted when it falls on a weekend: 25 April 2026 is a Saturday and 25 April 2027 is a Sunday, with no additional holiday.
- **Rule table `tas-courts`** — Supreme Court of Tasmania, Magistrates Court of Tasmania; holidays: `tas`. Verified against legislation.tas.gov.au on 2026-08-26. The Supreme Court Rules 2000 carry their own time code in Part 4: r 47 (a period of days not expressed as clear days excludes the first day and includes the last), r 48 (the period between 23 December and 7 January is not reckoned for filing, amendment or delivery of a pleading or appearance), r 50 (periods of less than 6 days exclude Saturdays, Sundays and Court holidays) and r 51 (a period expiring on a Saturday, Sunday or Court holiday runs to the next day that is none of those). 'Court holiday' is defined by r 19 and is not the same as a public holiday; the script approximates Court holidays and registry closures with the weekend-and-public-holiday table (Hobart basis, Easter Tuesday included), and every computed date carries a warning to confirm the registry was open. Acts Interpretation Act 1931 s 29 could not be retrieved from the publisher on the checked date (the site returned 404 or 'Internal Error' for every candidate identifier) and is recorded as pending-verification; no period rule depends on it because Part 4 is self-contained. Magistrates Court (Civil Division) Rules 1998 periods are not tabled here. An entry returned to pending-verification fails closed until re-verified.
  Provision `tas-scr-pt4-time`: Supreme Court Rules 2000 (Tas) rr 47, 50 and 51 (verified)
  Provision `tas-scr-r48-vacation`: Supreme Court Rules 2000 (Tas) r 48 (verified)
  Provision `tas-aia-s29`: Acts Interpretation Act 1931 (Tas) s 29 (pending-verification)
  Rule `tas-scr-appearance-after-service`: Notice of appearance after service of writ within Tasmania — Supreme Court Rules 2000 (Tas) r 98; 7 calendar days, rollover next_business_day (verified)
  Rule `tas-scr-defence-after-appearance`: Defence to statement of claim — Supreme Court Rules 2000 (Tas) r 266(1); 21 calendar days, rollover next_business_day (verified)
  Rule `tas-scr-appeal-full-court`: Notice of appeal to the Full Court from a final judgment — Supreme Court Rules 2000 (Tas) r 659; 21 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
