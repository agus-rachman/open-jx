# Pack nz@0.1.0 — New Zealand (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: none · Level: national · Locale: en-NZ · Legal system: common law (unitary)
- Maintainers: @nz-reviewer · Last reviewed: not yet

## detection

- Names: New Zealand, Aotearoa, NZ
- Governing-law wording: laws of New Zealand, New Zealand law, courts of New Zealand
- Courts and tribunals: Supreme Court of New Zealand, Court of Appeal of New Zealand, High Court of New Zealand, District Court of New Zealand, Employment Relations Authority, Employment Court, Disputes Tribunal
- Identifiers: NZBN, NZ company number, IRD number, FSP number
- Other signals: Limited (registered under the Companies Act 1993), NZD, NZ$, +64, Auckland, Wellington, Christchurch

## Sources (rank 1 = official text)

- **nz.src.legislation** — New Zealand Legislation (Parliamentary Counsel Office).
  Source: https://www.legislation.govt.nz/ · Type: legislation, rank 1 · Note: Official versions of Acts and secondary legislation, with point-in-time versions.
- **nz.src.courts** — Courts of New Zealand.
  Source: https://www.courtsofnz.govt.nz/ · Type: court, rank 1 · Note: Judgments of senior courts, practice notes and AI guidelines.
- **nz.src.nzlii** — NZLII.
  Source: https://www.nzlii.org/ · Type: case-law, rank 2 · Note: Free reprints; confirm currency against legislation.govt.nz.
- **nz.src.companies** — Companies Office (Companies Register).
  Source: https://www.companiesoffice.govt.nz/ · Type: register, rank 1
- **nz.src.nzbn** — New Zealand Business Number register.
  Source: https://www.nzbn.govt.nz/ · Type: register, rank 1
- **nz.src.opc** — Office of the Privacy Commissioner.
  Source: https://www.privacy.org.nz/ · Type: regulator, rank 1
- **nz.src.fma** — Financial Markets Authority.
  Source: https://www.fma.govt.nz/ · Type: regulator, rank 1
- **nz.src.comcom** — Commerce Commission.
  Source: https://comcom.govt.nz/ · Type: regulator, rank 1
- **nz.src.ird** — Inland Revenue.
  Source: https://www.ird.govt.nz/ · Type: regulator, rank 1
- **nz.src.employment** — Employment New Zealand (MBIE).
  Source: https://www.employment.govt.nz/ · Type: regulator, rank 1 · Note: Includes official public holiday and anniversary day dates.
- **nz.src.linz** — Land Information New Zealand.
  Source: https://www.linz.govt.nz/ · Type: register, rank 1

## Citation

- Guide: New Zealand Law Style Guide, 3rd edition (2018) (Thomson Reuters / New Zealand Law Foundation) — https://www.lawfoundation.org.nz/style-guide/
- **nz.cite.legislation** — Cite New Zealand Acts by title and year without a jurisdiction tag, and pinpoint with "s" and a space. Example: Companies Act 1993, s 180.
  Authority: New Zealand Law Style Guide (3rd ed) ch 3 · Source: https://www.lawfoundation.org.nz/style-guide/ · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed
- **nz.cite.cases** — Cite judgments by neutral citation where available, followed by a report citation if reported. Example: [2020] NZSC 1.
  Authority: New Zealand Law Style Guide (3rd ed) ch 2 · Source: https://www.lawfoundation.org.nz/style-guide/ · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed

## identifiers.personal — never reproduce values

- **nz.id.ird** — IRD number. Looks like: 8 or 9 digits, often written 123-456-789, near "IRD" or "tax number".
  Authority: Tax Administration Act 1994 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet · Note: Tax information is subject to statutory confidentiality; record the field, never the number.
- **nz.id.nhi** — National Health Index (NHI) number. Looks like: 3 letters followed by 4 characters (for example ABC1234), near "NHI".
  Authority: Health Information Privacy Code 2020 · Source: https://www.privacy.org.nz/ · Status: in-force · Verified: not yet
- **nz.id.driver-licence** — New Zealand driver licence number. Looks like: 2 letters followed by 6 digits, near "licence number".
  Authority: Land Transport Act 1998 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet
- **nz.id.passport** — New Zealand passport number. Looks like: 2 letters followed by 6 digits, near "passport".
  Authority: Passports Act 1992 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet
- **nz.id.msd** — Ministry of Social Development client number. Looks like: 9 digits near "MSD" or "client number".
  Authority: Social Security Act 2018 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet

## identifiers.organisational — may be quoted and compared

- **nz.org.company-number** — New Zealand company number. Format: up to 7 digits, issued by the Companies Office.
  Authority: Companies Act 1993 · Source: https://www.companiesoffice.govt.nz/
- **nz.org.nzbn** — New Zealand Business Number (NZBN). Format: 13 digits, usually starting 94.
  Authority: New Zealand Business Number Act 2016 · Source: https://www.nzbn.govt.nz/
- **nz.org.fsp** — Financial Service Provider (FSP) number. Format: FSP followed by digits.
  Authority: Financial Service Providers (Registration and Dispute Resolution) Act 2008 · Source: https://www.fma.govt.nz/

## privacy_context

- **nz.priv.ipp** — Agencies handling personal information follow the information privacy principles; IPP 13 restricts how unique identifiers are assigned and used.
  Authority: Privacy Act 2020, s 22 (IPP 13) · Source: https://www.legislation.govt.nz/act/public/2020/0031/latest/ · Status: in-force · Verified: not yet
- **nz.priv.ipp3a** — An agency collecting personal information indirectly (from someone other than the individual) must take reasonable steps to tell the individual, subject to exceptions.
  Authority: Privacy Act 2020, IPP 3A (inserted by the Privacy Amendment Act 2025) · Source: https://www.legislation.govt.nz/act/public/2025/53/en/latest/ · Status: in-force · Verified: not yet · Note: In force from 1 May 2026.

## execution

- **nz.exec.s180-deed** [company, deed] — For an obligation that would need a deed if made by an individual, the company's block shows signature by two or more directors; or, if there is only one director, by that director with the signature witnessed; or by a person the constitution allows, with signatures witnessed; or by an attorney appointed under s 181.
  Authority: Companies Act 1993, s 180(1)(a) · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet
- **nz.exec.s180-writing** [company] — For an obligation that needs writing (not a deed), a person acting under the company's express or implied authority signs on its behalf.
  Authority: Companies Act 1993, s 180(1)(b) · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet
- **nz.exec.s181-attorney** [company, attorney] — A company signs by an attorney; check the block refers to a power of attorney executed as a deed.
  Authority: Companies Act 1993, s 181 · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet
- **nz.exec.pla-deed-individual** [individual, deed] — A deed by an individual is signed by the individual and witnessed by at least one person who is not a party; the witness block shows the witness's signature, name, occupation and place of residence.
  Authority: Property Law Act 2007, s 9 · Source: https://www.legislation.govt.nz/act/public/2007/0091/latest/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed (witness details and exceptions)
- **nz.exec.pla-deed-form** [deed] — The document is described as a deed on its face (for example "deed", "executed as a deed"); sealing is not needed for an individual's deed.
  Authority: Property Law Act 2007, ss 9–12 · Source: https://www.legislation.govt.nz/act/public/2007/0091/latest/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **nz.exec.electronic** [individual, company, electronic] — An electronic signature is used where the law requires a signature or witnessing.
  Authority: Contract and Commercial Law Act 2017, pt 4 · Source: https://www.legislation.govt.nz/act/public/2017/0005/latest/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed (electronic signatures and witnessing)

## governance

- **nz.gov.sch3-minutes** [company-board] — The board keeps proper minutes of all proceedings of its meetings; the draft provides for the minutes to be confirmed or signed.
  Authority: Companies Act 1993, sch 3 cl 6 · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet
- **nz.gov.sch3-unanimous** [company-board] — A board resolution in writing records signature or assent by all directors entitled to receive notice of a board meeting.
  Authority: Companies Act 1993, sch 3 cl 7 · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet · Note: The constitution may provide otherwise.
- **nz.gov.sch3-quorum** [company-board] — The minutes record who was present for quorum; unless the constitution provides otherwise, the board quorum is a majority of directors.
  Authority: Companies Act 1993, sch 3 cl 4 · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet
- **nz.gov.s189-records** [company-board, company-members] — Minutes of shareholder and director meetings, and written resolutions, form part of the company records kept at the registered office.
  Authority: Companies Act 1993, s 189 · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet
- **nz.gov.s140-interests** [company-board] — A director's disclosure of interest in a transaction is recorded, and the interests register is updated.
  Authority: Companies Act 1993, ss 140, 189(1)(c) · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **nz.gov.s122-shareholders** [company-members] — A shareholders' resolution in writing records the signatures of the required proportion of shareholders entitled to vote.
  Authority: Companies Act 1993, s 122 · Source: https://www.legislation.govt.nz/act/public/1993/0105/latest/ · Status: in-force · Verified: not yet · Note: pinpoint and thresholds to be confirmed
- **nz.gov.societies** [association] — If the governing body is an incorporated society, its meetings follow the Incorporated Societies Act 2022 and its constitution.
  Authority: Incorporated Societies Act 2022 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet

## calendar.business_day

- **nz.cal.working-day** — Many New Zealand Acts define "working day" and exclude a period over Christmas and New Year; the excluded period differs between Acts. Check the definition in the Act that sets the deadline.
  Authority: For example Companies Act 1993, s 2 (definition of "working day"); Property Law Act 2007, s 4 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **nz.cal.bd-contract** — If a contract does not define "Business Day" or names no city, regional anniversary days create uncertainty about which days count.
  Authority: Contract construction (no statutory default) · Source: https://www.employment.govt.nz/ · Status: guidance · Verified: not yet

## calendar.time_computation

- **nz.cal.legislation-act** — Periods in legislation are counted under the general time rules in the Legislation Act 2019.
  Authority: Legislation Act 2019 · Source: https://www.legislation.govt.nz/act/public/2019/0058/latest/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **nz.cal.hcr** — Time limits in High Court proceedings are counted under the High Court Rules 2016.
  Authority: High Court Rules 2016 · Source: https://www.legislation.govt.nz/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed

## calendar.holidays

- **nz.cal.holidays** — National public holidays include Waitangi Day, ANZAC Day and Te Rā Aro ki a Matariki (Matariki); Waitangi Day and ANZAC Day may be Mondayised.
  Authority: Holidays Act 2003, s 44; Te Kīngitanga o Matariki Public Holiday Act 2022 · Source: https://www.employment.govt.nz/ · Status: in-force · Verified: not yet · Note: Use the official list for the year; do not list dates from memory.
- **nz.cal.anniversary** — Each region observes its own anniversary day (for example Wellington, Auckland, Canterbury), which changes business days by region.
  Authority: Holidays Act 2003, s 44(1) · Source: https://www.employment.govt.nz/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed

## calendar.limitation

- **nz.cal.limitation** — Limitation periods for most civil claims, including the general six-year period for money claims, are in the Limitation Act 2010.
  Authority: Limitation Act 2010 · Source: https://www.legislation.govt.nz/act/public/2010/0110/latest/ · Status: in-force · Verified: not yet · Note: The applicable period is a counsel decision.

## courts_ai

- **nz.ai.guidelines-lawyers** — Court: All New Zealand courts and tribunals. Instrument: Guidelines for use of generative artificial intelligence in courts and tribunals — lawyers (Courts of New Zealand, December 2023). Lawyers remain responsible for material put before the court, must check the accuracy of AI-assisted content and citations, and must not enter suppressed, confidential or privileged information into public AI tools. Courts may ask whether and how AI was used.
  Authority: Courts of New Zealand generative AI guidelines for lawyers · Source: https://www.courtsofnz.govt.nz/ · Status: guidance · Verified: not yet
- **nz.ai.check-current** — Court: Supreme Court, Court of Appeal, High Court, District Court, Employment Court, tribunals. Instrument: Current practice notes and judicial statements on generative AI. Check for later practice notes or judgments on AI use (the Supreme Court has warned about inaccurate AI-generated material); contributors should add each instrument as its own entry.
  Authority: Courts of New Zealand practice notes · Source: https://www.courtsofnz.govt.nz/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **nz.case.courtsofnz** — NZSC, NZCA, NZHC → Courts of New Zealand judgments (direct). Court: Supreme Court, Court of Appeal and High Court of New Zealand.
  Source: https://www.courtsofnz.govt.nz/ · Status: guidance · Verified: not yet · Note: Not from upstream; open-jx seed entry. Check suppression and anonymisation notations before quoting.
- **nz.case.district** — NZDC, NZFC, NZYC → District Court of New Zealand (not-mapped). Court: District Court, Family Court and Youth Court.
  Source: https://www.districtcourts.govt.nz/ · Status: guidance · Verified: not yet · Note: Not from upstream; publication of these courts' decisions is selective and often anonymised.
- **nz.case.employment** — NZEmpC → Employment Court (not-mapped). Court: Employment Court of New Zealand.
  Source: https://www.employmentcourt.govt.nz/ · Status: guidance · Verified: not yet · Note: Not from upstream; open-jx seed entry.

## terminology

- Spelling: en-NZ
- Use **barrister and solicitor / lawyer** instead of attorney (except "power of attorney")
- Use **Limited / Ltd** instead of Pty Ltd / Inc / LLC — New Zealand companies do not use "Pty".
- Use **GST** instead of VAT / sales tax — Goods and Services Tax Act 1985.
- Use **Schedule** instead of Exhibit
- Use **PPSA / PPSR** instead of UCC Article 9 financing statement — Personal Property Securities Act 1999.
- Use **Fair Trading Act 1986 / Consumer Guarantees Act 1993** instead of Australian Consumer Law — New Zealand consumer law differs from the Australian Consumer Law.
- Use **Te Tiriti o Waitangi / Treaty of Waitangi** — Use the form the source document uses.
- Use **organisation, licence (noun), judgment** instead of organization, license (noun), judgement
