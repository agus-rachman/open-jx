# Pack sg@0.1.0 — Singapore (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: none · Level: national · Locale: en-SG · Legal system: common law
- Maintainers: @agus-rachman · Last reviewed: not yet

## detection

- Names: Singapore, Republic of Singapore
- Governing-law wording: laws of Singapore, laws of the Republic of Singapore, courts of Singapore
- Courts and tribunals: Court of Appeal of the Republic of Singapore, Appellate Division of the High Court, General Division of the High Court, Singapore International Commercial Court (SICC), State Courts of Singapore (District Court, Magistrates' Court), Family Justice Courts, Small Claims Tribunals, Employment Claims Tribunals
- Identifiers: UEN, GST registration number
- Other signals: Pte. Ltd., SGD, S$, +65, six-digit postal code, SIAC arbitration clause (hint only: SIAC also hears foreign-law disputes)
- Note: 'SG' alone is ambiguous; load this pack only with another Singapore signal, otherwise ask.

## Sources (rank 1 = official text)

- **sg.src.sso** — Singapore Statutes Online (Attorney-General's Chambers).
  Source: https://sso.agc.gov.sg/ · Type: legislation, rank 1 · Note: Official text with point-in-time view. Acts are cited by year of enactment since the 2020 Revised Edition. Reviewer to confirm the point-in-time label.
- **sg.src.judgments** — Singapore Courts — judgments.
  Source: https://www.judiciary.gov.sg/judgments · Type: case-law, rank 1 · Note: Free judgments of the Supreme Court and State Courts.
- **sg.src.elitigation** — eLitigation GD Viewer.
  Source: https://www.elitigation.sg/ · Type: case-law, rank 1 · Note: Named in the courts' generative AI Guide as a verification source.
- **sg.src.lawnet** — LawNet (Singapore Academy of Law).
  Source: https://www.lawnet.sg/ · Type: case-law, rank 2 · Note: Subscription; Singapore Law Reports.
- **sg.src.slw** — Singapore Law Watch.
  Source: https://www.singaporelawwatch.sg/ · Type: secondary, rank 2
- **sg.src.acra** — Accounting and Corporate Regulatory Authority (ACRA).
  Source: https://www.acra.gov.sg/ · Type: register, rank 1 · Note: Companies, UEN, BizFile+.
- **sg.src.pdpc** — Personal Data Protection Commission (PDPC).
  Source: https://www.pdpc.gov.sg/ · Type: regulator, rank 1
- **sg.src.mas** — Monetary Authority of Singapore (MAS).
  Source: https://www.mas.gov.sg/ · Type: regulator, rank 1
- **sg.src.iras** — Inland Revenue Authority of Singapore (IRAS).
  Source: https://www.iras.gov.sg/ · Type: regulator, rank 1 · Note: Tax, GST and stamp duty.
- **sg.src.mom** — Ministry of Manpower (MOM).
  Source: https://www.mom.gov.sg/ · Type: regulator, rank 1 · Note: Employment; official public holiday list.
- **sg.src.cccs** — Competition and Consumer Commission of Singapore (CCCS).
  Source: https://www.cccs.gov.sg/ · Type: regulator, rank 1

## Citation

- Guide: Singapore Law Reports Style Guide, 2021 (Academy Publishing (Singapore Academy of Law)) — https://libguides.nus.edu.sg/Singaporelaw/citations
- Note: Recommended by NUS Libraries for current Singapore materials; reviewer to confirm the guide practitioners use in court documents.
- **sg.cite.legislation** — Cite Acts by name and year of enactment, then pinpoint; pre-2021 material may use the chapter and revised edition. Example: Companies Act 1967 s 41B.
  Authority: SLR Style Guide 2021 · Source: https://libguides.nus.edu.sg/Singaporelaw/citations · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed
- **sg.cite.neutral** — Cite judgments by neutral citation [year] court number; court identifiers may carry a bracketed suffix. Example: [2026] SGHC(A) 9.
  Authority: SLR Style Guide 2021 · Source: https://libguides.nus.edu.sg/Singaporelaw/citations · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed
- **sg.cite.reports** — Reported cases use the Singapore Law Reports (SLR) from 2010 and the reissue series SLR(R) for 1965 to 2009. Example: [2020] 2 SLR 1151.
  Authority: SLR Style Guide 2021 · Source: https://libguides.nus.edu.sg/Singaporelaw/citations · Status: guidance · Verified: not yet · Note: Year boundaries to be confirmed

## identifiers.personal — never reproduce values

- **sg.id.nric** — NRIC number. Looks like: a letter (S or T) + 7 digits + check letter, near 'NRIC' or 'IC no.'.
  Authority: PDPC Advisory Guidelines on the PDPA for NRIC and other national identification numbers (from 1 September 2019); National Registration Act 1965 · Source: https://www.pdpc.gov.sg/ · Status: in-force · Verified: not yet · Note: Organisations are generally barred from collecting, using or disclosing NRIC numbers unless required by law or needed to establish identity to a high degree of fidelity. Record the field, never the number.
- **sg.id.fin** — Foreign identification number (FIN). Looks like: a letter (F, G or M) + 7 digits + check letter, near 'FIN'.
  Authority: PDPC Advisory Guidelines on NRIC and other national identification numbers · Source: https://www.pdpc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.id.work-pass** — Work pass number. Looks like: format varies by pass type; near 'work permit' or 'pass no.'.
  Authority: Employment of Foreign Manpower Act 1990 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.id.passport** — Singapore passport number. Looks like: a letter + 7 digits + a letter, near 'passport'.
  Authority: Passports Act 2007 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: Pattern to be confirmed
- **sg.id.birth-cert** — Birth certificate number. Looks like: near 'birth certificate no.'.
  Authority: Registration of Births and Deaths Act 2021 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet

## identifiers.organisational — may be quoted and compared

- **sg.org.uen** — Unique Entity Number (UEN). Format: 9 or 10 characters, e.g. 201912345K (local companies: year + 5 digits + check letter).
  Authority: ACRA · Source: https://www.acra.gov.sg/
- **sg.org.gst** — GST registration number. Format: usually the UEN, or an M-prefixed number.
  Authority: Goods and Services Tax Act 1993 · Source: https://www.iras.gov.sg/

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **sg.privacy.pdpa** — General privacy law: Personal Data Protection Act 2012 — private-sector organisations collecting, using or disclosing personal data in Singapore.
  Authority: Personal Data Protection Act 2012 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.privacy.breach** — Data breach notification: once there are credible grounds to believe a breach occurred, the organisation assesses whether it is notifiable (significant harm or significant scale); PDPC is notified within 3 calendar days of that determination and affected individuals at the same time or after.
  Authority: Personal Data Protection Act 2012 pt 6A, s 26D(1)–(2) (from 1 February 2021) · Source: https://www.pdpc.gov.sg/ · Status: in-force · Verified: not yet · Note: Significant-scale threshold (believed to be 500 individuals) and assessment timing to be confirmed in the PDP (Notification of Data Breaches) Regulations 2021
- **sg.privacy.intermediary** — A data intermediary notifies the organisation it processes for without undue delay after credible grounds to believe a breach occurred.
  Authority: Personal Data Protection Act 2012 s 26C(3)(a) · Source: https://www.pdpc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.privacy.nric** — The document collects, uses or discloses NRIC numbers or retains physical NRICs; PDPC guidelines restrict this from 1 September 2019.
  Authority: PDPC Advisory Guidelines on NRIC and other national identification numbers · Source: https://www.pdpc.gov.sg/ · Status: guidance · Verified: not yet
- **sg.privacy.dnc** — The document involves marketing messages to Singapore telephone numbers, which engage the Do Not Call provisions.
  Authority: Personal Data Protection Act 2012 pt 9 · Source: https://www.pdpc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed

## execution

- **sg.exec.s41a-seal-optional** [company] — The company has no common seal or does not use one; the Act provides that a document is not defective only because no seal was affixed.
  Authority: Companies Act 1967 s 41A (from 31 March 2017) · Source: https://www.acra.gov.sg/ · Status: in-force · Verified: not yet
- **sg.exec.s41b-deed** [company, deed] — A company deed shows signature by a director and the secretary, by two directors, or by one director whose signature is attested by a witness.
  Authority: Companies Act 1967 s 41B · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.exec.deed-individual-seal** [individual, deed] — A deed by an individual shows an objective physical manifestation of sealing (wording alone may not suffice); at common law sealing remains a requirement unless a statute displaces it.
  Authority: Lim Zhipeng v Seow Suat Thin [2020] 2 SLR 1151 at [37] · Source: https://www.judiciary.gov.sg/judgments · Status: in-force · Verified: not yet
- **sg.exec.attestation** [individual, deed] — Witness boxes are present but blank; record whether any statute or the document itself calls for attestation.
  Authority: Lee Yih Kang v Hsu Shih Hsun [2026] SGHC(A) 9 · Source: https://www.judiciary.gov.sg/judgments · Status: in-force · Verified: not yet · Note: Taken from commentary; reviewer to read the judgment before relying on this entry
- **sg.exec.eta-exclusions** [electronic, deed] — The document is signed electronically and may fall within a category the Electronic Transactions Act excludes (wills, indentures, trusts, powers of attorney, immovable-property contracts and conveyances).
  Authority: Electronic Transactions Act 2010 s 4 and First Schedule · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: Negotiable instruments were removed from the exclusions in 2021; confirm the current list
- **sg.exec.e-conveyancing** [electronic] — A property transaction relies on electronic execution through a prescribed system.
  Authority: Electronic Conveyancing and Other Matters Act 2025 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: Commencement to be confirmed
- **sg.exec.guarantee-writing** [individual, company] — A guarantee is in writing and signed by the guarantor.
  Authority: Civil Law Act 1909 s 6(b) · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.exec.stamp-duty** [company, individual] — The document may be chargeable with stamp duty (for example property or shares), payable within a fixed period after execution.
  Authority: Stamp Duties Act 1929 · Source: https://www.iras.gov.sg/ · Status: in-force · Verified: not yet · Note: Periods believed to be 14 days if signed in Singapore and 30 days if signed abroad; to be confirmed. Whether duty is payable is a counsel decision
- **sg.exec.lpa** [attorney] — A lasting power of attorney is signed in the presence of a certificate issuer.
  Authority: Mental Capacity Act 2008 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed

## governance

- **sg.gov.s188-minutes** [company-board, company-members] — Minutes are entered in the minute book within one month and signed by the chair of that meeting or the next; signed minutes serve as evidence that the meeting was duly held.
  Authority: Companies Act 1967 s 188 (evidence: s 188(3)) · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet
- **sg.gov.written-resolution-members** [company-members] — A members' written resolution of a private or unlisted public company records the required majority, notice to every member within 15 days, and a minute-book record signed by a director or the secretary.
  Authority: Companies Act 1967 ss 184A–184G · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **sg.gov.directors-written-resolution** [company-board] — A directors' written resolution follows the procedure in the company's constitution.
  Authority: Companies (Model Constitutions) Regulations 2015 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **sg.gov.s156-interests** [company-board] — A director's interest in a transaction is declared at a board meeting and recorded in the minutes.
  Authority: Companies Act 1967 s 156 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **sg.gov.agm-dispensed** [company-members] — A private company has dispensed with annual general meetings, and the minutes or resolutions show how.
  Authority: Companies Act 1967 s 175A · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed

## calendar.business_day

- **sg.cal.bd-contract** — No statutory default for 'business day' in contracts; agreements usually refer to days banks are open in Singapore.
  Authority: Contract construction (no statutory default) · Source: https://sso.agc.gov.sg/ · Status: guidance · Verified: not yet

## calendar.time_computation

- **sg.cal.ia-s50** — For periods in written law, the day of the event is excluded from a period counted from that event.
  Authority: Interpretation Act 1965 s 50 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: Rules on a last day falling on an excluded day and on short periods to be confirmed
- **sg.cal.roc-2021** — Time limits in civil proceedings in the Supreme Court and State Courts are counted under the Rules of Court 2021 (from 1 April 2022): for example notice of intention to contest within 14 days and defence within 21 days after service of the statement of claim in Singapore.
  Authority: Rules of Court 2021 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: Order and rule numbers to be confirmed; the deadline script has no Singapore tables and will not compute

## calendar.holidays

- **sg.cal.holidays** — Public holidays are listed in the Schedule to the Holidays Act 1998 (one national list, no regional days); the President may declare additional or substitute holidays by Gazette notification, and a holiday falling on a Sunday is observed on the next day.
  Authority: Holidays Act 1998 ss 4–5 and Schedule · Source: https://sso.agc.gov.sg/Act/HA1998 · Status: in-force · Verified: not yet · Note: Use MOM's official list for dated holidays; s 4 text to be confirmed

## calendar.limitation

- **sg.cal.limitation** — Candidate general limitation period for contract and tort claims: 6 years from accrual, subject to the special rules below.
  Authority: Limitation Act 1959 s 6(1) · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision
- **sg.cal.limitation-pi** — Personal injury (negligence, nuisance or breach of duty): 3 years from accrual or from the date of knowledge, whichever is later.
  Authority: Limitation Act 1959 s 24A · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **sg.cal.limitation-latent** — Other negligence damage: 6 years from damage or 3 years from knowledge, with a 15-year longstop.
  Authority: Limitation Act 1959 ss 24A–24B · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **sg.cal.limitation-defamation** — Defamation: no shorter special period was identified (6 years from publication), unlike Australia.
  Authority: Limitation Act 1959 s 6 · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: To be confirmed
- **sg.cal.limitation-judgments** — Enforcement of judgments: 12 years.
  Authority: Limitation Act 1959 s 6(3) · Source: https://sso.agc.gov.sg/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **sg.cal.limitation-postponement** — Disability (minors under 21, lack of capacity), fraud, concealment and acknowledgment may postpone or extend a period; record as flags, never resolve.
  Authority: Limitation Act 1959 ss 22, 26, 29 · Source: https://sso.agc.gov.sg/ · Status: guidance · Verified: not yet · Note: pinpoint to be confirmed

## courts_ai

- **sg.ai.courts-guide** — Court: Supreme Court, State Courts (including the Small Claims, Employment Claims and Community Disputes Resolution Tribunals) and Family Justice Courts of Singapore. Instrument: Guide on the Use of Generative Artificial Intelligence Tools by Court Users (Registrar's Circular No. 1 of 2024, Supreme Court; No. 9 of 2024, State Courts), from 1 October 2024. AI tools may be used to prepare court documents, including a first-cut draft of an affidavit or witness statement, but must not be used to generate, fabricate, embellish, strengthen, dilute or tamper with evidence. The court user is fully responsible for content: every case, statute and quotation must be checked to exist and support the proposition, using eLitigation GD Viewer or Singapore Statutes Online (another AI tool is not enough). Disclosure is not required by default but the court may require a statement, if needed by affidavit. Confidentiality orders, personal data, privilege and documents produced under court order must be respected. Non-compliance may lead to adverse costs (personally against lawyers), disregard of material, or disciplinary action. Restricted content: evidence-fabrication.
  Authority: Guide on the Use of Generative AI Tools by Court Users paras 3(1)–(3), 5(1), 5(3)–(8), 6(9) · Source: https://www.judiciary.gov.sg/news-and-resources/registrar's-circulars/circular-details/registrar's-circular-no.-1-2024-supreme-court · Status: in-force · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **sg.case.court-of-appeal** — SGCA, SGCA(I) → Singapore Courts judgments (direct). Court: Court of Appeal.
  Source: https://www.judiciary.gov.sg/judgments · Status: guidance · Verified: not yet · Note: Also eLitigation GD Viewer. Court identifiers to be confirmed.
- **sg.case.appellate-division** — SGHC(A) → Singapore Courts judgments (direct). Court: Appellate Division of the High Court.
  Source: https://www.judiciary.gov.sg/judgments · Status: guidance · Verified: not yet
- **sg.case.high-court** — SGHC, SGHCR, SGHCF → Singapore Courts judgments (direct). Court: General Division of the High Court (including Registrar and Family Division).
  Source: https://www.judiciary.gov.sg/judgments · Status: guidance · Verified: not yet
- **sg.case.sicc** — SGHC(I) → Singapore Courts judgments (direct). Court: Singapore International Commercial Court.
  Source: https://www.judiciary.gov.sg/judgments · Status: guidance · Verified: not yet
- **sg.case.lower-courts** — SGDC, SGMC, SGFC, SGYC → Singapore Courts judgments (direct). Court: State Courts and Family Justice Courts.
  Source: https://www.judiciary.gov.sg/judgments · Status: guidance · Verified: not yet · Note: Publication of lower-court decisions is selective.

## terminology

- Spelling: en-SG
- Use **Pte. Ltd. / Ltd** instead of Pty Ltd / Inc / LLC — Private and public companies under the Companies Act 1967.
- Use **advocate and solicitor** instead of attorney (except 'power of attorney') / barrister — Legal Profession Act 1966.
- Use **originating claim / statement of claim** instead of writ of summons — Rules of Court 2021.
- Use **General Division of the High Court / Appellate Division** instead of High Court (alone) — Court structure since 2021.
- Use **GST** instead of VAT / sales tax — 9% from 1 January 2024; confirm the rate at use.
- Use **stamp duty** instead of transfer tax — Stamp Duties Act 1929.
- Use **SICC / SIAC / SIMC** — Commercial court, arbitration centre and mediation centre.
