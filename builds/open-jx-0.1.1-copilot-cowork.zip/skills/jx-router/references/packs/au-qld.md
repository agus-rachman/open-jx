# Pack au-qld@0.1.0 — Queensland (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: state · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Queensland, QLD, Qld
- Governing-law wording: laws of Queensland, laws in force in Queensland, courts of Queensland
- Courts and tribunals: Supreme Court of Queensland, District Court of Queensland, Magistrates Courts of Queensland, Queensland Civil and Administrative Tribunal (QCAT)
- Other signals: Brisbane, QLD in an address with a four-digit postcode

## Sources (rank 1 = official text)

- **au-qld.src.legislation** — Queensland legislation (official).
  Source: https://www.legislation.qld.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-qld.src.1** — Queensland Courts.
  Source: https://www.courts.qld.gov.au/ · Type: court, rank 1 · Note: Practice directions and AI guidelines.
- **au-qld.src.2** — Supreme Court Library Queensland.
  Source: https://www.sclqld.org.au/ · Type: case-law, rank 1 · Note: Queensland judgments.
- **au-qld.src.3** — Queensland Revenue Office.
  Source: https://qro.qld.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-qld.cite.state-act** — Cite Queensland Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-qld.id.driver-licence** — Queensland driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Transport Operations (Road Use Management) Act 1995 (Qld) · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-qld.privacy.general-privacy** — General privacy law: Information Privacy Act 2009 — Queensland public-sector agencies, including councils (current legislation).
  Authority: Information Privacy Act 2009 (Qld) · Source: https://www.legislation.qld.gov.au/view/html/inforce/current/act-2009-014 · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-qld.privacy.health** — Health information: Information Privacy Act 2009 and sector confidentiality law — public health bodies (current legislation).
  Authority: Information Privacy Act 2009 and sector confidentiality law (Qld) · Source: https://www.legislation.qld.gov.au/view/html/inforce/current/act-2009-014 · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-qld.privacy.breach** — Data breach notification: Information Privacy Act mandatory notification scheme (current legislation).
  Authority: Information Privacy Act mandatory notification scheme (Qld) · Source: https://www.oic.qld.gov.au/community/qld-data-breach-scheme · Status: in-force · Verified: not yet · Note: commencement state agencies: 2025-07-01; commencement local government: 2026-07-01 · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-qld.privacy.workplace** — Workplace surveillance: no dedicated regime identified in this jurisdiction (upstream as at 2026-08-14).
  Authority: Dedicated workplace-surveillance regime · Source: https://www.legislation.qld.gov.au/view/html/inforce/current/act-1971-050 · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-qld.exec.deed-individual** [individual, deed] — A deed by an individual shows the signing and witnessing formalities of the current Queensland property law Act, including any electronic deed provisions.
  Authority: Property Law Act 2023 (Qld) · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Note: The Property Law Act 2023 (Qld) replaced the Property Law Act 1974 (Qld); confirm commencement and pinpoints.
- **au-qld.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions (Queensland) Act 2001 · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-qld.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Duties Act 2001 (Qld) · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.
- **au-qld.exec.poa** [attorney] — A party signs by an attorney. If the power is an enduring power of attorney, it is in the approved form, signed before an eligible witness (justice of the peace, commissioner for declarations, notary public or lawyer) who certifies, and accepted by the attorney.
  Authority: Powers of Attorney Act 1998 (Qld) ss 31, 44 · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## governance

- **au-qld.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Act 1981 (Qld) · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-qld.cal.interp** — Periods in Queensland legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Acts Interpretation Act 1954 (Qld) s 38; Statutory Instruments Act 1992 (Qld) s 14(1) · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-qld.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Uniform Civil Procedure Rules 1999 (Qld) · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed for the general time rule · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-qld.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Uniform Civil Procedure Rules 1999 (Qld) · Source: https://www.legislation.qld.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## calendar.holidays

- **au-qld.cal.holidays** — The Royal Queensland Show holiday applies in the Brisbane area; other districts have their own show holidays.
  Authority: Holidays Act 1983 (Qld) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-qld.cal.limitation** — Candidate general limitation period for contract and tort claims governed by Queensland law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation of Actions Act 1974 (Qld) s 10 · Source: https://www.legislation.qld.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-qld.ai.qld-guidelines** — Court: Queensland courts. Instrument: Queensland Courts guidelines on the use of generative AI, and Supreme Court practice directions on accuracy of references. Queensland courts publish guidance on responsible use of generative AI and expect references in submissions to be checked for accuracy; check the current guideline and any practice direction for the court concerned.
  Authority: Queensland Courts guidelines on the use of generative AI, and Supreme Court practice directions on accuracy of references · Source: https://www.courts.qld.gov.au/ · Status: in-force · Verified: not yet
- **au-qld.ai.check-current** — Court: All Queensland courts and QCAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.courts.qld.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-qld.case.sclqld** — QSC, QCA, QDC, QCAT → Supreme Court Library Queensland (human-browser-only). Court: Queensland courts.
  Source: https://www.sclqld.org.au/caselaw · Status: guidance · Verified: not yet · Note: Judgment text is rendered in the browser only; use a human-operated browser session. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **QCAT** instead of small claims court / administrative tribunal — Queensland civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Duties Act 2001 (Qld).

## deadlines — holiday table and court computation rules

- **Holiday table `qld`** — Queensland public holidays under the Holidays Act 1983 (Qld), as published by the Queensland Government (statewide list; Brisbane-area basis for the show holiday). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-14 (verified); source https://www.qld.gov.au/recreation/travel/holidays/public.
  Holidays: 2026-01-01, 2026-01-26, 2026-04-03, 2026-04-04, 2026-04-05, 2026-04-06, 2026-04-25, 2026-05-04, 2026-08-12, 2026-10-05, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-26, 2027-03-27, 2027-03-28, 2027-03-29, 2027-04-26, 2027-05-03, 2027-08-11, 2027-10-04, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Caveat: The Royal Queensland Show holiday (Wednesday 12 August 2026; Wednesday 11 August 2027) applies in the Brisbane area only and is included because the Supreme Court and Court of Appeal registry sits at Brisbane; every other local government district has its own appointed show holiday (97 districts in 2026), none of which is included — confirm registry-location holidays before relying on a business-day computation.
  Caveat: Local show holidays for districts outside Brisbane had not been published for 2027 at the checked date.
  Caveat: Christmas Eve is a part-day public holiday (6pm to midnight) and is not included as a non-business day.
  Caveat: Anzac Day is substituted only when 25 April falls on a Sunday: 2026 falls on a Saturday with no substitute; 2027 is observed on Monday 26 April as published.
- **Rule table `qcat`** — Queensland Civil and Administrative Tribunal; holidays: `qld`. Verified against legislation.qld.gov.au on 2026-08-14. The general review period sits in s 33(3) of the QCAT Act (28 days after the relevant day), but an enabling Act that is an Act may provide a different period (s 6(7); s 33 note 1) — the conferring Act must be checked before any candidate is relied on. The QCAT Rules 2009 (SL 2009 No. 253) govern form, content and filing only and do not qualify the s 33(3) period. Extension is available under s 61, but is barred where it would cause prejudice or detriment not remediable by an appropriate order for costs or damages (s 61(3)).
  Provision `qld-aia-s38`: Acts Interpretation Act 1954 (Qld) s 38 (verified)
  Rule `qcat-review-application`: Application to review a reviewable decision (general period, subject to the enabling Act) — Queensland Civil and Administrative Tribunal Act 2009 (Qld) s 33(3); 28 calendar days, rollover next_business_day (verified)
- **Rule table `qld-courts`** — Supreme Court of Queensland, District Court of Queensland, Magistrates Courts of Queensland; holidays: `qld`. Verified against legislation.qld.gov.au on 2026-08-14. The UCPR contains no time-reckoning rule of its own: the note to r 7 states that a time allowed or provided for under the rules is calculated according to the Acts Interpretation Act 1954 s 38, which applies to the UCPR through the Statutory Instruments Act 1992 s 14(1) and sch 1 (item 'parts 9-11'). The UCPR dictionary is schedule 3 and adopts the AIA sch 1 'business day' definition. Rollover under s 38(2) turns on 'excluded days' — for filing, days the registry is closed (s 38(5)(a)), and the registry closes on Saturdays, Sundays and court holidays (r 976); the script approximates registry-closed days with the weekend-and-public-holiday table, and every computed date carries a warning to confirm the registry was open.
  Provision `qld-aia-s38`: Acts Interpretation Act 1954 (Qld) s 38 (verified)
  Provision `qld-sia-s14`: Statutory Instruments Act 1992 (Qld) s 14(1) and sch 1 (verified)
  Rule `qld-ucpr-noid-after-service`: Notice of intention to defend (with defence attached) after service of claim — Uniform Civil Procedure Rules 1999 (Qld) r 137(1); 28 calendar days, rollover next_business_day (verified)
  Rule `qld-ucpr-appeal-notice`: Notice of appeal to the Court of Appeal — Uniform Civil Procedure Rules 1999 (Qld) r 748(a); 28 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
