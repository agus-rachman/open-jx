# Pack au-nt@0.1.0 — Northern Territory (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: territory · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Northern Territory, NT
- Governing-law wording: laws of Northern Territory, laws in force in Northern Territory, courts of Northern Territory
- Courts and tribunals: Supreme Court of the Northern Territory, Local Court of the Northern Territory, Northern Territory Civil and Administrative Tribunal (NTCAT)
- Other signals: Darwin, NT in an address with a four-digit postcode

## Sources (rank 1 = official text)

- **au-nt.src.legislation** — Northern Territory legislation (official).
  Source: https://legislation.nt.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-nt.src.1** — Supreme Court of the Northern Territory.
  Source: https://supremecourt.nt.gov.au/ · Type: court, rank 1
- **au-nt.src.2** — Territory Revenue Office (Department of Treasury and Finance).
  Source: https://treasury.nt.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-nt.cite.state-act** — Cite Northern Territory Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-nt.id.driver-licence** — Northern Territory driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Motor Vehicles Act 1949 (NT) · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-nt.privacy.general-privacy** — General privacy law: Information Act 2002 — NT public-sector organisations and specified contractors (current legislation).
  Authority: Information Act 2002 (NT) · Source: https://legislation.nt.gov.au/en/Legislation/information-act-2002 · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nt.privacy.breach** — Data breach notification: NT Government breach reporting (policy or voluntary pathway).
  Authority: NT Government breach reporting · Source: https://infocomm.nt.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nt.privacy.workplace** — Workplace surveillance: no dedicated regime identified in this jurisdiction (upstream as at 2026-08-14).
  Authority: Dedicated workplace-surveillance regime · Source: https://legislation.nt.gov.au/en/Legislation/SURVEILLANCE-DEVICES-ACT-2007 · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-nt.exec.deed-individual** [individual, deed] — A deed by an individual shows signature and witnessing as required in the Northern Territory.
  Authority: Law of Property Act 2000 (NT) · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-nt.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions (Northern Territory) Act 2000 · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-nt.exec.poa** [attorney] — A party signs by an attorney; the power of attorney and its form are governed by state or territory law.
  Authority: Powers of Attorney Act 1980 (NT); Advance Personal Planning Act 2013 (NT) · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet
- **au-nt.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Stamp Duty Act 1978 (NT) · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.

## governance

- **au-nt.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Act 2003 (NT) · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-nt.cal.interp** — Periods in Northern Territory legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Interpretation Act 1978 (NT) ss 4 and 28 · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-nt.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Supreme Court Rules 1987 (NT) rr 3.01 and 3.07 · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-nt.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Supreme Court Rules 1987 (NT) rr 3.01 and 3.07 · Source: https://legislation.nt.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## calendar.holidays

- **au-nt.cal.holidays** — May Day and Picnic Day (August) are NT-specific; Christmas Eve and New Year's Eve are part-day public holidays (evening).
  Authority: Public Holidays Act 1981 (NT) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-nt.cal.limitation** — Candidate general limitation period for contract and tort claims governed by Northern Territory law: 3 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation Act 1981 (NT) s 12 · Source: https://legislation.nt.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-nt.ai.check-current** — Court: All Northern Territory courts and NTCAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://supremecourt.nt.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-nt.case.court-site** — NTSC, NTCA, NTCAT → The court's own website (not-mapped). Court: Northern Territory courts and NTCAT.
  Source: https://supremecourt.nt.gov.au/ · Status: guidance · Verified: not yet · Note: Official publisher route not yet mapped; a citation that cannot be checked at the court's publisher is reported as unverifiable, never as verified or fabricated. Contributors: map the publisher and access posture. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **NTCAT** instead of small claims court / administrative tribunal — Northern Territory civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Stamp Duty Act 1978 (NT).

## deadlines — holiday table and court computation rules

- **Holiday table `nt`** — Northern Territory public holidays under the Public Holidays Act 1981 (NT), as published by the Northern Territory Government (territory-wide list; Darwin-registry basis for the regional show day). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-26 (verified); source https://nt.gov.au/nt-public-holidays.
  Holidays: 2026-01-01, 2026-01-26, 2026-04-03, 2026-04-04, 2026-04-05, 2026-04-06, 2026-04-25, 2026-05-04, 2026-06-08, 2026-07-24, 2026-08-03, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-26, 2027-03-27, 2027-03-28, 2027-03-29, 2027-04-26, 2027-05-03, 2027-06-14, 2027-07-23, 2027-08-02, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Caveat: The Darwin Show Day (Friday 24 July 2026; Friday 23 July 2027) is a regional holiday and is included on a Darwin-registry basis; the Alice Springs Show Day (3 July 2026; 2 July 2027) and the Tennant Creek, Katherine and Borroloola show days are not included — confirm registry-location holidays for the Alice Springs registry (see the show-day regions map on the source page).
  Caveat: Christmas Eve and New Year's Eve are part-day public holidays (7pm to midnight) and are not included as non-business days; Interpretation Act 1978 (NT) s 28(2) and the 'business day' definition likewise disregard part-day holidays.
  Caveat: Anzac Day 2026 falls on a Saturday with no substitute; Anzac Day 2027 is observed on Monday 26 April, as published.
  Caveat: Christmas Day 2027 falls on a Saturday: Saturday 25 and Monday 27 December are holidays, and Boxing Day is observed on Sunday 26 and Tuesday 28 December, as published.
- **Rule table `nt-courts`** — Supreme Court of the Northern Territory, Local Court of the Northern Territory; holidays: `nt`. Verified against legislation.nt.gov.au on 2026-08-26. The Supreme Court Rules 1987 carry their own time code in O 3 r 3.01: the start day is excluded and the end day included, periods of 5 days or less skip days the Registry is closed, and a last day on which the Registry is closed moves to the next day it is open; the Registry is open every day except Saturdays, Sundays and public holidays under the Public Holidays Act 1981 (r 3.07(1)). Interpretation Act 1978 s 28 applies to statutory instruments through s 4 and produces the same result (exclusive of the trigger day; last day on a Saturday, Sunday or whole-day public holiday moves to the next day that is none of those) and is tabled as a secondary provision. The script approximates registry-open days with the weekend-and-public-holiday table (Darwin basis), and every computed date carries a warning to confirm the registry was open. Local Court (Civil Jurisdiction) Rules periods are not tabled here. An entry returned to pending-verification fails closed until re-verified.
  Provision `nt-scr-r3-01`: Supreme Court Rules 1987 (NT) rr 3.01 and 3.07 (verified)
  Provision `nt-ia-s28`: Interpretation Act 1978 (NT) ss 4 and 28 (verified)
  Rule `nt-scr-appearance-after-service`: Notice of appearance after service of writ (Darwin Registry, service within 200 km of Darwin) — Supreme Court Rules 1987 (NT) r 8.04(a)(i); 7 calendar days, rollover next_business_day (verified)
  Rule `nt-scr-defence-after-soc-service`: Defence after service of a separate statement of claim — Supreme Court Rules 1987 (NT) r 14.04(b); 14 calendar days, rollover next_business_day (verified)
  Rule `nt-scr-appeal-notice`: Notice of appeal (Court of Appeal or Full Court) where no Act fixes the period — Supreme Court Rules 1987 (NT) r 82.04(2)(b); 28 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
