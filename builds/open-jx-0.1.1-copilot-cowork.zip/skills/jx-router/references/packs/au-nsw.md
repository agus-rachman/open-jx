# Pack au-nsw@0.1.0 — New South Wales (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: state · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: New South Wales, NSW
- Governing-law wording: laws of New South Wales, laws in force in New South Wales, courts of New South Wales
- Courts and tribunals: Supreme Court of New South Wales, District Court of New South Wales, Local Court of New South Wales, Land and Environment Court of New South Wales, NSW Civil and Administrative Tribunal (NCAT)
- Other signals: Sydney, NSW in an address with a four-digit postcode

## Sources (rank 1 = official text)

- **au-nsw.src.legislation** — New South Wales legislation (official).
  Source: https://legislation.nsw.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-nsw.src.1** — NSW Caselaw.
  Source: https://www.caselaw.nsw.gov.au/ · Type: case-law, rank 1 · Note: Official NSW judgments.
- **au-nsw.src.2** — Supreme Court of NSW.
  Source: https://supremecourt.nsw.gov.au/ · Type: court, rank 1 · Note: Practice notes, including SC Gen 23.
- **au-nsw.src.3** — Revenue NSW.
  Source: https://www.revenue.nsw.gov.au/ · Type: regulator, rank 1
- **au-nsw.src.4** — NSW Fair Trading.
  Source: https://www.fairtrading.nsw.gov.au/ · Type: regulator, rank 1
- **au-nsw.src.5** — NSW Land Registry Services.
  Source: https://www.nswlrs.com.au/ · Type: register, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-nsw.cite.state-act** — Cite New South Wales Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-nsw.id.driver-licence** — New South Wales driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Road Transport Act 2013 (NSW) · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-nsw.privacy.general-privacy** — General privacy law: Privacy and Personal Information Protection Act 1998 — NSW public sector, councils and specified bodies (current legislation).
  Authority: Privacy and Personal Information Protection Act 1998 (NSW) · Source: https://legislation.nsw.gov.au/view/html/inforce/current/act-1998-133/lh · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nsw.privacy.health** — Health information: Health Records and Information Privacy Act 2002 — public and specified private health-information handling (current legislation).
  Authority: Health Records and Information Privacy Act 2002 (NSW) · Source: https://legislation.nsw.gov.au/view/html/inforce/current/act-2002-071/lh · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nsw.privacy.breach** — Data breach notification: PPIP Act Part 6A — covered NSW public-sector agencies (current legislation).
  Authority: PPIP Act Part 6A (NSW) · Source: https://legislation.nsw.gov.au/view/html/inforce/current/act-1998-133/lh · Status: in-force · Verified: not yet · Note: commencement: 2023-11-28 · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nsw.privacy.workplace** — Workplace surveillance: Workplace Surveillance Act 2005 (current legislation).
  Authority: Workplace Surveillance Act 2005 (NSW) · Source: https://legislation.nsw.gov.au/view/html/inforce/current/act-2005-047/lh · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-nsw.exec.deed-individual** [individual, deed] — A deed signed by an individual is attested by at least one witness who is not a party; a seal is not needed.
  Authority: Conveyancing Act 1919 (NSW) s 38 · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet
- **au-nsw.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions Act 2000 (NSW) · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Includes provisions on electronic execution of deeds and witnessing by audio-visual link; pinpoint to be confirmed
- **au-nsw.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Duties Act 1997 (NSW) · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.
- **au-nsw.exec.poa** [attorney] — A party signs by an attorney. If the power is an enduring power of attorney, its creation shows the continuing-effect statement, a prescribed witness who is not an attorney, and the witness certificate; the attorney's authority depends on signed acceptance.
  Authority: Powers of Attorney Act 2003 (NSW) ss 19, 20 · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Commercial (non-enduring) powers follow the general law and the instrument itself. · Upstream: legal-skills@5bfb3d8, checked 2026-08-20 (verified)
- **au-nsw.exec.avl-witnessing** [individual, electronic] — A will, power of attorney or enduring guardianship appointment was witnessed by audio visual link; the document shows the witness's endorsement of the method used.
  Authority: Electronic Transactions Act 2000 (NSW) pt 2B, s 14G · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Check separately whether a commercial deed may be witnessed this way. · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## governance

- **au-nsw.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Act 2009 (NSW) · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-nsw.cal.interp** — Periods in New South Wales legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Interpretation Act 1987 (NSW) s 36 · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nsw.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Uniform Civil Procedure Rules 2005 (NSW) r 1.11 · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Interpretation Act 1987 (NSW) s 36 does not apply to periods under the UCPR (r 1.11(5)); for periods of 5 days or less, registry-closed days are excluded (r 1.11(3)). · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-nsw.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Uniform Civil Procedure Rules 2005 (NSW) r 1.11 · Source: https://legislation.nsw.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## calendar.holidays

- **au-nsw.cal.holidays** — Includes a Bank Holiday (first Monday in August) that applies to banks and certain financial institutions only.
  Authority: Public Holidays Act 2010 (NSW) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-nsw.cal.limitation** — Candidate general limitation period for contract and tort claims governed by New South Wales law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation Act 1969 (NSW) s 14 · Source: https://legislation.nsw.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-nsw.ai.sc-gen-23** — Court: Supreme Court of New South Wales. Instrument: Practice Note SC Gen 23 — Use of Generative Artificial Intelligence (Gen AI). Gen AI must not be used to generate the content of affidavits, witness statements, character references or other material intended to reflect a witness's evidence or opinion; such documents carry a statement that Gen AI was not used. Gen AI must not be used to draft or prepare expert reports without the Court's prior leave. Where Gen AI is used for written submissions or summaries, the author must verify that citations and references exist, are accurate and are relevant. Restrictions apply to entering material subject to non-publication or suppression orders, subpoenaed material and material produced under compulsion. Restricted content: affidavit-content, witness-statement-content, character-reference-content, expert-report-without-leave.
  Authority: Practice Note SC Gen 23 — Use of Generative Artificial Intelligence (Gen AI) · Source: https://supremecourt.nsw.gov.au/ · Status: in-force · Verified: not yet
- **au-nsw.ai.district-local** — Court: District Court of New South Wales; Local Court of New South Wales. Instrument: Generative AI practice notes of the District Court and Local Court (Local Court note commencing 12 January 2026). The District and Local Courts have adopted generative AI practice notes along the lines of SC Gen 23; check the current note for the court concerned. Restricted content: affidavit-content, witness-statement-content, character-reference-content, expert-report-without-leave.
  Authority: Generative AI practice notes of the District Court and Local Court (Local Court note commencing 12 January 2026) · Source: https://localcourt.nsw.gov.au/ · Status: in-force · Verified: not yet
- **au-nsw.ai.pic13** — Court: Personal Injury Commission of New South Wales. Instrument: Procedural Direction PIC13 — Use of Generative Artificial Intelligence. The Commission has its own procedural direction on generative AI; check it before preparing material for the Commission.
  Authority: Procedural Direction PIC13 — Use of Generative Artificial Intelligence · Source: https://www.pi.nsw.gov.au/ · Status: in-force · Verified: not yet
- **au-nsw.ai.check-current** — Court: All New South Wales courts and NCAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.caselaw.nsw.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-nsw.case.caselaw** — NSWSC, NSWCA, NSWCCA, NSWDC, NSWLC, NSWLEC, NSWIC, NSWCATAP, NSWCATAD → NSW Caselaw (direct). Court: NSW courts and tribunals.
  Source: https://www.caselaw.nsw.gov.au/ · Status: guidance · Verified: not yet · Note: Reproduce decisions accurately and in context, preserve restriction notations, and do not republish party names into indexable contexts (Copyright in Judicial Decisions Notice 1995 (NSW)). · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **NCAT** instead of small claims court / administrative tribunal — New South Wales civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Duties Act 1997 (NSW).

## deadlines — holiday table and court computation rules

- **Holiday table `nsw`** — Declared NSW public holidays under the Public Holidays Act 2010 (NSW), as published by the NSW Government. Coverage 2026-01-01 to 2027-12-31; checked 2026-08-14 (verified); source https://www.nsw.gov.au/about-nsw/public-holidays.
  Holidays: 2026-01-01, 2026-01-26, 2026-04-03, 2026-04-04, 2026-04-05, 2026-04-06, 2026-04-25, 2026-04-27, 2026-06-08, 2026-10-05, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-26, 2027-03-27, 2027-03-28, 2027-03-29, 2027-04-25, 2027-04-26, 2027-06-14, 2027-10-04, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Caveat: Local public holidays and local event days declared for particular NSW local government areas are not included; confirm registry-location holidays before relying on a business-day computation.
  Caveat: The NSW Bank Holiday (first Monday in August) is not a declared public holiday and is excluded.
  Caveat: The published table lists an Additional Day after Anzac Day (Monday 27 April 2026; Monday 26 April 2027); it is included exactly as published.
- **Rule table `ncat`** — NSW Civil and Administrative Tribunal; holidays: `nsw`. Verified against legislation.nsw.gov.au on 2026-08-14. Time limits for particular divisions and decision types sit in the enabling legislation, which displaces the general rule (r 25(4)(a)); a 14-day period applies to internal appeals against decisions in residential proceedings (r 25(4)(b)).
  Provision `nsw-ia-s36`: Interpretation Act 1987 (NSW) s 36 (verified)
  Rule `ncat-internal-appeal`: Internal appeal to the NCAT Appeal Panel (general period) — Civil and Administrative Tribunal Rules 2014 (NSW) r 25(4)(c); 28 calendar days, rollover next_business_day (verified)
- **Rule table `nsw-courts`** — Supreme Court of NSW, District Court of NSW, Local Court of NSW; holidays: `nsw`. Verified against legislation.nsw.gov.au on 2026-08-14. Interpretation Act 1987 s 36 is disapplied to the UCPR by r 1.11(5), so UCPR period rules rely on r 1.11 alone. UCPR rollover turns on days the registry is closed (r 1.11(4)); the script approximates registry-closed days with the weekend-and-public-holiday table, and every computed date carries a warning to confirm the registry was open. An entry returned to pending-verification fails closed until re-verified.
  Provision `nsw-ia-s36`: Interpretation Act 1987 (NSW) s 36 (verified)
  Provision `ucpr-1-11`: Uniform Civil Procedure Rules 2005 (NSW) r 1.11 (verified)
  Rule `ucpr-defence-after-service`: Defence after service of statement of claim — Uniform Civil Procedure Rules 2005 (NSW) r 14.3(1); 28 calendar days, rollover next_business_day (verified)
  Rule `ucpr-appeal-notice-ca`: Notice of appeal to the Court of Appeal (no leave required, no notice of intention filed) — Uniform Civil Procedure Rules 2005 (NSW) r 51.16(1)(c); 28 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
