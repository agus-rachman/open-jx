# Pack au-vic@0.1.0 — Victoria (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: state · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Victoria, Victorian, VIC
- Governing-law wording: laws of Victoria, laws in force in Victoria, courts of Victoria
- Courts and tribunals: Supreme Court of Victoria, County Court of Victoria, Magistrates' Court of Victoria, Victorian Civil and Administrative Tribunal (VCAT)
- Other signals: Melbourne, VIC in an address with a four-digit postcode

## Sources (rank 1 = official text)

- **au-vic.src.legislation** — Victoria legislation (official).
  Source: https://www.legislation.vic.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-vic.src.1** — Supreme Court of Victoria.
  Source: https://www.supremecourt.vic.gov.au/ · Type: court, rank 1 · Note: Practice notes and AI guidelines.
- **au-vic.src.2** — County Court of Victoria.
  Source: https://www.countycourt.vic.gov.au/ · Type: court, rank 1
- **au-vic.src.3** — State Revenue Office Victoria.
  Source: https://www.sro.vic.gov.au/ · Type: regulator, rank 1
- **au-vic.src.4** — Consumer Affairs Victoria.
  Source: https://www.consumer.vic.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-vic.cite.state-act** — Cite Victoria Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-vic.id.driver-licence** — Victoria driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Road Safety Act 1986 (Vic) · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-vic.privacy.general-privacy** — General privacy law: Privacy and Data Protection Act 2014 — Victorian public sector and specified contracted service providers (current legislation).
  Authority: Privacy and Data Protection Act 2014 (Vic) · Source: https://www.legislation.vic.gov.au/in-force/acts/privacy-and-data-protection-act-2014/014 · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-vic.privacy.health** — Health information: Health Records Act 2001 — public and private organisations handling health information (current legislation).
  Authority: Health Records Act 2001 (Vic) · Source: https://www.legislation.vic.gov.au/in-force/acts/health-records-act-2001/042 · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-vic.privacy.breach** — Data breach notification: OVIC Information Security Incident Notification Scheme — in-scope VPDSS bodies (standards-based scheme).
  Authority: OVIC Information Security Incident Notification Scheme · Source: https://ovic.vic.gov.au/information-security/ovic-information-security-incident-notification-scheme/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-vic.privacy.workplace** — Workplace surveillance: Dedicated workplace-surveillance regime (proposal).
  Authority: Dedicated workplace-surveillance regime · Source: https://www.premier.vic.gov.au/big-tech-must-stop-spying-workers-work · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-vic.exec.deed-individual** [individual, deed] — A deed by an individual shows the execution formalities required in Victoria (signature, witnessing and any sealing or delivery wording).
  Authority: Property Law Act 1958 (Vic) s 73 · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Note: Victorian deed formalities for individuals have historically differed from other states; confirm the current position, including electronic deeds.
- **au-vic.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions (Victoria) Act 2000 · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Note: Electronic signing and electronic deeds; pinpoint to be confirmed
- **au-vic.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Duties Act 2000 (Vic) · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.
- **au-vic.exec.poa** [attorney] — A party signs by an attorney. If the power is an enduring power of attorney, it uses the prescribed form, is signed before two eligible witnesses (at least one authorised to witness affidavits or a medical practitioner) and carries each attorney's witnessed acceptance.
  Authority: Powers of Attorney Act 2014 (Vic) ss 32–38; Powers of Attorney Regulations 2025 (Vic) reg 6, sch 1 form 1 · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-20 (verified)
- **au-vic.exec.remote-poa** [attorney, electronic] — An enduring power of attorney was witnessed remotely; Victoria permits this only through its statutory procedure (same day, within Victoria, a special witness who signs last).
  Authority: Powers of Attorney Act 2014 (Vic) ss 5A–5C, 33(2)–(4) · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-20 (verified)

## governance

- **au-vic.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Reform Act 2012 (Vic) · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-vic.cal.interp** — Periods in Victoria legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Interpretation of Legislation Act 1984 (Vic) s 44 · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-vic.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 3.01 · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-vic.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 3.01 · Source: https://www.legislation.vic.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## calendar.holidays

- **au-vic.cal.holidays** — Melbourne Cup Day applies in metropolitan Melbourne (regional councils may substitute another day); the Friday before the AFL Grand Final is a public holiday.
  Authority: Public Holidays Act 1993 (Vic) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-vic.cal.limitation** — Candidate general limitation period for contract and tort claims governed by Victoria law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation of Actions Act 1958 (Vic) s 5 · Source: https://www.legislation.vic.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-vic.ai.vsc-guidelines** — Court: Supreme Court of Victoria; County Court of Victoria. Instrument: Guidelines for litigants: responsible use of artificial intelligence in litigation (Supreme Court, 2024; County Court equivalent). The guidelines expect parties and practitioners to understand the tools they use, to disclose AI use where appropriate, to verify citations and content, and not to use AI to generate evidence that should reflect a witness's own knowledge.
  Authority: Guidelines for litigants: responsible use of artificial intelligence in litigation (Supreme Court, 2024; County Court equivalent) · Source: https://www.supremecourt.vic.gov.au/ · Status: in-force · Verified: not yet
- **au-vic.ai.check-current** — Court: All Victoria courts and VCAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.supremecourt.vic.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-vic.case.court-site** — VSC, VSCA, VCC, VCAT → The court's own website (not-mapped). Court: Victorian courts and VCAT.
  Source: https://www.supremecourt.vic.gov.au/ · Status: guidance · Verified: not yet · Note: Official publisher route not yet mapped; a citation that cannot be checked at the court's publisher is reported as unverifiable, never as verified or fabricated. Contributors: map the publisher and access posture. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **VCAT** instead of small claims court / administrative tribunal — Victoria civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Duties Act 2000 (Vic).

## deadlines — holiday table and court computation rules

- **Holiday table `vic`** — Victorian public holidays as published by Business Victoria (statewide list; metropolitan basis). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-14 (verified); source https://business.vic.gov.au/business-information/public-holidays.
  Holidays: 2026-01-01, 2026-01-26, 2026-03-09, 2026-04-03, 2026-04-04, 2026-04-05, 2026-04-06, 2026-04-25, 2026-06-08, 2026-09-25, 2026-11-03, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-08, 2027-03-26, 2027-03-27, 2027-03-28, 2027-03-29, 2027-04-25, 2027-06-14, 2027-11-02, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Uncertain window 2027-09-01 to 2027-10-08: The Friday before the AFL Grand Final 2027 public holiday has no fixed date until the AFL schedule is released; the publisher states the page will be updated when it is.
  Caveat: Non-metropolitan councils may substitute an alternate local holiday for Melbourne Cup Day; confirm registry-location holidays before relying on a business-day computation.
  Caveat: ANZAC Day is commemorated on the day it falls with no replacement holiday when it falls on a weekend.
- **Rule table `vcat`** — Victorian Civil and Administrative Tribunal; holidays: `vic`. Verified against legislation.vic.gov.au on 2026-08-14: NO general default review period exists. Neither the Victorian Civil and Administrative Tribunal Act 1998 (Authorised Version No. 145) nor the VCAT Rules 2018 (Authorised Version No. 019) fixes a period for review applications where the enabling enactment is silent — s 67 of the Act deals only with the form and manner of applications, and the phrase '28 days' does not appear in the current Rules. Each enabling enactment fixes its own period (many specify 28 days; planning matters 60 days), and s 126 of the Act permits extensions. The widely repeated general '28 days' derives from VCAT guidance, not legislation. No general period rule ships in this table; add enabling-enactment-specific rules per practice after verifying the conferring provision, in the pending-verification state until verify-deadline-basis confirms them.
  Provision `vic-ila-s44`: Interpretation of Legislation Act 1984 (Vic) s 44 (verified)
- **Rule table `vic-courts`** — Supreme Court of Victoria, County Court of Victoria, Magistrates' Court of Victoria; holidays: `vic`. Verified against legislation.vic.gov.au on 2026-08-14. The Supreme Court (General Civil Procedure) Rules 2015 were replaced by the Supreme Court (General Civil Procedure) Rules 2025 (S.R. No. 85/2025) from 8 September 2025; citations refer to the 2025 instrument. Rule 3.01 rollover turns on days the Court office is closed; the script approximates office-closed days with the weekend-and-public-holiday table, and every computed date carries a warning to confirm the office was open. The appearance rule stays pending-verification because the operative time is the time stated in the writ itself.
  Provision `vic-ila-s44`: Interpretation of Legislation Act 1984 (Vic) s 44 (verified)
  Provision `vic-scr-3-01`: Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 3.01 (verified)
  Rule `vic-scr-appearance-after-service`: Appearance after service of writ (service in Victoria; minimum period) — Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 8.04(a)(i); 10 calendar days, rollover next_business_day (pending-verification)
  Rule `vic-scr-defence-after-appearance`: Defence where the writ's indorsement of claim stands as the statement of claim — Supreme Court (General Civil Procedure) Rules 2025 (Vic) r 14.04(a); 30 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
