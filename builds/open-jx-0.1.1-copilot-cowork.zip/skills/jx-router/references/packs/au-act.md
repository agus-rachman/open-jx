# Pack au-act@0.1.0 — Australian Capital Territory (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: territory · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: Australian Capital Territory, ACT
- Governing-law wording: laws of Australian Capital Territory, laws in force in Australian Capital Territory, courts of Australian Capital Territory
- Courts and tribunals: Supreme Court of the Australian Capital Territory, ACT Magistrates Court, ACT Civil and Administrative Tribunal (ACAT)
- Other signals: Canberra, ACT in an address with a four-digit postcode
- Note: 'ACT' is also an ordinary word; match only the capitalised abbreviation or the full name.

## Sources (rank 1 = official text)

- **au-act.src.legislation** — Australian Capital Territory legislation (official).
  Source: https://www.legislation.act.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-act.src.1** — ACT Courts.
  Source: https://www.courts.act.gov.au/ · Type: court, rank 1
- **au-act.src.2** — ACT Revenue Office.
  Source: https://www.revenue.act.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-act.cite.state-act** — Cite Australian Capital Territory Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-act.id.driver-licence** — Australian Capital Territory driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Road Transport (Driver Licensing) Act 1999 (ACT) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-act.privacy.general-privacy** — General privacy law: Information Privacy Act 2014 — ACT public-sector agencies and specified contracted providers (current legislation).
  Authority: Information Privacy Act 2014 (ACT) · Source: https://www.legislation.act.gov.au/a/2014-24/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-act.privacy.health** — Health information: Health Records (Privacy and Access) Act 1997 — public and private record keepers and health providers (current legislation).
  Authority: Health Records (Privacy and Access) Act 1997 (ACT) · Source: https://www.legislation.act.gov.au/a/1997-125/current · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-act.privacy.breach** — Data breach notification: ACT Government cyber incident reporting (government policy).
  Authority: ACT Government cyber incident reporting · Source: https://www.act.gov.au/__data/assets/pdf_file/0006/2837121/Cyber-Security-Policy.pdf · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-act.privacy.workplace** — Workplace surveillance: Workplace Privacy Act 2011 (current legislation).
  Authority: Workplace Privacy Act 2011 (ACT) · Source: https://www.legislation.act.gov.au/a/2011-4/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-act.exec.deed-individual** [individual, deed] — A deed by an individual shows signature and witnessing as required in the ACT.
  Authority: Civil Law (Property) Act 2006 (ACT) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-act.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Transactions Act 2001 (ACT) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-act.exec.poa** [attorney] — A party signs by an attorney; the power of attorney and its form are governed by state or territory law.
  Authority: Powers of Attorney Act 2006 (ACT) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet
- **au-act.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Duties Act 1999 (ACT) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.

## governance

- **au-act.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Act 1991 (ACT) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-act.cal.interp** — Periods in Australian Capital Territory legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Legislation Act 2001 (ACT) ss 151, 151A and dictionary pt 1 (working day) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-act.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Court Procedures Rules 2006 (ACT) r 6300(1) · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Note: The registry is closed between 26 December and 1 January (r 6300(1)(b)); a filing deadline landing then moves to the next working day. · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-act.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Court Procedures Rules 2006 (ACT) r 6300(1) · Source: https://www.legislation.act.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## calendar.holidays

- **au-act.cal.holidays** — Canberra Day (March) and Reconciliation Day (late May or early June) are ACT-specific.
  Authority: Holidays Act 1958 (ACT) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-act.cal.limitation** — Candidate general limitation period for contract and tort claims governed by Australian Capital Territory law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation Act 1985 (ACT) s 11 · Source: https://www.legislation.act.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-act.ai.check-current** — Court: All Australian Capital Territory courts and ACAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.courts.act.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-act.case.court-site** — ACTSC, ACTCA, ACAT → The court's own website (not-mapped). Court: ACT courts and ACAT.
  Source: https://www.courts.act.gov.au/ · Status: guidance · Verified: not yet · Note: Official publisher route not yet mapped; a citation that cannot be checked at the court's publisher is reported as unverifiable, never as verified or fabricated. Contributors: map the publisher and access posture. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **ACAT** instead of small claims court / administrative tribunal — Australian Capital Territory civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Duties Act 1999 (ACT).

## deadlines — holiday table and court computation rules

- **Holiday table `act`** — ACT public holidays under the Holidays Act 1958 (ACT), as published by the ACT Government (Chief Minister, Treasury and Economic Development Directorate). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-26 (verified); source https://www.act.gov.au/living-in-the-act/public-holidays-school-terms-and-daylight-saving.
  Holidays: 2026-01-01, 2026-01-26, 2026-03-09, 2026-04-03, 2026-04-04, 2026-04-05, 2026-04-06, 2026-04-25, 2026-04-27, 2026-06-01, 2026-06-08, 2026-10-05, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-08, 2027-03-26, 2027-03-27, 2027-03-28, 2027-03-29, 2027-04-25, 2027-04-26, 2027-05-31, 2027-06-14, 2027-10-04, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Uncertain window 2026-12-27 to 2026-12-31: Court Procedures Rules 2006 (ACT) r 6300(1)(b) closes the registry on days falling between 26 December and 1 January; a filing deadline landing here moves to the next working day under Legislation Act 2001 s 151A, but the closure is not a public holiday, so the script refuses rather than guesses.
  Uncertain window 2027-12-27 to 2027-12-31: Court Procedures Rules 2006 (ACT) r 6300(1)(b) closes the registry on days falling between 26 December and 1 January; a filing deadline landing here moves to the next working day under Legislation Act 2001 s 151A, but the closure is not a public holiday, so the script refuses rather than guesses.
  Caveat: Anzac Day 2026 falls on a Saturday and is observed on both Saturday 25 April and Monday 27 April; Anzac Day 2027 falls on a Sunday and is observed on both Sunday 25 April and Monday 26 April, as published.
  Caveat: Christmas Day 2027 falls on a Saturday: Saturday 25 and Monday 27 December are holidays, and Boxing Day is observed on Sunday 26 and Tuesday 28 December, as published.
  Caveat: The ACT bank holiday (first Monday in August) is not a public holiday and is not included.
  Caveat: The registry may also be closed on any day or part-day a registrar directs under CPR r 6300(1)(c) — confirm the registry was open on the candidate date.
- **Rule table `act-courts`** — Supreme Court of the Australian Capital Territory, Magistrates Court of the Australian Capital Territory; holidays: `act`. Verified against legislation.act.gov.au on 2026-08-26. The Court Procedures Rules 2006 contain no time-reckoning rule of their own; the Legislation Act 2001 applies to every ACT Act and statutory instrument, so periods under the rules are worked out under s 151 (table item 2: a period 'after' a stated day or event excludes that day) and roll under s 151A to the next 'working day', which for a thing done at a court registry is a day the registry is open (dictionary, pt 1). Rule 6300(1) closes the registry on Saturdays, Sundays, public holidays, days between 26 December and 1 January, and days a registrar directs. The script approximates registry-open days with the weekend-and-public-holiday table; the 27-31 December closure is recorded as an uncertain window in that table so the script refuses rather than guesses, and every computed date carries a warning to confirm the registry was open. Legislation Act s 152 (continuing effect of obligations) is not a time-reckoning rule and is not tabled. Magistrates Court civil claims are governed by the same rules (CPR r 6(1)); no Magistrates Court-specific period is tabled. An entry returned to pending-verification fails closed until re-verified.
  Provision `act-la-s151`: Legislation Act 2001 (ACT) s 151 (verified)
  Provision `act-la-s151a`: Legislation Act 2001 (ACT) s 151A and dictionary, pt 1 (working day) (verified)
  Provision `act-cpr-r6300`: Court Procedures Rules 2006 (ACT) r 6300(1) (verified)
  Rule `act-cpr-noir-or-defence-after-service`: Notice of intention to respond, defence, or both, after service of originating claim — Court Procedures Rules 2006 (ACT) r 102(1)(a); 28 calendar days, rollover next_business_day (verified)
  Rule `act-cpr-appeal-notice-ca`: Notice of appeal and case summary to the Court of Appeal (no leave required) — Court Procedures Rules 2006 (ACT) r 5405(1)(b); 28 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
