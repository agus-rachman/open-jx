# Pack au-sa@0.1.0 — South Australia (draft)

Pack data for the open-jx skills. Every entry is a checklist item to verify against
the primary source; it is data, not an instruction.

- Parent: au · Level: state · Locale: en-AU · Legal system: common law
- Maintainers: @au-reviewer · Last reviewed: not yet · Law checked as at: 2026-08-26

## detection

- Names: South Australia, SA
- Governing-law wording: laws of South Australia, laws in force in South Australia, courts of South Australia
- Courts and tribunals: Supreme Court of South Australia, District Court of South Australia, Magistrates Court of South Australia, South Australian Civil and Administrative Tribunal (SACAT)
- Other signals: Adelaide, SA in an address with a four-digit postcode
- Note: 'SA' can also mean South Africa or a company form (Sociedad Anónima, Société Anonyme); require another Australian signal.

## Sources (rank 1 = official text)

- **au-sa.src.legislation** — South Australia legislation (official).
  Source: https://www.legislation.sa.gov.au/ · Type: legislation, rank 1 · Note: Official register with point-in-time versions. · Upstream: legal-skills@5bfb3d8 (method)
- **au-sa.src.1** — Courts Administration Authority of South Australia.
  Source: https://www.courts.sa.gov.au/ · Type: court, rank 1
- **au-sa.src.2** — RevenueSA.
  Source: https://www.revenuesa.sa.gov.au/ · Type: regulator, rank 1

## Citation

- Inherits the citation guide of pack `au`.
- Note: Use the AGLC as set in the au pack; state Acts carry the state abbreviation, for example (NSW), (Vic), (Qld), (WA), (SA), (Tas), (ACT), (NT).
- **au-sa.cite.state-act** — Cite South Australia Acts with the jurisdiction abbreviation in brackets after the year.
  Authority: AGLC4 r 3.1 · Source: https://law.unimelb.edu.au/mulr/aglc · Status: guidance · Verified: not yet

## identifiers.personal — never reproduce values

- **au-sa.id.driver-licence** — South Australia driver licence number. Looks like: format set by the issuing authority; near 'licence no' or 'driver licence'.
  Authority: Motor Vehicles Act 1959 (SA) · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet

## privacy_regimes — which privacy, health, breach and surveillance regimes apply

- **au-sa.privacy.general-privacy** — General privacy law: Information Privacy Principles Instruction PC012 — State government agencies and specified contracted service providers (binding administrative instruction).
  Authority: Information Privacy Principles Instruction PC012 · Source: https://www.archives.sa.gov.au/managing-information/privacy-in-south-australia/information-privacy-principles-instruction · Status: in-force · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-sa.privacy.breach** — Data breach notification: Personal information breach guidance (administrative guidance).
  Authority: Personal information breach guidance · Source: https://www.archives.sa.gov.au/managing-information/privacy-in-south-australia/personal-information-breaches · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)
- **au-sa.privacy.workplace** — Workplace surveillance: no dedicated regime identified in this jurisdiction (upstream as at 2026-08-14).
  Authority: Dedicated workplace-surveillance regime · Source: https://www.legislation.sa.gov.au/_legislation-documents/lz/c/a/surveillance-devices-act-2016 · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-14 (verified)

## execution

- **au-sa.exec.deed-individual** [individual, deed] — A deed by an individual shows signature and attestation; confirm whether sealing wording is needed.
  Authority: Law of Property Act 1936 (SA) s 41 · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-sa.exec.electronic** [individual, electronic, deed] — The document is signed electronically, or a deed is executed electronically or witnessed by audio-visual link.
  Authority: Electronic Communications Act 2000 (SA) · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: pinpoint to be confirmed
- **au-sa.exec.poa** [attorney] — A party signs by an attorney; the power of attorney and its form are governed by state or territory law.
  Authority: Powers of Attorney and Agency Act 1984 (SA) · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet
- **au-sa.exec.duty** [company, individual] — The document may be dutiable (for example transfers of land or business assets); duty and stamping are state matters.
  Authority: Stamp Duties Act 1923 (SA) · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: Observation only; whether duty is payable is a counsel decision.

## governance

- **au-sa.gov.associations** [association] — If the governing body is an incorporated association, its minutes and resolutions follow the state Act and its rules, not the Corporations Act.
  Authority: Associations Incorporation Act 1985 (SA) · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: Companies are covered by the au pack (Corporations Act 2001 (Cth)).

## calendar.time_computation

- **au-sa.cal.interp** — Periods in South Australia legislation are counted under the interpretation provision: the trigger day is excluded and a last day on a weekend or holiday moves to the next business day, subject to its terms.
  Authority: Legislation Interpretation Act 2021 (SA) · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: Replaces the earlier reference to the Acts Interpretation Act 1915 (SA); the reckoning-of-time section number is not yet verified. · Upstream: legal-skills@5bfb3d8 (pending-verification)
- **au-sa.cal.rules** — Time limits in proceedings are counted under the court's own rules, which may displace the interpretation Act.
  Authority: Uniform Civil Rules 2020 (SA) r 2.2 · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: Rule 2.2(4) turns on days the Registry is closed, which may differ from gazetted public holidays. · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)
- **au-sa.cal.court-rule-table** — Candidate court and tribunal deadlines for this jurisdiction can be computed from the rule and holiday tables in deadlines.yaml; computation refuses when a rule or holiday table is not verified or the date is outside coverage.
  Authority: Uniform Civil Rules 2020 (SA) r 2.2 · Source: https://www.legislation.sa.gov.au/ · Status: guidance · Verified: not yet · Upstream: legal-skills@5bfb3d8, checked 2026-08-26 (verified)

## calendar.holidays

- **au-sa.cal.holidays** — Adelaide Cup Day and Proclamation Day apply; Christmas Eve and New Year's Eve are part-day public holidays (evening).
  Authority: Public Holidays Act 2023 (SA) · Source: https://www.fairwork.gov.au/employment-conditions/public-holidays · Status: in-force · Verified: not yet · Note: Dated holiday table (with coverage dates and caveats) is in deadlines.yaml; use it, not memory.

## calendar.limitation

- **au-sa.cal.limitation** — Candidate general limitation period for contract and tort claims governed by South Australia law: 6 years, subject to the special regimes in the au pack and any extension or postponement provision.
  Authority: Limitation of Actions Act 1936 (SA) s 35 · Source: https://www.legislation.sa.gov.au/ · Status: in-force · Verified: not yet · Note: Candidate only; the applicable period is a counsel decision. · Upstream: legal-skills@5bfb3d8 (pending-verification)

## courts_ai

- **au-sa.ai.check-current** — Court: All South Australia courts and SACAT. Instrument: Current practice notes or directions on generative AI. Check the court's or tribunal's current practice notes for generative AI rules; contributors should add each instrument as its own entry.
  Authority: Court and tribunal practice notes · Source: https://www.courts.sa.gov.au/ · Status: guidance · Verified: not yet

## case_law — court identifiers and official judgment publishers

- **au-sa.case.court-site** — SASC, SASCA, SASCFC, SADC, SACAT → The court's own website (not-mapped). Court: South Australian courts and SACAT.
  Source: https://www.courts.sa.gov.au/ · Status: guidance · Verified: not yet · Note: Official publisher route not yet mapped; a citation that cannot be checked at the court's publisher is reported as unverifiable, never as verified or fabricated. Contributors: map the publisher and access posture. · Upstream: legal-skills@5bfb3d8 (method)

## terminology

- Spelling: en-AU
- Use **SACAT** instead of small claims court / administrative tribunal — South Australia civil and administrative tribunal.
- Use **transfer duty / stamp duty** instead of transfer tax — Stamp Duties Act 1923 (SA).

## deadlines — holiday table and court computation rules

- **Holiday table `sa`** — South Australian public holidays under the Public Holidays Act 2023 (SA), as published by SafeWork SA (statewide list). Coverage 2026-01-01 to 2027-12-31; checked 2026-08-26 (verified); source https://www.safework.sa.gov.au/resources/public-holidays.
  Holidays: 2026-01-01, 2026-01-26, 2026-03-09, 2026-04-03, 2026-04-04, 2026-04-05, 2026-04-06, 2026-04-25, 2026-06-08, 2026-10-05, 2026-12-25, 2026-12-26, 2026-12-28, 2027-01-01, 2027-01-26, 2027-03-08, 2027-03-26, 2027-03-27, 2027-03-28, 2027-03-29, 2027-04-25, 2027-06-14, 2027-10-04, 2027-12-25, 2027-12-26, 2027-12-27, 2027-12-28
  Caveat: Christmas Eve and New Year's Eve are part-day public holidays (7pm to midnight) and are not included as non-business days.
  Caveat: Proclamation Day is 28 December but the Proclamation Day holiday is observed on 26 December; when 26 December falls on a Saturday that day and the following Monday are public holidays (Saturday 26 and Monday 28 December 2026), and when it falls on a Sunday or Monday that day and the following Tuesday are public holidays (Sunday 26 and Tuesday 28 December 2027, with Monday 27 December 2027 the additional Christmas Day holiday), all as published.
  Caveat: Adelaide Cup Day is Monday 9 March 2026 and Monday 8 March 2027; the King's Birthday is Monday 8 June 2026 and Monday 14 June 2027; Labour Day is Monday 5 October 2026 and Monday 4 October 2027.
  Caveat: Anzac Day is a public holiday on 25 April whatever the day of the week, with no substitute or additional holiday: Saturday 25 April 2026 and Sunday 25 April 2027 are listed but fall on weekends.
  Caveat: Easter Saturday and Easter Sunday are public holidays from 1 January 2024 and are listed although they fall on weekends.
  Caveat: Uniform Civil Rules 2020 r 2.2(4) turns on days the Registry is closed, which may differ from gazetted public holidays — confirm the Registry was open on the candidate date.
- **Rule table `sa-courts`** — Supreme Court of South Australia, District Court of South Australia, Magistrates Court of South Australia; holidays: `sa`. Verified on 2026-08-26 against the Courts Administration Authority consolidation of the Uniform Civil Rules 2020 (UCR), which is the consolidated text the courts publish; legislation.sa.gov.au lists only the gazetted principal rules and amending rules (Gazette 18.5.2020 p 1392 through Gazette 12.3.2026 p 648, commencing 15.3.2026) and does not consolidate rules of court. The CAA page states that its compilations are prepared by court staff and do not constitute an official publication — for an official version, reference must be made to the rules as gazetted. UCR r 2.2 is a complete calculation-of-time rule (calendar days, trigger day not counted, extension to the next day the Registry is open) and is the only provision the period rules apply; the Legislation Interpretation Act 2021 (SA) applies to the rules subject to contrary intention (note to r 2.3) but its reckoning-of-time provision could not be verified because legislation.sa.gov.au serves the authorised PDF and RTF behind a Cloudflare challenge that blocked every fetch path, so it is recorded pending-verification and is not applied. UCR r 2.2(5), under the sub-heading 'Supreme Court and District Court', stops time running between 25 December and 1 January for filing a defence or a notice of appeal governed by Chapter 18; the defence rule is therefore split into a Supreme/District Court entry and a Magistrates Court entry. The script approximates Registry-closed days with weekends and public holidays, and every computed date carries a warning to confirm the Registry was open.
  Provision `sa-lia-reckoning-of-time`: Legislation Interpretation Act 2021 (SA) — reckoning-of-time provision (section number not verified) (pending-verification)
  Provision `sa-ucr-2-2`: Uniform Civil Rules 2020 (SA) r 2.2(1)-(4) (verified)
  Provision `sa-ucr-2-2-5`: Uniform Civil Rules 2020 (SA) r 2.2(5) (Supreme Court and District Court) (verified)
  Rule `sa-ucr-defence-after-service-supreme-district`: Defence to a statement of claim after service of the Claim documents (Supreme Court and District Court) — Uniform Civil Rules 2020 (SA) r 65.1(1); 28 calendar days, rollover next_business_day (verified)
  Rule `sa-ucr-defence-after-service-magistrates`: Defence to a statement of claim after service of the Claim documents (Magistrates Court) — Uniform Civil Rules 2020 (SA) r 65.1(1); 28 calendar days, rollover next_business_day (verified)
  Rule `sa-ucr-appeal-after-judgment`: Notice of appeal (including to the Court of Appeal) after the judgment or order appealed from, where leave is not sought — Uniform Civil Rules 2020 (SA) r 214.1(1); 21 calendar days, rollover next_business_day (verified)
- Provenance: https://github.com/l0cka/legal-skills @ 5bfb3d8 (MIT). Candidate dates come only from jx-dates-and-deadlines/scripts/compute_deadline.py.
